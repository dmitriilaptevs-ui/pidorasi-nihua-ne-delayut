#!/bin/sh
set -e

echo "▸ Применяю миграции базы данных…"
npx prisma migrate deploy

echo "▸ Запускаю rubai…"
exec npx next start -p 3000 -H 0.0.0.0
