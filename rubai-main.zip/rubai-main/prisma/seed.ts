import "../scripts/_env";
import { env } from "../src/lib/env";
import { hashPassword } from "../src/lib/password";
import { prisma } from "../src/lib/db";
import { syncModels } from "../src/lib/model-sync";
import { syncUsdRate } from "../src/lib/rate-sync";

const DEMO_EMAIL = "demo@rubai.local";
const DEMO_PASSWORD = "demo12345";
const DEMO_BALANCE_KOPECKS = 100_000n; // 1 000 ₽

async function main(): Promise<void> {
  // Администратор
  const adminEmail = env.adminEmail || "admin@rubai.local";
  const adminPassword = env.adminPassword || "admin12345";
  const existingAdmin = await prisma.user.findUnique({ where: { email: adminEmail } });

  if (!existingAdmin) {
    await prisma.user.create({
      data: {
        email: adminEmail,
        name: "Администратор",
        passwordHash: hashPassword(adminPassword),
        role: "ADMIN",
        consentPd: true,
      },
    });
    console.log(`✔ Создан администратор: ${adminEmail} / ${adminPassword}`);
  } else {
    console.log(`• Администратор уже существует: ${adminEmail}`);
  }

  // Демо-пользователь
  const demo = await prisma.user.findUnique({ where: { email: DEMO_EMAIL } });
  if (!demo) {
    await prisma.user.create({
      data: {
        email: DEMO_EMAIL,
        name: "Демо-пользователь",
        passwordHash: hashPassword(DEMO_PASSWORD),
        balanceKopecks: DEMO_BALANCE_KOPECKS,
      },
    });
    await prisma.transaction.create({
      data: {
        userId: (await prisma.user.findUniqueOrThrow({ where: { email: DEMO_EMAIL } })).id,
        type: "DEPOSIT",
        amountKopecks: DEMO_BALANCE_KOPECKS,
        balanceAfter: DEMO_BALANCE_KOPECKS,
        description: "Стартовое демо-пополнение",
      },
    });
    console.log(`✔ Создан демо-пользователь: ${DEMO_EMAIL} / ${DEMO_PASSWORD} (баланс 1 000 ₽)`);
  } else {
    console.log(`• Демо-пользователь уже существует: ${DEMO_EMAIL}`);
  }

  // Курс валюты
  try {
    const rate = await syncUsdRate();
    console.log(`✔ Курс USD с сайта ЦБ РФ: ${rate} ₽`);
  } catch (error) {
    console.log(`• Не удалось загрузить курс ЦБ (${(error as Error).message}); используется USD_RUB_FALLBACK=${env.usdRubFallback}`);
  }

  // Каталог моделей
  const modelCount = await prisma.model.count();
  if (modelCount === 0) {
    try {
      const result = await syncModels();
      console.log(`✔ Каталог моделей: загружено ${result.total} (провайдер: ${result.provider})`);
    } catch (error) {
      console.log(`• Не удалось синхронизировать модели: ${(error as Error).message}`);
    }
  } else {
    console.log(`• Каталог моделей уже заполнен: ${modelCount}`);
  }
}

main()
  .catch((error) => {
    console.error("Ошибка seed-скрипта:", error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
