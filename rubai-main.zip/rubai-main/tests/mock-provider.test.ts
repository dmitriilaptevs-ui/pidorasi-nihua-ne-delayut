import { describe, expect, it } from "vitest";
import { mockProvider } from "../src/lib/upstream/mock";

describe("mock upstream provider", () => {
  it("возвращает каталог моделей", async () => {
    const models = await mockProvider.listModels();
    expect(models.length).toBeGreaterThanOrEqual(6);
    expect(models.every((model) => model.slug.includes("/"))).toBe(true);
  });

  it("отвечает на chat completions с usage", async () => {
    const response = await mockProvider.chatCompletions({
      model: "openai/gpt-4o-mini",
      messages: [{ role: "user", content: "Привет, как дела?" }],
    });
    expect(response.status).toBe(200);

    const json = (await response.json()) as {
      choices: Array<{ message: { content: string } }>;
      usage: { prompt_tokens: number; completion_tokens: number; total_tokens: number };
    };
    expect(json.choices[0]?.message.content).toContain("[mock]");
    expect(json.usage.prompt_tokens).toBeGreaterThan(0);
    expect(json.usage.total_tokens).toBe(json.usage.prompt_tokens + json.usage.completion_tokens);
  });

  it("стримит SSE с финальным usage и [DONE]", async () => {
    const response = await mockProvider.chatCompletions({
      model: "openai/gpt-4o-mini",
      stream: true,
      messages: [{ role: "user", content: "Стрим-тест" }],
    });
    expect(response.headers.get("content-type")).toContain("text/event-stream");

    const text = await response.text();
    expect(text).toContain("chat.completion.chunk");
    expect(text).toContain("data: [DONE]");
    expect(text).toContain('"usage"');
  });

  it("возвращает эмбеддинги", async () => {
    const response = await mockProvider.embeddings({ model: "mock-embedding", input: ["раз", "два"] });
    const json = (await response.json()) as {
      data: Array<{ embedding: number[] }>;
      usage: { prompt_tokens: number };
    };
    expect(json.data).toHaveLength(2);
    expect(json.data[0]?.embedding).toHaveLength(8);
    expect(json.usage.prompt_tokens).toBeGreaterThan(0);
  });
});
