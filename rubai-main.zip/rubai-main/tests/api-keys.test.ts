import { describe, expect, it } from "vitest";
import { API_KEY_PREFIX, extractBearerToken, generateApiKey, hashApiKey, maskApiKey } from "../src/lib/api-keys";

describe("api keys", () => {
  it("генерирует ключ правильного формата", () => {
    const key = generateApiKey();
    expect(key.plain.startsWith(API_KEY_PREFIX)).toBe(true);
    expect(key.plain).toHaveLength(API_KEY_PREFIX.length + 48);
    expect(key.hash).toHaveLength(64);
    expect(key.last4).toBe(key.plain.slice(-4));
    expect(key.prefix).toBe(key.plain.slice(0, API_KEY_PREFIX.length + 4));
  });

  it("генерирует уникальные ключи", () => {
    const keys = new Set(Array.from({ length: 50 }, () => generateApiKey().plain));
    expect(keys.size).toBe(50);
  });

  it("хеширует ключ детерминированно", () => {
    const key = generateApiKey();
    expect(hashApiKey(key.plain)).toBe(key.hash);
    expect(hashApiKey(key.plain)).not.toBe(key.plain);
  });

  it("маскирует ключ для отображения", () => {
    const key = generateApiKey();
    const masked = maskApiKey({ keyPrefix: key.prefix, last4: key.last4 });
    expect(masked).toBe(`${key.prefix}…${key.last4}`);
    expect(masked).not.toContain(key.plain.slice(12, -4));
  });

  it("извлекает токен из заголовков", () => {
    const withBearer = new Request("http://localhost", {
      headers: { authorization: "Bearer sk-rubai-test" },
    });
    expect(extractBearerToken(withBearer)).toBe("sk-rubai-test");

    const withApiKey = new Request("http://localhost", { headers: { "x-api-key": "sk-rubai-x" } });
    expect(extractBearerToken(withApiKey)).toBe("sk-rubai-x");

    const empty = new Request("http://localhost");
    expect(extractBearerToken(empty)).toBeNull();
  });
});
