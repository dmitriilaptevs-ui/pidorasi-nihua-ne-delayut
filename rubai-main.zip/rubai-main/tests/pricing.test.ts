import { describe, expect, it } from "vitest";
import { costKopecks, costRub, costUsd, estimateTokensFromText } from "../src/lib/pricing";

const price = {
  inputUsdPerM: 3,
  outputUsdPerM: 15,
  cachedUsdPerM: 0.3,
  usdRubRate: 95,
  markupPercent: 30,
};

describe("pricing", () => {
  it("считает стоимость в долларах без кэша", () => {
    const usd = costUsd({ promptTokens: 1_000_000, completionTokens: 1_000_000 }, price);
    expect(usd).toBeCloseTo(18, 10); // 3 + 15
  });

  it("учитывает кэшированные токены по отдельной цене", () => {
    const usd = costUsd({ promptTokens: 1_000_000, completionTokens: 0, cachedTokens: 1_000_000 }, price);
    expect(usd).toBeCloseTo(0.3, 10);
  });

  it("не позволяет кэшу превысить число входных токенов", () => {
    const usd = costUsd({ promptTokens: 100, completionTokens: 0, cachedTokens: 10_000 }, price);
    expect(usd).toBeCloseTo((100 * 0.3) / 1_000_000, 12);
  });

  it("применяет курс и наценку", () => {
    const rub = costRub({ promptTokens: 1_000_000, completionTokens: 0 }, price);
    expect(rub).toBeCloseTo(3 * 95 * 1.3, 10);
  });

  it("округляет копейки вверх и не теряет мелкие суммы", () => {
    const kopecks = costKopecks({ promptTokens: 1, completionTokens: 0 }, { ...price, inputUsdPerM: 0.15 });
    expect(kopecks).toBe(1n); // 0.00000015 * 95 * 1.3 = 0.000018525 ₽ → 0.0018525 коп. → 1 коп.
  });

  it("возвращает 0 для бесплатных моделей", () => {
    const kopecks = costKopecks(
      { promptTokens: 1000, completionTokens: 1000 },
      { ...price, inputUsdPerM: 0, outputUsdPerM: 0, cachedUsdPerM: 0 },
    );
    expect(kopecks).toBe(0n);
  });

  it("оценивает токены по длине текста", () => {
    expect(estimateTokensFromText("")).toBe(1);
    expect(estimateTokensFromText("a".repeat(40))).toBe(10);
  });
});
