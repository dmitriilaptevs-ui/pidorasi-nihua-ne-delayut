import { afterEach, describe, expect, it } from "vitest";
import { checkRateLimit, resetRateLimits } from "../src/lib/ratelimit";

describe("ratelimit", () => {
  afterEach(() => {
    resetRateLimits();
  });

  it("пропускает запросы в пределах лимита", () => {
    for (let i = 0; i < 5; i += 1) {
      expect(checkRateLimit("k1", 5).ok).toBe(true);
    }
  });

  it("блокирует запросы сверх лимита и подсказывает retry-after", () => {
    for (let i = 0; i < 3; i += 1) {
      checkRateLimit("k2", 3);
    }
    const blocked = checkRateLimit("k2", 3);
    expect(blocked.ok).toBe(false);
    expect(blocked.retryAfterSec).toBeGreaterThan(0);
    expect(blocked.remaining).toBe(0);
  });

  it("ведёт отдельные окна для разных ключей", () => {
    for (let i = 0; i < 2; i += 1) {
      checkRateLimit("a", 2);
    }
    expect(checkRateLimit("a", 2).ok).toBe(false);
    expect(checkRateLimit("b", 2).ok).toBe(true);
  });

  it("освобождает окно после истечения периода", async () => {
    checkRateLimit("k3", 1, 50);
    expect(checkRateLimit("k3", 1, 50).ok).toBe(false);
    await new Promise((resolve) => setTimeout(resolve, 80));
    expect(checkRateLimit("k3", 1, 50).ok).toBe(true);
  });
});
