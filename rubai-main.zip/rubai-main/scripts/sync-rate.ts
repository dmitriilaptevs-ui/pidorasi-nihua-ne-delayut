import "./_env";
import { prisma } from "../src/lib/db";
import { syncUsdRate } from "../src/lib/rate-sync";

async function main(): Promise<void> {
  const rate = await syncUsdRate();
  console.log(`✔ Курс USD обновлён: ${rate} ₽`);
}

main()
  .catch((error) => {
    console.error("Ошибка обновления курса:", error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
