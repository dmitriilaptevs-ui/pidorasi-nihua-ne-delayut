import "./_env";
import { prisma } from "../src/lib/db";
import { syncModels } from "../src/lib/model-sync";

async function main(): Promise<void> {
  const result = await syncModels();
  console.log(
    `✔ Синхронизация завершена (${result.provider}): всего ${result.total}, новых ${result.created}, обновлено ${result.updated}, избранных ${result.featured}`,
  );
}

main()
  .catch((error) => {
    console.error("Ошибка синхронизации моделей:", error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
