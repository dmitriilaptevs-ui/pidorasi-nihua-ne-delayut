/**
 * Загружает переменные из .env для standalone-скриптов (tsx),
 * которые запускаются вне Next.js. Импортируется первым.
 */
import { existsSync } from "node:fs";
import path from "node:path";

const envFile = path.resolve(process.cwd(), ".env");

if (existsSync(envFile) && !process.env.DATABASE_URL) {
  try {
    process.loadEnvFile(envFile);
  } catch {
    // .env недоступен — продолжаем со значениями по умолчанию
  }
}
