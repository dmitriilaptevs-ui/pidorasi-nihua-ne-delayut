#!/usr/bin/env node
/**
 * Сквозная проверка API rubai. Требует запущенного приложения:
 *   npm run dev
 *   npm run smoke
 */
const BASE = (process.env.BASE_URL ?? "http://localhost:3000").replace(/\/+$/, "");
const MODEL = process.env.SMOKE_MODEL ?? "openai/gpt-4o-mini";

let failures = 0;

function check(name, ok, extra = "") {
  console.log(`${ok ? "✔" : "✘"} ${name}${extra ? ` — ${extra}` : ""}`);
  if (!ok) failures += 1;
}

async function jsonFetch(path, options = {}) {
  const response = await fetch(`${BASE}${path}`, options);
  let body = null;
  try {
    body = await response.json();
  } catch {
    body = null;
  }
  return { response, body };
}

async function main() {
  const email = `smoke-${Date.now()}@example.com`;
  const password = "smoke12345";

  const register = await jsonFetch("/api/auth/register", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ name: "Smoke Test", email, password, consent: true }),
  });
  check("Регистрация пользователя", register.response.ok, register.body?.error);
  if (!register.response.ok) process.exit(1);

  const cookie = (register.response.headers.getSetCookie?.() ?? [])
    .map((value) => value.split(";")[0])
    .join("; ");

  const keyResponse = await jsonFetch("/api/keys", {
    method: "POST",
    headers: { "content-type": "application/json", cookie },
    body: JSON.stringify({ name: "Smoke", limitRub: 100, limitPeriod: "MONTHLY" }),
  });
  const plainKey = keyResponse.body?.plainKey;
  check("Создание API-ключа", keyResponse.response.ok && typeof plainKey === "string", keyResponse.body?.error);
  if (!plainKey) process.exit(1);

  const topup = await jsonFetch("/api/billing/topup", {
    method: "POST",
    headers: { "content-type": "application/json", cookie },
    body: JSON.stringify({ amountRub: 500 }),
  });
  check("Создание платежа на пополнение", topup.response.ok, topup.body?.error);

  if (topup.body?.mock) {
    const pay = await jsonFetch("/api/billing/mock-pay", {
      method: "POST",
      headers: { "content-type": "application/json", cookie },
      body: JSON.stringify({ paymentId: topup.body.paymentId }),
    });
    check("Тестовое зачисление баланса", pay.response.ok && pay.body?.credited === true, pay.body?.error);
  }

  const models = await jsonFetch("/v1/models", {
    headers: { authorization: `Bearer ${plainKey}` },
  });
  check(
    "GET /v1/models",
    models.response.ok && Array.isArray(models.body?.data) && models.body.data.length > 0,
    models.body?.error?.message,
  );

  const alias = await jsonFetch("/api/v1/models", {
    headers: { authorization: `Bearer ${plainKey}` },
  });
  check("Алиас /api/v1/models", alias.response.ok && Array.isArray(alias.body?.data));

  const embeddings = await jsonFetch("/v1/embeddings", {
    method: "POST",
    headers: { authorization: `Bearer ${plainKey}`, "content-type": "application/json" },
    body: JSON.stringify({ model: "openai/gpt-4o-mini", input: "Проверка эмбеддингов" }),
  });
  check(
    "POST /v1/embeddings",
    embeddings.response.ok && Array.isArray(embeddings.body?.data?.[0]?.embedding),
    embeddings.body?.error?.message,
  );

  const chat = await jsonFetch("/v1/chat/completions", {
    method: "POST",
    headers: { authorization: `Bearer ${plainKey}`, "content-type": "application/json" },
    body: JSON.stringify({ model: MODEL, messages: [{ role: "user", content: "Привет!" }] }),
  });
  check(
    "POST /v1/chat/completions",
    chat.response.ok && Array.isArray(chat.body?.choices) && chat.body.choices.length > 0,
    chat.body?.error?.message ?? chat.body?.error,
  );
  const cost = chat.response.headers.get("x-rubai-cost-kopecks");
  check("Заголовок x-rubai-cost-kopecks", cost !== null, `стоимость: ${cost} коп.`);

  const streamResponse = await fetch(`${BASE}/v1/chat/completions`, {
    method: "POST",
    headers: { authorization: `Bearer ${plainKey}`, "content-type": "application/json" },
    body: JSON.stringify({
      model: MODEL,
      stream: true,
      messages: [{ role: "user", content: "Стриминг!" }],
    }),
  });
  const streamText = await streamResponse.text();
  check(
    "Стриминг SSE",
    streamResponse.ok && streamText.includes("[DONE]") && streamText.includes("chat.completion.chunk"),
  );

  const badKey = await jsonFetch("/v1/chat/completions", {
    method: "POST",
    headers: { authorization: "Bearer sk-rubai-invalid", "content-type": "application/json" },
    body: JSON.stringify({ model: MODEL, messages: [] }),
  });
  check("Неверный ключ → 401", badKey.response.status === 401);

  const keys = await jsonFetch("/api/keys", { headers: { cookie } });
  const spent = keys.body?.keys?.[0]?.spentKopecks ?? 0;
  check("Расход учтён в статистике ключа", spent > 0, `израсходовано: ${spent} коп.`);

  const csvResponse = await fetch(`${BASE}/api/usage/export?days=30`, { headers: { cookie } });
  const csvText = await csvResponse.text();
  check(
    "Экспорт CSV",
    csvResponse.ok && csvText.includes(MODEL) && csvText.includes("Стоимость"),
    `строк: ${csvText.split("\n").length}`,
  );

  // 9. Лимит расхода по ключу
  const zeroLimitKey = await jsonFetch("/api/keys", {
    method: "POST",
    headers: { "content-type": "application/json", cookie },
    body: JSON.stringify({ name: "Zero limit", limitRub: 0, limitPeriod: "NONE" }),
  });
  const limitResponse = await jsonFetch("/v1/chat/completions", {
    method: "POST",
    headers: { authorization: `Bearer ${zeroLimitKey.body?.plainKey}`, "content-type": "application/json" },
    body: JSON.stringify({ model: MODEL, messages: [{ role: "user", content: "Проверка лимита" }] }),
  });
  check(
    "Лимит по ключу → 429",
    limitResponse.response.status === 429 && limitResponse.body?.error?.code === "key_limit_exceeded",
    `status=${limitResponse.response.status}, code=${limitResponse.body?.error?.code}`,
  );

  // 10. Недостаточно средств
  const poorEmail = `smoke-poor-${Date.now()}@example.com`;
  const poorRegister = await jsonFetch("/api/auth/register", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ name: "Poor Smoke", email: poorEmail, password, consent: true }),
  });
  const poorCookie = (poorRegister.response.headers.getSetCookie?.() ?? [])
    .map((value) => value.split(";")[0])
    .join("; ");
  const poorKey = await jsonFetch("/api/keys", {
    method: "POST",
    headers: { "content-type": "application/json", cookie: poorCookie },
    body: JSON.stringify({ name: "Без баланса" }),
  });
  const poorResponse = await jsonFetch("/v1/chat/completions", {
    method: "POST",
    headers: { authorization: `Bearer ${poorKey.body?.plainKey}`, "content-type": "application/json" },
    body: JSON.stringify({ model: MODEL, messages: [{ role: "user", content: "Нет денег" }] }),
  });
  check(
    "Нулевой баланс → 402",
    poorResponse.response.status === 402 && poorResponse.body?.error?.code === "insufficient_funds",
    `status=${poorResponse.response.status}, code=${poorResponse.body?.error?.code}`,
  );

  // 11. Отзыв ключа
  const revoked = await jsonFetch(`/api/keys/${keyResponse.body.key.id}`, {
    method: "DELETE",
    headers: { cookie },
  });
  const revokedResponse = await jsonFetch("/v1/chat/completions", {
    method: "POST",
    headers: { authorization: `Bearer ${plainKey}`, "content-type": "application/json" },
    body: JSON.stringify({ model: MODEL, messages: [{ role: "user", content: "Отозванный ключ" }] }),
  });
  check(
    "Отозванный ключ → 401",
    revoked.response.ok && revokedResponse.response.status === 401,
    `status=${revokedResponse.response.status}`,
  );

  console.log("");
  if (failures === 0) {
    console.log("Все проверки пройдены ✅");
  } else {
    console.log(`Провалено проверок: ${failures} ❌`);
  }
  process.exit(failures === 0 ? 0 : 1);
}

main().catch((error) => {
  console.error("Smoke-тест упал:", error);
  process.exit(1);
});
