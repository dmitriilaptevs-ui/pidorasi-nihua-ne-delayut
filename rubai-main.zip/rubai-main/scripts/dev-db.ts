/**
 * Локальная база данных для разработки без Docker:
 * запускает встроенный Postgres на порту 5433 в папке .devdb.
 *
 * Использование: npm run dev:db
 */
import path from "node:path";
import { existsSync } from "node:fs";
import EmbeddedPostgres from "embedded-postgres";

const DATA_DIR = path.join(process.cwd(), ".devdb", "data");
const PORT = 5433;
const DATABASE = "rubai";
const USER = "postgres";
const PASSWORD = "postgres";

async function main(): Promise<void> {
  const pg = new EmbeddedPostgres({
    databaseDir: DATA_DIR,
    user: USER,
    password: PASSWORD,
    port: PORT,
    persistent: true,
    authMethod: "password",
    // UTF-8 обязателен: иначе русская локаль Windows даёт WIN1251,
    // в которую не помещается символ ₽.
    initdbFlags: ["--encoding=UTF8", "--locale=C"],
    onLog: process.env.DEV_DB_VERBOSE ? (message) => console.log(String(message)) : () => undefined,
    onError: (error) => console.error(String(error)),
  });

  const isInitialised = existsSync(path.join(DATA_DIR, "PG_VERSION"));
  if (!isInitialised) {
    console.log("Инициализирую кластер Postgres (первый запуск)…");
    await pg.initialise();
  }

  await pg.start();
  console.log(`✔ Postgres запущен: postgresql://${USER}:${PASSWORD}@localhost:${PORT}`);

  try {
    await pg.createDatabase(DATABASE);
    console.log(`✔ База данных «${DATABASE}» создана`);
  } catch {
    console.log(`• База данных «${DATABASE}» уже существует`);
  }

  console.log("");
  console.log(`DATABASE_URL="postgresql://${USER}:${PASSWORD}@localhost:${PORT}/${DATABASE}?schema=public"`);
  console.log("Нажмите Ctrl+C, чтобы остановить базу.");

  const shutdown = async () => {
    console.log("\nОстанавливаю Postgres…");
    await pg.stop().catch(() => undefined);
    process.exit(0);
  };
  process.on("SIGINT", shutdown);
  process.on("SIGTERM", shutdown);

  await new Promise(() => undefined);
}

main().catch((error) => {
  console.error("Не удалось запустить встроенный Postgres:");
  console.error(error);
  process.exit(1);
});
