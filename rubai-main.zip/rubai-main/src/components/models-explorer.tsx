"use client";

import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import { Badge, Card, EmptyState, Input, Select, Table, Td, Th, Tr } from "@/components/ui";
import { formatTokens } from "@/lib/money";
import type { ModelDto } from "@/lib/serializers";

function price(value: number): string {
  return new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 2 }).format(value);
}

export function ModelsExplorer({
  models,
  markupPercent,
  usdRubRate,
}: {
  models: ModelDto[];
  markupPercent: number;
  usdRubRate: number;
}) {
  const [query, setQuery] = useState("");
  const [provider, setProvider] = useState("all");
  const [sort, setSort] = useState("output-asc");

  const providers = useMemo(
    () => Array.from(new Set(models.map((model) => model.provider))).sort(),
    [models],
  );

  const filtered = useMemo(() => {
    const search = query.trim().toLowerCase();
    const list = models.filter((model) => {
      if (provider !== "all" && model.provider !== provider) return false;
      if (!search) return true;
      return (
        model.slug.toLowerCase().includes(search) ||
        model.displayName.toLowerCase().includes(search) ||
        model.provider.toLowerCase().includes(search)
      );
    });

    return list.sort((a, b) => {
      if (sort === "output-asc") return a.outputRubPerM - b.outputRubPerM;
      if (sort === "output-desc") return b.outputRubPerM - a.outputRubPerM;
      if (sort === "name") return a.displayName.localeCompare(b.displayName, "ru");
      return b.contextLength ? b.contextLength - (a.contextLength ?? 0) : 0;
    });
  }, [models, provider, query, sort]);

  return (
    <div>
      <Card className="mb-6 p-4">
        <div className="grid gap-3 md:grid-cols-[1.5fr_1fr_1fr]">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
            <Input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Поиск по названию или slug…"
              className="pl-9"
            />
          </div>
          <Select value={provider} onChange={(event) => setProvider(event.target.value)}>
            <option value="all">Все провайдеры</option>
            {providers.map((item) => (
              <option key={item} value={item}>
                {item}
              </option>
            ))}
          </Select>
          <Select value={sort} onChange={(event) => setSort(event.target.value)}>
            <option value="output-asc">Сначала дешёвые</option>
            <option value="output-desc">Сначала дорогие</option>
            <option value="context">Сначала с большим контекстом</option>
            <option value="name">По алфавиту</option>
          </Select>
        </div>
        <div className="mt-3 text-xs text-slate-500">
          Найдено моделей: {filtered.length}. Цены — в рублях за 1 млн токенов, с учётом курса ЦБ РФ (
          {price(usdRubRate)} ₽/$) и наценки {markupPercent}%.
        </div>
      </Card>

      {filtered.length === 0 ? (
        <EmptyState
          title="Ничего не найдено"
          description="Попробуйте изменить запрос или сбросить фильтры."
        />
      ) : (
        <Card className="overflow-hidden">
          <Table>
            <thead>
              <tr>
                <Th>Модель</Th>
                <Th>Провайдер</Th>
                <Th>Контекст</Th>
                <Th className="text-right">Вход, ₽/1M</Th>
                <Th className="text-right">Выход, ₽/1M</Th>
                <Th>Модальности</Th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((model) => (
                <Tr key={model.id}>
                  <Td>
                    <div className="font-medium text-slate-100">{model.displayName}</div>
                    <div className="mt-0.5 font-mono text-xs text-slate-500">{model.slug}</div>
                  </Td>
                  <Td>
                    <Badge>{model.provider}</Badge>
                  </Td>
                  <Td className="text-xs text-slate-400">
                    {model.contextLength ? `${formatTokens(model.contextLength)} токенов` : "—"}
                  </Td>
                  <Td className="text-right font-mono text-xs">{price(model.inputRubPerM)}</Td>
                  <Td className="text-right font-mono text-xs">{price(model.outputRubPerM)}</Td>
                  <Td className="text-xs text-slate-400">{model.inputModalities.join(", ")}</Td>
                </Tr>
              ))}
            </tbody>
          </Table>
        </Card>
      )}
    </div>
  );
}
