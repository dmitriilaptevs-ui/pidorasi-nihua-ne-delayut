"use client";

import { useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { Alert, Button, Card, Field, Input } from "@/components/ui";

export function ProfileForm({ initialName, email }: { initialName: string; email: string }) {
  const router = useRouter();
  const [name, setName] = useState(initialName);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(false);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setLoading(true);
    setError(null);
    setSaved(false);

    try {
      const response = await fetch("/api/profile", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ name }),
      });
      const data = (await response.json().catch(() => null)) as { error?: string } | null;

      if (!response.ok) {
        setError(data?.error ?? "Не удалось сохранить");
        return;
      }

      setSaved(true);
      router.refresh();
    } catch {
      setError("Сеть недоступна");
    } finally {
      setLoading(false);
    }
  }

  return (
    <Card className="p-6">
      <div className="font-medium text-white">Профиль</div>
      <div className="mt-1 text-xs text-slate-500">Имя отображается в личном кабинете.</div>

      <form onSubmit={submit} className="mt-5 space-y-4">
        {error ? <Alert tone="danger">{error}</Alert> : null}
        {saved ? <Alert tone="success">Изменения сохранены</Alert> : null}

        <Field label="Имя">
          <Input value={name} onChange={(event) => setName(event.target.value)} minLength={2} required />
        </Field>

        <Field label="Email" hint="Email изменить нельзя — он используется для входа.">
          <Input value={email} disabled />
        </Field>

        <Button type="submit" disabled={loading}>
          {loading ? "Сохраняем…" : "Сохранить"}
        </Button>
      </form>
    </Card>
  );
}

export function PasswordForm() {
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(false);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setLoading(true);
    setError(null);
    setSaved(false);

    try {
      const response = await fetch("/api/auth/password", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      const data = (await response.json().catch(() => null)) as { error?: string } | null;

      if (!response.ok) {
        setError(data?.error ?? "Не удалось сменить пароль");
        return;
      }

      setSaved(true);
      setCurrentPassword("");
      setNewPassword("");
    } catch {
      setError("Сеть недоступна");
    } finally {
      setLoading(false);
    }
  }

  return (
    <Card className="p-6">
      <div className="font-medium text-white">Пароль</div>
      <div className="mt-1 text-xs text-slate-500">Минимум 8 символов.</div>

      <form onSubmit={submit} className="mt-5 space-y-4">
        {error ? <Alert tone="danger">{error}</Alert> : null}
        {saved ? <Alert tone="success">Пароль обновлён</Alert> : null}

        <Field label="Текущий пароль">
          <Input
            type="password"
            value={currentPassword}
            onChange={(event) => setCurrentPassword(event.target.value)}
            autoComplete="current-password"
            required
          />
        </Field>

        <Field label="Новый пароль">
          <Input
            type="password"
            value={newPassword}
            onChange={(event) => setNewPassword(event.target.value)}
            autoComplete="new-password"
            minLength={8}
            required
          />
        </Field>

        <Button type="submit" disabled={loading}>
          {loading ? "Сохраняем…" : "Сменить пароль"}
        </Button>
      </form>
    </Card>
  );
}
