"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Alert, Badge, Button, Card, Field, Input, Select } from "@/components/ui";
import { CopyButton } from "@/components/copy-button";
import { formatRub } from "@/lib/money";
import type { ApiKeyDto, ModelDto } from "@/lib/serializers";

const PERIOD_LABELS: Record<ApiKeyDto["limitPeriod"], string> = {
  NONE: "за всё время",
  MONTHLY: "в месяц",
};

function formatDate(value: string | null): string {
  if (!value) return "—";
  return new Intl.DateTimeFormat("ru-RU", {
    day: "2-digit",
    month: "2-digit",
    year: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(value));
}

export function KeysManager({
  initialKeys,
  models,
  defaultRpm,
}: {
  initialKeys: ApiKeyDto[];
  models: ModelDto[];
  defaultRpm: number;
}) {
  const router = useRouter();
  const [keys, setKeys] = useState(initialKeys);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [plainKey, setPlainKey] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [showCreate, setShowCreate] = useState(initialKeys.length === 0);

  // форма создания
  const [name, setName] = useState("");
  const [limitRub, setLimitRub] = useState("1000");
  const [limitPeriod, setLimitPeriod] = useState<"NONE" | "MONTHLY">("MONTHLY");
  const [rpmLimit, setRpmLimit] = useState(String(defaultRpm));
  const [allowedModels, setAllowedModels] = useState<string[]>([]);
  const [modelFilter, setModelFilter] = useState("");
  const [creating, setCreating] = useState(false);

  // редактирование лимита
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editLimit, setEditLimit] = useState("");
  const [editPeriod, setEditPeriod] = useState<"NONE" | "MONTHLY">("MONTHLY");

  const filteredModels = useMemo(() => {
    const query = modelFilter.trim().toLowerCase();
    if (!query) return models;
    return models.filter(
      (model) =>
        model.slug.toLowerCase().includes(query) || model.displayName.toLowerCase().includes(query),
    );
  }, [modelFilter, models]);

  function applyKey(updated: ApiKeyDto) {
    setKeys((current) => current.map((key) => (key.id === updated.id ? updated : key)));
  }

  async function createKey() {
    setCreating(true);
    setError(null);
    setNotice(null);

    try {
      const response = await fetch("/api/keys", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          name: name.trim() || "Новый ключ",
          limitRub: limitRub.trim() === "" ? null : Number(limitRub),
          limitPeriod,
          allowedModels,
          rpmLimit: Number(rpmLimit) || defaultRpm,
        }),
      });
      const data = (await response.json().catch(() => null)) as
        | { key: ApiKeyDto; plainKey: string; error?: string }
        | null;

      if (!response.ok || !data?.plainKey) {
        setError(data?.error ?? "Не удалось создать ключ");
        return;
      }

      setKeys((current) => [data.key, ...current]);
      setPlainKey(data.plainKey);
      setName("");
      setAllowedModels([]);
      setShowCreate(false);
      setNotice("Ключ создан. Скопируйте его сейчас — повторно он не отобразится.");
      router.refresh();
    } catch {
      setError("Сеть недоступна");
    } finally {
      setCreating(false);
    }
  }

  async function toggleStatus(key: ApiKeyDto) {
    setBusyId(key.id);
    setError(null);
    try {
      const response = await fetch(`/api/keys/${key.id}`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ status: key.status === "ACTIVE" ? "PAUSED" : "ACTIVE" }),
      });
      const data = (await response.json().catch(() => null)) as
        | { key: ApiKeyDto; error?: string }
        | null;
      if (!response.ok || !data?.key) {
        setError(data?.error ?? "Не удалось обновить ключ");
        return;
      }
      applyKey(data.key);
      router.refresh();
    } finally {
      setBusyId(null);
    }
  }

  async function saveLimit(key: ApiKeyDto) {
    setBusyId(key.id);
    setError(null);
    try {
      const response = await fetch(`/api/keys/${key.id}`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          limitRub: editLimit.trim() === "" ? null : Number(editLimit),
          limitPeriod: editPeriod,
        }),
      });
      const data = (await response.json().catch(() => null)) as
        | { key: ApiKeyDto; error?: string }
        | null;
      if (!response.ok || !data?.key) {
        setError(data?.error ?? "Не удалось сохранить лимит");
        return;
      }
      applyKey(data.key);
      setEditingId(null);
      router.refresh();
    } finally {
      setBusyId(null);
    }
  }

  async function revoke(key: ApiKeyDto) {
    if (!window.confirm(`Отозвать ключ «${key.name}»? Это действие необратимо.`)) return;
    setBusyId(key.id);
    setError(null);
    try {
      const response = await fetch(`/api/keys/${key.id}`, { method: "DELETE" });
      const data = (await response.json().catch(() => null)) as
        | { key: ApiKeyDto; error?: string }
        | null;
      if (!response.ok || !data?.key) {
        setError(data?.error ?? "Не удалось отозвать ключ");
        return;
      }
      applyKey(data.key);
      router.refresh();
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="space-y-6">
      {error ? <Alert tone="danger">{error}</Alert> : null}
      {notice ? <Alert tone="success">{notice}</Alert> : null}

      {plainKey ? (
        <Card className="border-brand-500/40 bg-brand-500/[0.07] p-5">
          <div className="text-sm font-medium text-white">
            Ваш новый API-ключ (показывается один раз)
          </div>
          <div className="mt-3 flex flex-wrap items-center gap-3">
            <code className="rounded-lg border border-white/10 bg-black/40 px-3 py-2 font-mono text-sm text-brand-200">
              {plainKey}
            </code>
            <CopyButton value={plainKey} label="Скопировать" />
            <Button size="sm" variant="ghost" onClick={() => setPlainKey(null)}>
              Скрыть
            </Button>
          </div>
          <p className="mt-3 text-xs text-slate-400">
            Хранится только хеш ключа — после закрытия этого блока восстановить его будет невозможно.
          </p>
        </Card>
      ) : null}

      <div className="flex items-center justify-between">
        <div className="text-sm text-slate-400">
          Всего ключей: {keys.length} · активных: {keys.filter((key) => key.status === "ACTIVE").length}
        </div>
        <Button size="sm" variant={showCreate ? "secondary" : "primary"} onClick={() => setShowCreate((value) => !value)}>
          {showCreate ? "Свернуть" : "Создать ключ"}
        </Button>
      </div>

      {showCreate ? (
        <Card className="p-6">
          <div className="grid gap-4 md:grid-cols-2">
            <Field label="Название" hint="Например: «Разработка», «Бот поддержки»">
              <Input value={name} onChange={(event) => setName(event.target.value)} placeholder="Новый ключ" />
            </Field>
            <Field label="Лимит расхода, ₽" hint="Пусто — без лимита">
              <Input
                value={limitRub}
                onChange={(event) => setLimitRub(event.target.value.replace(/[^\d.]/g, ""))}
                placeholder="1000"
                inputMode="decimal"
              />
            </Field>
            <Field label="Период лимита">
              <Select
                value={limitPeriod}
                onChange={(event) => setLimitPeriod(event.target.value as "NONE" | "MONTHLY")}
              >
                <option value="MONTHLY">Ежемесячно</option>
                <option value="NONE">За всё время</option>
              </Select>
            </Field>
            <Field label="Лимит запросов, RPM">
              <Input
                value={rpmLimit}
                onChange={(event) => setRpmLimit(event.target.value.replace(/[^\d]/g, ""))}
                inputMode="numeric"
              />
            </Field>
          </div>

          <div className="mt-4">
            <div className="mb-2 flex items-center justify-between">
              <div className="text-xs font-medium text-slate-400">
                Доступные модели{" "}
                <span className="text-slate-500">
                  ({allowedModels.length === 0 ? "все модели каталога" : `выбрано ${allowedModels.length}`})
                </span>
              </div>
              {allowedModels.length > 0 ? (
                <button
                  type="button"
                  className="text-xs text-brand-300 hover:text-brand-200"
                  onClick={() => setAllowedModels([])}
                >
                  Разрешить все
                </button>
              ) : null}
            </div>
            <Input
              value={modelFilter}
              onChange={(event) => setModelFilter(event.target.value)}
              placeholder="Фильтр по моделям…"
              className="mb-2"
            />
            <div className="max-h-48 space-y-1 overflow-y-auto rounded-xl border border-white/10 p-2">
              {filteredModels.map((model) => {
                const checked = allowedModels.includes(model.slug);
                return (
                  <label
                    key={model.id}
                    className="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-1.5 text-xs hover:bg-white/[0.04]"
                  >
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={(event) =>
                        setAllowedModels((current) =>
                          event.target.checked
                            ? [...current, model.slug]
                            : current.filter((slug) => slug !== model.slug),
                        )
                      }
                      className="h-3.5 w-3.5 accent-brand-500"
                    />
                    <span className="text-slate-300">{model.displayName}</span>
                    <span className="font-mono text-slate-500">{model.slug}</span>
                  </label>
                );
              })}
              {filteredModels.length === 0 ? (
                <div className="px-2 py-3 text-xs text-slate-500">Модели не найдены</div>
              ) : null}
            </div>
          </div>

          <div className="mt-5 flex justify-end gap-3">
            <Button variant="secondary" onClick={() => setShowCreate(false)}>
              Отмена
            </Button>
            <Button onClick={createKey} disabled={creating}>
              {creating ? "Создаём…" : "Создать ключ"}
            </Button>
          </div>
        </Card>
      ) : null}

      <div className="space-y-3">
        {keys.length === 0 ? (
          <Card className="px-6 py-12 text-center text-sm text-slate-500">
            Ключей пока нет — создайте первый, чтобы начать работу с API.
          </Card>
        ) : null}

        {keys.map((key) => {
          const limit = key.limitKopecks;
          const spent = key.spentKopecks;
          const progress = limit && limit > 0 ? Math.min(100, Math.round((spent / limit) * 100)) : 0;
          const isRevoked = key.status === "REVOKED";

          return (
            <Card key={key.id} className="p-5">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <div className="flex items-center gap-3">
                    <span className="font-medium text-white">{key.name}</span>
                    {key.status === "ACTIVE" ? <Badge tone="success">активен</Badge> : null}
                    {key.status === "PAUSED" ? <Badge tone="warning">на паузе</Badge> : null}
                    {isRevoked ? <Badge tone="danger">отозван</Badge> : null}
                  </div>
                  <div className="mt-1.5 font-mono text-xs text-slate-500">
                    {key.prefix}…{key.last4}
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  {!isRevoked ? (
                    <>
                      <Button
                        size="sm"
                        variant="secondary"
                        onClick={() => toggleStatus(key)}
                        disabled={busyId === key.id}
                      >
                        {key.status === "ACTIVE" ? "Приостановить" : "Возобновить"}
                      </Button>
                      <Button
                        size="sm"
                        variant="secondary"
                        onClick={() => {
                          setEditingId(editingId === key.id ? null : key.id);
                          setEditLimit(key.limitKopecks ? String(key.limitKopecks / 100) : "");
                          setEditPeriod(key.limitPeriod);
                        }}
                        disabled={busyId === key.id}
                      >
                        Лимит
                      </Button>
                      <Button
                        size="sm"
                        variant="danger"
                        onClick={() => revoke(key)}
                        disabled={busyId === key.id}
                      >
                        Отозвать
                      </Button>
                    </>
                  ) : null}
                </div>
              </div>

              {editingId === key.id ? (
                <div className="mt-4 flex flex-wrap items-end gap-3 rounded-xl border border-white/10 bg-white/[0.02] p-4">
                  <div className="w-40">
                    <Field label="Лимит, ₽">
                      <Input
                        value={editLimit}
                        onChange={(event) => setEditLimit(event.target.value.replace(/[^\d.]/g, ""))}
                        placeholder="Без лимита"
                        inputMode="decimal"
                      />
                    </Field>
                  </div>
                  <div className="w-40">
                    <Field label="Период">
                      <Select
                        value={editPeriod}
                        onChange={(event) => setEditPeriod(event.target.value as "NONE" | "MONTHLY")}
                      >
                        <option value="MONTHLY">Ежемесячно</option>
                        <option value="NONE">За всё время</option>
                      </Select>
                    </Field>
                  </div>
                  <Button size="sm" onClick={() => saveLimit(key)} disabled={busyId === key.id}>
                    Сохранить
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => setEditingId(null)}>
                    Отмена
                  </Button>
                </div>
              ) : null}

              <div className="mt-4 grid gap-4 text-xs text-slate-400 md:grid-cols-4">
                <div>
                  <div className="text-slate-500">Расход {PERIOD_LABELS[key.limitPeriod]}</div>
                  <div className="mt-1 text-sm text-slate-200">{formatRub(spent)}</div>
                </div>
                <div>
                  <div className="text-slate-500">Лимит</div>
                  <div className="mt-1 text-sm text-slate-200">
                    {limit === null ? "без лимита" : formatRub(limit)}
                  </div>
                </div>
                <div>
                  <div className="text-slate-500">Запросов в минуту</div>
                  <div className="mt-1 text-sm text-slate-200">{key.rpmLimit}</div>
                </div>
                <div>
                  <div className="flex items-center gap-1 text-slate-500">
                    <CalendarIcon /> Последнее использование
                  </div>
                  <div className="mt-1 text-sm text-slate-200">{formatDate(key.lastUsedAt)}</div>
                </div>
              </div>

              {limit !== null && limit > 0 ? (
                <div className="mt-4">
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/5">
                    <div
                      className={`h-full rounded-full ${progress >= 90 ? "bg-red-400" : "bg-brand-400"}`}
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                  <div className="mt-1 text-[11px] text-slate-500">
                    Использовано {progress}% лимита
                    {progress >= 100 ? " — ключ заблокирован до смены лимита" : ""}
                  </div>
                </div>
              ) : null}

              <div className="mt-4 flex flex-wrap items-center gap-3 border-t border-white/5 pt-3 text-xs text-slate-500">
                <span>Модели: {key.allowedModels.length === 0 ? "все" : key.allowedModels.join(", ")}</span>
                <span>·</span>
                <span>Создан: {formatDate(key.createdAt)}</span>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

function CalendarIcon() {
  return (
    <svg className="h-3 w-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <rect x="3" y="4" width="18" height="18" rx="2" />
      <path d="M16 2v4M8 2v4M3 10h18" />
    </svg>
  );
}
