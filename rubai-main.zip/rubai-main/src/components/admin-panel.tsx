"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Alert, Badge, Button, Card, Field, Input, Table, Td, Th, Tr } from "@/components/ui";
import { formatRub } from "@/lib/money";

export interface AdminUserRow {
  id: string;
  name: string;
  email: string;
  role: string;
  balanceKopecks: number;
  spendKopecks: number;
  keysCount: number;
  createdAt: string;
}

export function AdminPanel({
  settings,
  users,
}: {
  settings: {
    usdRubRate: number;
    markupPercent: number;
    modelsSyncedAt: string | null;
    rateSyncedAt: string | null;
  };
  users: AdminUserRow[];
}) {
  const router = useRouter();
  const [rate, setRate] = useState(String(settings.usdRubRate));
  const [markup, setMarkup] = useState(String(settings.markupPercent));
  const [message, setMessage] = useState<{ tone: "success" | "danger"; text: string } | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [deltas, setDeltas] = useState<Record<string, string>>({});

  function formatDate(value: string | null): string {
    if (!value) return "никогда";
    return new Intl.DateTimeFormat("ru-RU", { dateStyle: "short", timeStyle: "short" }).format(
      new Date(value),
    );
  }

  async function run(key: string, request: () => Promise<Response>, successText: (data: unknown) => string) {
    setBusy(key);
    setMessage(null);
    try {
      const response = await request();
      const data = await response.json().catch(() => null);
      if (!response.ok) {
        setMessage({ tone: "danger", text: (data as { error?: string })?.error ?? "Ошибка выполнения" });
        return;
      }
      setMessage({ tone: "success", text: successText(data) });
      router.refresh();
    } catch {
      setMessage({ tone: "danger", text: "Сеть недоступна" });
    } finally {
      setBusy(null);
    }
  }

  const syncModels = () =>
    run(
      "models",
      () => fetch("/api/admin/sync-models", { method: "POST" }),
      (data) => {
        const result = data as { total: number; created: number; updated: number };
        return `Каталог обновлён: всего ${result.total}, новых ${result.created}, обновлено ${result.updated}`;
      },
    );

  const syncRate = () =>
    run(
      "rate",
      () => fetch("/api/admin/sync-rate", { method: "POST" }),
      (data) => `Курс USD обновлён: ${(data as { usdRubRate: number }).usdRubRate} ₽`,
    );

  const saveSettings = () =>
    run(
      "settings",
      () =>
        fetch("/api/admin/settings", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ usdRubRate: Number(rate), markupPercent: Number(markup) }),
        }),
      () => "Настройки цен сохранены",
    );

  async function adjustBalance(userId: string) {
    const value = Number(deltas[userId]);
    if (!Number.isFinite(value) || value === 0) {
      setMessage({ tone: "danger", text: "Укажите сумму корректировки (может быть отрицательной)" });
      return;
    }

    await run(
      `user:${userId}`,
      () =>
        fetch(`/api/admin/users/${userId}/balance`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ deltaRub: value, description: "Корректировка из админки" }),
        }),
      () => "Баланс пользователя обновлён",
    );
    setDeltas((current) => ({ ...current, [userId]: "" }));
  }

  return (
    <div className="space-y-6">
      {message ? <Alert tone={message.tone}>{message.text}</Alert> : null}

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="p-6">
          <div className="font-medium text-white">Синхронизация данных</div>
          <div className="mt-1 text-xs text-slate-500">
            Каталог моделей: {formatDate(settings.modelsSyncedAt)} · Курс ЦБ:{" "}
            {formatDate(settings.rateSyncedAt)}
          </div>
          <div className="mt-5 flex flex-wrap gap-3">
            <Button onClick={syncModels} disabled={busy !== null}>
              {busy === "models" ? "Синхронизируем…" : "Обновить каталог моделей"}
            </Button>
            <Button variant="secondary" onClick={syncRate} disabled={busy !== null}>
              {busy === "rate" ? "Обновляем…" : "Обновить курс ЦБ"}
            </Button>
          </div>
        </Card>

        <Card className="p-6">
          <div className="font-medium text-white">Курс и наценка</div>
          <div className="mt-1 text-xs text-slate-500">
            Применяются ко всем новым запросам. Для каждого запроса значения сохраняются в журнале.
          </div>
          <div className="mt-5 grid gap-4 sm:grid-cols-2">
            <Field label="Курс USD, ₽">
              <Input
                value={rate}
                onChange={(event) => setRate(event.target.value.replace(/[^\d.,]/g, ""))}
                inputMode="decimal"
              />
            </Field>
            <Field label="Наценка, %">
              <Input
                value={markup}
                onChange={(event) => setMarkup(event.target.value.replace(/[^\d.,]/g, ""))}
                inputMode="decimal"
              />
            </Field>
          </div>
          <Button className="mt-4" onClick={saveSettings} disabled={busy !== null}>
            {busy === "settings" ? "Сохраняем…" : "Сохранить"}
          </Button>
        </Card>
      </div>

      <Card className="overflow-hidden">
        <div className="px-5 py-4 font-medium text-white">Пользователи</div>
        <Table className="min-w-[820px]">
          <thead>
            <tr>
              <Th>Пользователь</Th>
              <Th>Роль</Th>
              <Th className="text-right">Баланс</Th>
              <Th className="text-right">Расход</Th>
              <Th className="text-right">Ключей</Th>
              <Th>Регистрация</Th>
              <Th className="text-right">Корректировка, ₽</Th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <Tr key={user.id}>
                <Td>
                  <div className="text-sm text-slate-100">{user.name}</div>
                  <div className="text-xs text-slate-500">{user.email}</div>
                </Td>
                <Td>
                  {user.role === "ADMIN" ? <Badge tone="brand">admin</Badge> : <Badge>user</Badge>}
                </Td>
                <Td className="text-right text-xs">{formatRub(user.balanceKopecks)}</Td>
                <Td className="text-right text-xs">{formatRub(user.spendKopecks)}</Td>
                <Td className="text-right text-xs">{user.keysCount}</Td>
                <Td className="text-xs text-slate-400">
                  {new Intl.DateTimeFormat("ru-RU", { dateStyle: "short" }).format(
                    new Date(user.createdAt),
                  )}
                </Td>
                <Td>
                  <div className="flex items-center justify-end gap-2">
                    <Input
                      value={deltas[user.id] ?? ""}
                      onChange={(event) =>
                        setDeltas((current) => ({ ...current, [user.id]: event.target.value }))
                      }
                      placeholder="+500 / -100"
                      className="h-8 w-28 text-xs"
                    />
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() => adjustBalance(user.id)}
                      disabled={busy === `user:${user.id}`}
                    >
                      Применить
                    </Button>
                  </div>
                </Td>
              </Tr>
            ))}
          </tbody>
        </Table>
      </Card>
    </div>
  );
}
