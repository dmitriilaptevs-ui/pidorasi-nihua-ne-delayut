"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  BarChart3,
  BookOpen,
  Boxes,
  KeyRound,
  LayoutDashboard,
  Settings,
  Shield,
  Wallet,
} from "lucide-react";
import clsx from "clsx";

const items = [
  { href: "/dashboard", label: "Обзор", icon: LayoutDashboard, exact: true },
  { href: "/dashboard/keys", label: "API-ключи", icon: KeyRound },
  { href: "/dashboard/billing", label: "Пополнение", icon: Wallet },
  { href: "/dashboard/usage", label: "Статистика", icon: BarChart3 },
  { href: "/dashboard/models", label: "Модели", icon: Boxes },
  { href: "/dashboard/docs", label: "Документация", icon: BookOpen },
  { href: "/dashboard/settings", label: "Настройки", icon: Settings },
];

export function DashboardNav({ isAdmin }: { isAdmin: boolean }) {
  const pathname = usePathname();

  const allItems = isAdmin
    ? [...items, { href: "/dashboard/admin", label: "Админка", icon: Shield, exact: false }]
    : items;

  return (
    <nav className="flex gap-1 overflow-x-auto pb-2 lg:flex-col lg:overflow-visible lg:pb-0">
      {allItems.map((item) => {
        const active = item.exact ? pathname === item.href : pathname.startsWith(item.href);
        const Icon = item.icon;
        return (
          <Link
            key={item.href}
            href={item.href}
            className={clsx(
              "flex shrink-0 items-center gap-2.5 rounded-xl px-3 py-2 text-sm transition",
              active
                ? "bg-brand-500/15 text-white"
                : "text-slate-400 hover:bg-white/[0.05] hover:text-slate-200",
            )}
          >
            <Icon className="h-4 w-4" />
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}
