import { CopyButton } from "./copy-button";

export function CodeBlock({
  code,
  title,
  className,
}: {
  code: string;
  title?: string;
  className?: string;
}) {
  return (
    <div className={`overflow-hidden rounded-2xl border border-white/10 bg-black/40 ${className ?? ""}`}>
      <div className="flex items-center justify-between border-b border-white/5 px-4 py-2">
        <span className="text-xs font-medium text-slate-500">{title ?? "shell"}</span>
        <CopyButton value={code} label="Копировать" />
      </div>
      <pre className="overflow-x-auto p-4 font-mono text-[13px] leading-relaxed text-slate-300">
        <code>{code}</code>
      </pre>
    </div>
  );
}
