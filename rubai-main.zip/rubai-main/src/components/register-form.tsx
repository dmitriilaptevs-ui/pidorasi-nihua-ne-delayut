"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { Alert, Button, Field, Input } from "@/components/ui";

export function RegisterForm() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [consent, setConsent] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function submit(event: FormEvent) {
    event.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ name, email, password, consent }),
      });
      const data = (await response.json().catch(() => null)) as { error?: string } | null;

      if (!response.ok) {
        setError(data?.error ?? "Не удалось зарегистрироваться");
        setLoading(false);
        return;
      }

      router.push("/dashboard");
      router.refresh();
    } catch {
      setError("Сеть недоступна. Попробуйте ещё раз.");
      setLoading(false);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      {error ? <Alert tone="danger">{error}</Alert> : null}

      <Field label="Имя">
        <Input
          value={name}
          onChange={(event) => setName(event.target.value)}
          placeholder="Как к вам обращаться"
          autoComplete="name"
          required
          minLength={2}
        />
      </Field>

      <Field label="Email">
        <Input
          type="email"
          value={email}
          onChange={(event) => setEmail(event.target.value)}
          placeholder="you@example.com"
          autoComplete="email"
          required
        />
      </Field>

      <Field label="Пароль" hint="Минимум 8 символов">
        <Input
          type="password"
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          placeholder="••••••••"
          autoComplete="new-password"
          required
          minLength={8}
        />
      </Field>

      <label className="flex items-start gap-3 text-xs leading-relaxed text-slate-400">
        <input
          type="checkbox"
          checked={consent}
          onChange={(event) => setConsent(event.target.checked)}
          className="mt-0.5 h-4 w-4 rounded border-white/20 bg-white/10 accent-brand-500"
          required
        />
        <span>
          Я согласен на обработку персональных данных и принимаю{" "}
          <Link href="/legal/terms" className="text-brand-300 hover:text-brand-200">
            пользовательское соглашение
          </Link>{" "}
          и{" "}
          <Link href="/legal/privacy" className="text-brand-300 hover:text-brand-200">
            политику конфиденциальности
          </Link>
          .
        </span>
      </label>

      <Button type="submit" className="w-full" disabled={loading || !consent}>
        {loading ? "Создаём аккаунт…" : "Создать аккаунт"}
      </Button>

      <p className="text-center text-sm text-slate-500">
        Уже есть аккаунт?{" "}
        <Link href="/login" className="text-brand-300 transition hover:text-brand-200">
          Войти
        </Link>
      </p>
    </form>
  );
}
