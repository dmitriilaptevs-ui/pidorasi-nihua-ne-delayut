"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Alert, Button, Card, Field, Input } from "@/components/ui";

const PRESETS = [500, 1000, 5000, 10000];

export function TopupForm({ mock }: { mock: boolean }) {
  const router = useRouter();
  const [amount, setAmount] = useState(1000);
  const [custom, setCustom] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [pending, setPending] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  const finalAmount = custom.trim() ? Number(custom) : amount;

  async function createPayment() {
    if (!Number.isFinite(finalAmount) || finalAmount < 100) {
      setError("Минимальная сумма пополнения — 100 ₽");
      return;
    }

    setLoading(true);
    setError(null);
    setDone(false);

    try {
      const response = await fetch("/api/billing/topup", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ amountRub: Math.round(finalAmount) }),
      });
      const data = (await response.json().catch(() => null)) as
        | { paymentId: string; mock: boolean; confirmationUrl: string | null; error?: string }
        | null;

      if (!response.ok || !data) {
        setError(data?.error ?? "Не удалось создать платёж");
        return;
      }

      if (data.mock) {
        setPending(data.paymentId);
      } else if (data.confirmationUrl) {
        window.location.href = data.confirmationUrl;
      } else {
        setError("Платёжный провайдер не вернул ссылку на оплату");
      }
    } catch {
      setError("Сеть недоступна. Попробуйте ещё раз.");
    } finally {
      setLoading(false);
    }
  }

  async function confirmMock() {
    if (!pending) return;
    setLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/billing/mock-pay", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ paymentId: pending }),
      });
      const data = (await response.json().catch(() => null)) as { error?: string } | null;

      if (!response.ok) {
        setError(data?.error ?? "Не удалось зачислить средства");
        return;
      }

      setPending(null);
      setDone(true);
      router.refresh();
    } catch {
      setError("Сеть недоступна");
    } finally {
      setLoading(false);
    }
  }

  return (
    <Card className="p-6">
      <div className="font-medium text-white">Пополнить баланс</div>
      <div className="mt-1 text-xs text-slate-500">
        {mock
          ? "Включён тестовый режим оплаты: средства зачисляются без реального платежа."
          : "Оплата проходит через ЮKassa: банковская карта или СБП."}
      </div>

      {error ? (
        <div className="mt-4">
          <Alert tone="danger">{error}</Alert>
        </div>
      ) : null}
      {done ? (
        <div className="mt-4">
          <Alert tone="success">Баланс пополнен. Хорошей работы!</Alert>
        </div>
      ) : null}

      <div className="mt-5 grid grid-cols-2 gap-2 sm:grid-cols-4">
        {PRESETS.map((preset) => (
          <button
            key={preset}
            type="button"
            onClick={() => {
              setAmount(preset);
              setCustom("");
            }}
            className={`rounded-xl border px-3 py-2.5 text-sm transition ${
              !custom && amount === preset
                ? "border-brand-500/60 bg-brand-500/15 text-white"
                : "border-white/10 bg-white/[0.03] text-slate-300 hover:bg-white/[0.06]"
            }`}
          >
            {preset.toLocaleString("ru-RU")} ₽
          </button>
        ))}
      </div>

      <div className="mt-4">
        <Field label="Или своя сумма, ₽" hint="Минимум 100 ₽, максимум 1 000 000 ₽">
          <Input
            value={custom}
            onChange={(event) => setCustom(event.target.value.replace(/[^\d]/g, ""))}
            placeholder="1500"
            inputMode="numeric"
          />
        </Field>
      </div>

      {pending ? (
        <div className="mt-5 space-y-3 rounded-xl border border-amber-500/25 bg-amber-500/10 p-4">
          <div className="text-sm text-amber-100">
            Тестовый платёж на {(custom ? Number(custom) : amount).toLocaleString("ru-RU")} ₽ создан.
            Подтвердите его, чтобы зачислить средства.
          </div>
          <Button onClick={confirmMock} disabled={loading}>
            {loading ? "Зачисляем…" : "Подтвердить оплату (тест)"}
          </Button>
        </div>
      ) : (
        <Button className="mt-5 w-full" onClick={createPayment} disabled={loading}>
          {loading
            ? "Создаём платёж…"
            : mock
              ? "Создать тестовый платёж"
              : "Перейти к оплате"}
        </Button>
      )}
    </Card>
  );
}
