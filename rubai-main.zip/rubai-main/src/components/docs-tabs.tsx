"use client";

import { useState } from "react";
import { CodeBlock } from "@/components/code-block";
import { Card } from "@/components/ui";

const TABS = ["Python", "Node.js", "curl", "Cursor", "Cline", "OpenCode"] as const;
type Tab = (typeof TABS)[number];

export function DocsTabs({ baseUrl }: { baseUrl: string }) {
  const [tab, setTab] = useState<Tab>("Python");

  const python = `from openai import OpenAI

client = OpenAI(
    api_key="sk-rubai-ВАШ_КЛЮЧ",
    base_url="${baseUrl}/v1",
)

response = client.chat.completions.create(
    model="openai/gpt-4o-mini",
    messages=[{"role": "user", "content": "Привет!"}],
)
print(response.choices[0].message.content)`;

  const pythonStream = `stream = client.chat.completions.create(
    model="anthropic/claude-3.5-sonnet",
    messages=[{"role": "user", "content": "Напиши функцию на Python"}],
    stream=True,
)
for chunk in stream:
    print(chunk.choices[0].delta.content or "", end="")`;

  const node = `import OpenAI from "openai";

const client = new OpenAI({
  apiKey: "sk-rubai-ВАШ_КЛЮЧ",
  baseURL: "${baseUrl}/v1",
});

const response = await client.chat.completions.create({
  model: "openai/gpt-4o-mini",
  messages: [{ role: "user", content: "Привет!" }],
});

console.log(response.choices[0].message.content);`;

  const curl = `curl ${baseUrl}/v1/chat/completions \\
  -H "Authorization: Bearer sk-rubai-ВАШ_КЛЮЧ" \\
  -H "Content-Type: application/json" \\
  -d '{
    "model": "openai/gpt-4o-mini",
    "messages": [{"role": "user", "content": "Привет!"}]
  }'

# Список доступных моделей
curl ${baseUrl}/v1/models \\
  -H "Authorization: Bearer sk-rubai-ВАШ_КЛЮЧ"`;

  const cursorSteps = [
    "Откройте Cursor → Settings → Models.",
    "Включите OpenAI API Key и вставьте ключ sk-rubai-…",
    "В поле Override OpenAI Base URL укажите адрес ниже.",
    "Добавьте нужные модели (например, openai/gpt-4o-mini) в список Custom Models.",
  ];

  const clineSteps = [
    "Откройте настройки Cline → API Configuration.",
    "Выберите API Provider: OpenAI Compatible.",
    "Base URL: адрес ниже. API Key: ваш ключ rubai.",
    "Model ID: точный slug модели из каталога, например anthropic/claude-3.5-sonnet.",
  ];

  const openCodeConfig = `{
  "$schema": "https://opencode.ai/config.json",
  "provider": {
    "rubai": {
      "npm": "@ai-sdk/openai-compatible",
      "name": "rubai",
      "options": {
        "baseURL": "${baseUrl}/v1",
        "apiKey": "sk-rubai-ВАШ_КЛЮЧ"
      },
      "models": {
        "openai/gpt-4o-mini": { "name": "GPT-4o mini" },
        "anthropic/claude-3.5-sonnet": { "name": "Claude 3.5 Sonnet" }
      }
    }
  }
}`;

  return (
    <div>
      <div className="mb-6 flex flex-wrap gap-2">
        {TABS.map((item) => (
          <button
            key={item}
            type="button"
            onClick={() => setTab(item)}
            className={`rounded-xl px-3.5 py-2 text-sm transition ${
              tab === item
                ? "bg-brand-600 text-white"
                : "border border-white/10 bg-white/[0.03] text-slate-300 hover:bg-white/[0.07]"
            }`}
          >
            {item}
          </button>
        ))}
      </div>

      <Card className="p-6">
        {tab === "Python" ? (
          <div className="space-y-5">
            <div>
              <h3 className="font-medium text-white">Установка SDK</h3>
              <CodeBlock className="mt-3" title="shell" code={"pip install openai"} />
            </div>
            <div>
              <h3 className="font-medium text-white">Обычный запрос</h3>
              <CodeBlock className="mt-3" title="python" code={python} />
            </div>
            <div>
              <h3 className="font-medium text-white">Стриминг ответа</h3>
              <CodeBlock className="mt-3" title="python" code={pythonStream} />
            </div>
          </div>
        ) : null}

        {tab === "Node.js" ? (
          <div className="space-y-5">
            <div>
              <h3 className="font-medium text-white">Установка SDK</h3>
              <CodeBlock className="mt-3" title="shell" code={"npm install openai"} />
            </div>
            <div>
              <h3 className="font-medium text-white">Запрос к модели</h3>
              <CodeBlock className="mt-3" title="javascript" code={node} />
            </div>
          </div>
        ) : null}

        {tab === "curl" ? (
          <div className="space-y-5">
            <h3 className="font-medium text-white">Проверка из терминала</h3>
            <CodeBlock title="bash" code={curl} />
          </div>
        ) : null}

        {tab === "Cursor" ? (
          <div className="space-y-4">
            <ol className="list-decimal space-y-2 pl-5 text-sm text-slate-300">
              {cursorSteps.map((step) => (
                <li key={step}>{step}</li>
              ))}
            </ol>
            <CodeBlock title="base url" code={`${baseUrl}/v1`} />
          </div>
        ) : null}

        {tab === "Cline" ? (
          <div className="space-y-4">
            <ol className="list-decimal space-y-2 pl-5 text-sm text-slate-300">
              {clineSteps.map((step) => (
                <li key={step}>{step}</li>
              ))}
            </ol>
            <CodeBlock title="base url" code={`${baseUrl}/v1`} />
          </div>
        ) : null}

        {tab === "OpenCode" ? (
          <div className="space-y-4">
            <p className="text-sm text-slate-400">
              Добавьте провайдера rubai в конфигурацию OpenCode:
            </p>
            <CodeBlock title="opencode.json" code={openCodeConfig} />
          </div>
        ) : null}
      </Card>
    </div>
  );
}
