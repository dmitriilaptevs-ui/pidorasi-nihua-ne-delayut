import { formatRub } from "@/lib/money";

/** Простая столбчатая диаграмма без внешних зависимостей. */
export function BarChart({
  data,
  height = 140,
  formatValue,
}: {
  data: Array<{ label: string; value: number }>;
  height?: number;
  formatValue?: (value: number) => string;
}) {
  if (data.length === 0) {
    return (
      <div className="flex h-36 items-center justify-center text-xs text-slate-500">
        Пока нет данных за выбранный период
      </div>
    );
  }

  const max = Math.max(1, ...data.map((point) => point.value));
  const format = formatValue ?? ((value: number) => formatRub(value));

  return (
    <div>
      <div className="flex items-end gap-1.5" style={{ height }}>
        {data.map((point, index) => (
          <div
            key={index}
            className="group relative flex h-full flex-1 items-end"
            title={`${point.label}: ${format(point.value)}`}
          >
            <div
              className="w-full rounded-t-md bg-gradient-to-t from-brand-600/40 to-brand-400/90 transition group-hover:from-brand-500 group-hover:to-brand-300"
              style={{ height: `${Math.max(3, (point.value / max) * 100)}%` }}
            />
          </div>
        ))}
      </div>
      <div className="mt-2 flex justify-between text-[11px] text-slate-500">
        <span>{data[0]?.label}</span>
        <span>{data[data.length - 1]?.label}</span>
      </div>
    </div>
  );
}
