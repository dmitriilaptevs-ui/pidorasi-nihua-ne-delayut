import { NextResponse } from "next/server";
import type { User } from "@prisma/client";
import { getCurrentUser } from "./auth";

type ApiResult = { user: User } | { response: Response };

export async function apiUser(): Promise<ApiResult> {
  const user = await getCurrentUser();
  if (!user) {
    return { response: NextResponse.json({ error: "Требуется авторизация" }, { status: 401 }) };
  }
  return { user };
}

export async function apiAdmin(): Promise<ApiResult> {
  const result = await apiUser();
  if ("response" in result) return result;
  if (result.user.role !== "ADMIN") {
    return { response: NextResponse.json({ error: "Недостаточно прав" }, { status: 403 }) };
  }
  return result;
}
