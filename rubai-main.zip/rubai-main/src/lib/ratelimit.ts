/**
 * Простейший rate limit в памяти процесса (скользящее окно).
 * Для MVP с одним инстансом приложения этого достаточно;
 * при масштабировании заменяется на Redis.
 */

const buckets = new Map<string, number[]>();
let lastSweep = 0;

export interface RateLimitResult {
  ok: boolean;
  remaining: number;
  retryAfterSec: number;
}

export function checkRateLimit(id: string, limit: number, windowMs = 60_000): RateLimitResult {
  const now = Date.now();

  if (now - lastSweep > 5 * 60_000) {
    lastSweep = now;
    for (const [key, stamps] of buckets) {
      const fresh = stamps.filter((t) => now - t < windowMs);
      if (fresh.length === 0) buckets.delete(key);
      else buckets.set(key, fresh);
    }
  }

  const stamps = (buckets.get(id) ?? []).filter((t) => now - t < windowMs);

  if (stamps.length >= limit) {
    buckets.set(id, stamps);
    const oldest = stamps[0] ?? now;
    const retryAfterSec = Math.max(1, Math.ceil((windowMs - (now - oldest)) / 1000));
    return { ok: false, remaining: 0, retryAfterSec };
  }

  stamps.push(now);
  buckets.set(id, stamps);
  return { ok: true, remaining: limit - stamps.length, retryAfterSec: 0 };
}

export function resetRateLimits(): void {
  buckets.clear();
}
