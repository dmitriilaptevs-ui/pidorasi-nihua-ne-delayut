import { randomUUID } from "node:crypto";
import { env } from "./env";

const YOOKASSA_API = "https://api.yookassa.ru/v3";

export interface YooKassaPayment {
  id: string;
  status: string;
  paid: boolean;
  amountValue: string;
  confirmationUrl?: string;
  metadata: Record<string, string>;
}

function authHeader(): string {
  const credentials = `${env.yookassaShopId}:${env.yookassaSecretKey}`;
  return `Basic ${Buffer.from(credentials, "utf8").toString("base64")}`;
}

function ensureConfigured(): void {
  if (!env.yookassaShopId || !env.yookassaSecretKey) {
    throw new Error("ЮKassa не настроена: задайте YOOKASSA_SHOP_ID и YOOKASSA_SECRET_KEY");
  }
}

function mapPayment(json: Record<string, unknown>): YooKassaPayment {
  const confirmation = json.confirmation as { confirmation_url?: string } | undefined;
  return {
    id: String(json.id ?? ""),
    status: String(json.status ?? ""),
    paid: Boolean(json.paid),
    amountValue: String((json.amount as { value?: string } | undefined)?.value ?? ""),
    confirmationUrl: confirmation?.confirmation_url,
    metadata: (json.metadata as Record<string, string> | undefined) ?? {},
  };
}

export async function createYooKassaPayment(params: {
  amountKopecks: bigint;
  description: string;
  returnUrl: string;
  metadata: Record<string, string>;
}): Promise<YooKassaPayment> {
  ensureConfigured();

  const response = await fetch(`${YOOKASSA_API}/payments`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      authorization: authHeader(),
      "Idempotence-Key": randomUUID(),
    },
    body: JSON.stringify({
      amount: {
        value: (Number(params.amountKopecks) / 100).toFixed(2),
        currency: "RUB",
      },
      capture: true,
      confirmation: {
        type: "redirect",
        return_url: params.returnUrl,
      },
      description: params.description,
      metadata: params.metadata,
    }),
    signal: AbortSignal.timeout(20_000),
  });

  const json = (await response.json().catch(() => ({}))) as Record<string, unknown>;
  if (!response.ok) {
    throw new Error(`ЮKassa: ${String((json as { description?: string }).description ?? `ошибка ${response.status}`)}`);
  }
  return mapPayment(json);
}

export async function getYooKassaPayment(paymentId: string): Promise<YooKassaPayment> {
  ensureConfigured();

  const response = await fetch(`${YOOKASSA_API}/payments/${encodeURIComponent(paymentId)}`, {
    headers: { authorization: authHeader() },
    signal: AbortSignal.timeout(20_000),
  });

  const json = (await response.json().catch(() => ({}))) as Record<string, unknown>;
  if (!response.ok) {
    throw new Error(`ЮKassa: ${String((json as { description?: string }).description ?? `ошибка ${response.status}`)}`);
  }
  return mapPayment(json);
}
