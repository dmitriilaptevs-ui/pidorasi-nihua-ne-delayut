import { SETTING_KEYS, setSetting } from "./settings";

/** Загружает официальный курс USD с сайта ЦБ РФ и сохраняет его в настройках. */
export async function syncUsdRate(): Promise<number> {
  const response = await fetch("https://www.cbr.ru/scripts/XML_daily.asp", {
    signal: AbortSignal.timeout(15_000),
  });
  if (!response.ok) {
    throw new Error(`ЦБ РФ: HTTP ${response.status}`);
  }

  const xml = await response.text();
  const match = xml.match(/<CharCode>USD<\/CharCode>[\s\S]{0,300}?<Value>([\d,]+)<\/Value>/);
  if (!match) {
    throw new Error("Не удалось разобрать курс USD в ответе ЦБ РФ");
  }

  const rate = Number(match[1].replace(",", "."));
  if (!Number.isFinite(rate) || rate <= 0) {
    throw new Error("ЦБ РФ вернул некорректный курс USD");
  }

  await setSetting(SETTING_KEYS.usdRubRate, String(rate));
  await setSetting(SETTING_KEYS.rateSyncedAt, new Date().toISOString());
  return rate;
}
