import { createHash, randomBytes } from "node:crypto";
import type { ApiKey, User } from "@prisma/client";
import { prisma } from "./db";

export const API_KEY_PREFIX = "sk-rubai-";

export interface GeneratedApiKey {
  plain: string;
  hash: string;
  prefix: string;
  last4: string;
}

export function generateApiKey(): GeneratedApiKey {
  const secret = randomBytes(24).toString("hex");
  const plain = API_KEY_PREFIX + secret;
  return {
    plain,
    hash: hashApiKey(plain),
    prefix: plain.slice(0, API_KEY_PREFIX.length + 4),
    last4: plain.slice(-4),
  };
}

export function hashApiKey(plain: string): string {
  return createHash("sha256").update(plain).digest("hex");
}

/** Маска для отображения: sk-rubai-a1b2…ef90 */
export function maskApiKey(key: Pick<ApiKey, "keyPrefix" | "last4">): string {
  return `${key.keyPrefix}…${key.last4}`;
}

export function extractBearerToken(req: Request): string | null {
  const header = req.headers.get("authorization");
  if (header) {
    const match = header.match(/^Bearer\s+(.+)$/i);
    if (match) return match[1].trim();
  }
  const xApiKey = req.headers.get("x-api-key");
  return xApiKey?.trim() || null;
}

export type ApiKeyWithUser = ApiKey & { user: User };

/**
 * Находит ключ по значению. Отозванные ключи не проходят;
 * приостановленные возвращаются, чтобы отдать понятную ошибку 403.
 */
export async function authenticateApiKey(token: string): Promise<ApiKeyWithUser | null> {
  if (!token.startsWith(API_KEY_PREFIX)) return null;
  const key = await prisma.apiKey.findUnique({
    where: { keyHash: hashApiKey(token) },
    include: { user: true },
  });
  if (!key || key.status === "REVOKED") return null;
  return key;
}
