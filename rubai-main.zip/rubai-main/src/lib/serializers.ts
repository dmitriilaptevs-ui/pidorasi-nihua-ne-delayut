import type { ApiKey, Model, Payment, UsageLog } from "@prisma/client";
import { kopecksToRub } from "./money";

export interface ApiKeyDto {
  id: string;
  name: string;
  prefix: string;
  last4: string;
  status: "ACTIVE" | "PAUSED" | "REVOKED";
  limitKopecks: number | null;
  limitPeriod: "NONE" | "MONTHLY";
  allowedModels: string[];
  rpmLimit: number;
  lastUsedAt: string | null;
  createdAt: string;
  spentKopecks: number;
}

export function serializeApiKey(key: ApiKey, spentKopecks: bigint): ApiKeyDto {
  return {
    id: key.id,
    name: key.name,
    prefix: key.keyPrefix,
    last4: key.last4,
    status: key.status,
    limitKopecks: key.limitKopecks === null ? null : Number(key.limitKopecks),
    limitPeriod: key.limitPeriod,
    allowedModels: key.allowedModels,
    rpmLimit: key.rpmLimit,
    lastUsedAt: key.lastUsedAt?.toISOString() ?? null,
    createdAt: key.createdAt.toISOString(),
    spentKopecks: Number(spentKopecks),
  };
}

export interface ModelDto {
  id: string;
  slug: string;
  displayName: string;
  provider: string;
  description: string | null;
  contextLength: number | null;
  inputRubPerM: number;
  outputRubPerM: number;
  cachedRubPerM: number;
  inputUsdPerM: number;
  outputUsdPerM: number;
  modality: string;
  inputModalities: string[];
  outputModalities: string[];
  isActive: boolean;
  isFeatured: boolean;
}

export function serializeModel(model: Model, price: { usdRubRate: number; markupPercent: number }): ModelDto {
  const multiplier = price.usdRubRate * (1 + price.markupPercent / 100);
  const toRub = (usdPerM: number) => Math.round(usdPerM * multiplier * 100) / 100;

  return {
    id: model.id,
    slug: model.slug,
    displayName: model.displayName,
    provider: model.provider,
    description: model.description,
    contextLength: model.contextLength,
    inputRubPerM: toRub(model.inputUsdPerM),
    outputRubPerM: toRub(model.outputUsdPerM),
    cachedRubPerM: toRub(model.cachedUsdPerM),
    inputUsdPerM: model.inputUsdPerM,
    outputUsdPerM: model.outputUsdPerM,
    modality: model.modality,
    inputModalities: model.inputModalities,
    outputModalities: model.outputModalities,
    isActive: model.isActive,
    isFeatured: model.isFeatured,
  };
}

export interface PaymentDto {
  id: string;
  amountKopecks: number;
  status: "PENDING" | "SUCCEEDED" | "CANCELED";
  provider: string;
  createdAt: string;
  paidAt: string | null;
  confirmationUrl: string | null;
}

export function serializePayment(payment: Payment): PaymentDto {
  return {
    id: payment.id,
    amountKopecks: Number(payment.amountKopecks),
    status: payment.status,
    provider: payment.provider,
    createdAt: payment.createdAt.toISOString(),
    paidAt: payment.paidAt?.toISOString() ?? null,
    confirmationUrl: payment.confirmationUrl,
  };
}

export interface UsageLogDto {
  id: string;
  modelSlug: string;
  endpoint: string;
  promptTokens: number;
  completionTokens: number;
  cachedTokens: number;
  totalTokens: number;
  costKopecks: number;
  status: string;
  httpStatus: number;
  latencyMs: number;
  streamed: boolean;
  requestId: string;
  createdAt: string;
  apiKeyId: string | null;
}

export function serializeUsageLog(log: UsageLog): UsageLogDto {
  return {
    id: log.id,
    modelSlug: log.modelSlug,
    endpoint: log.endpoint,
    promptTokens: log.promptTokens,
    completionTokens: log.completionTokens,
    cachedTokens: log.cachedTokens,
    totalTokens: log.totalTokens,
    costKopecks: Number(log.costKopecks),
    status: log.status,
    httpStatus: log.httpStatus,
    latencyMs: log.latencyMs,
    streamed: log.streamed,
    requestId: log.requestId,
    createdAt: log.createdAt.toISOString(),
    apiKeyId: log.apiKeyId,
  };
}

export function balanceRub(user: { balanceKopecks: bigint }): number {
  return kopecksToRub(user.balanceKopecks);
}
