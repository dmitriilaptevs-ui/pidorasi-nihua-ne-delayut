const rubFormatter = new Intl.NumberFormat("ru-RU", {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

const tokenFormatter = new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 0 });

/** Форматирует копейки в строку вида «1 234,56 ₽». */
export function formatRub(kopecks: bigint | number | null | undefined, options: { signed?: boolean } = {}): string {
  const value = typeof kopecks === "bigint" ? Number(kopecks) : (kopecks ?? 0);
  const rub = value / 100;
  const formatted = rubFormatter.format(Math.abs(rub));
  if (options.signed && value !== 0) {
    return `${value > 0 ? "+" : "−"}${formatted} ₽`;
  }
  return `${value < 0 ? "−" : ""}${formatted} ₽`;
}

/** Форматирует число без копеек, например «350 ₽». */
export function formatRubWhole(kopecks: bigint | number | null | undefined): string {
  const value = typeof kopecks === "bigint" ? Number(kopecks) : (kopecks ?? 0);
  return `${tokenFormatter.format(Math.round(value / 100))} ₽`;
}

export function kopecksToRub(kopecks: bigint | number): number {
  return (typeof kopecks === "bigint" ? Number(kopecks) : kopecks) / 100;
}

export function rubToKopecks(rub: number): bigint {
  return BigInt(Math.round(rub * 100));
}

export function formatTokens(tokens: number | bigint | null | undefined): string {
  const value = typeof tokens === "bigint" ? Number(tokens) : (tokens ?? 0);
  return tokenFormatter.format(value);
}

export function formatUsdPerM(usdPerM: number): string {
  if (usdPerM === 0) return "0";
  if (usdPerM < 1) return `$${usdPerM.toFixed(2)}`;
  return `$${usdPerM.toFixed(usdPerM < 10 ? 2 : 1)}`;
}
