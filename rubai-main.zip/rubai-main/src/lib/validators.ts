import { z } from "zod";

export const registerSchema = z.object({
  name: z.string().trim().min(2, "Укажите имя").max(80),
  email: z.string().trim().toLowerCase().email("Некорректный email").max(200),
  password: z.string().min(8, "Пароль должен быть не короче 8 символов").max(200),
  consent: z.literal(true, { errorMap: () => ({ message: "Необходимо согласие на обработку персональных данных" }) }),
});

export const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email("Некорректный email"),
  password: z.string().min(1, "Введите пароль"),
});

export const createKeySchema = z.object({
  name: z.string().trim().min(1, "Укажите название ключа").max(60),
  limitRub: z.number().min(0).max(100_000_000).nullable().optional(),
  limitPeriod: z.enum(["NONE", "MONTHLY"]).default("NONE"),
  allowedModels: z.array(z.string().trim().min(1)).max(500).default([]),
  rpmLimit: z.number().int().min(1).max(100_000).optional(),
});

export const updateKeySchema = z.object({
  name: z.string().trim().min(1).max(60).optional(),
  limitRub: z.number().min(0).max(100_000_000).nullable().optional(),
  limitPeriod: z.enum(["NONE", "MONTHLY"]).optional(),
  allowedModels: z.array(z.string().trim().min(1)).max(500).optional(),
  rpmLimit: z.number().int().min(1).max(100_000).optional(),
  status: z.enum(["ACTIVE", "PAUSED"]).optional(),
});

export const topupSchema = z.object({
  amountRub: z.number().int().min(100, "Минимальная сумма пополнения — 100 ₽").max(1_000_000),
});

export const profileSchema = z.object({
  name: z.string().trim().min(2).max(80),
});

export const passwordSchema = z.object({
  currentPassword: z.string().min(1, "Введите текущий пароль"),
  newPassword: z.string().min(8, "Новый пароль должен быть не короче 8 символов").max(200),
});

export const adminSettingsSchema = z.object({
  usdRubRate: z.number().positive().max(10_000).optional(),
  markupPercent: z.number().min(0).max(10_000).optional(),
});

export const adminBalanceSchema = z.object({
  deltaRub: z.number().min(-100_000_000).max(100_000_000),
  description: z.string().trim().max(200).optional(),
});

export type RegisterInput = z.infer<typeof registerSchema>;
export type LoginInput = z.infer<typeof loginSchema>;
export type CreateKeyInput = z.infer<typeof createKeySchema>;
export type UpdateKeyInput = z.infer<typeof updateKeySchema>;
export type TopupInput = z.infer<typeof topupSchema>;
