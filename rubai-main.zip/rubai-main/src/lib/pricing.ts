/**
 * Расчёт стоимости запроса.
 *
 * Цены моделей хранятся в USD за 1 млн токенов. К стоимости в долларах
 * применяется курс ЦБ и наценка сервиса; итог округляется вверх до копейки.
 */

export interface UsageTokens {
  promptTokens: number;
  completionTokens: number;
  cachedTokens?: number;
}

export interface PriceSnapshot {
  inputUsdPerM: number;
  outputUsdPerM: number;
  cachedUsdPerM: number;
  usdRubRate: number;
  markupPercent: number;
}

export function costUsd(usage: UsageTokens, price: Pick<PriceSnapshot, "inputUsdPerM" | "outputUsdPerM" | "cachedUsdPerM">): number {
  const prompt = Math.max(0, usage.promptTokens || 0);
  const completion = Math.max(0, usage.completionTokens || 0);
  const cached = Math.min(prompt, Math.max(0, usage.cachedTokens || 0));
  const fresh = prompt - cached;

  const usd =
    (fresh * price.inputUsdPerM) / 1_000_000 +
    (cached * price.cachedUsdPerM) / 1_000_000 +
    (completion * price.outputUsdPerM) / 1_000_000;

  return usd;
}

export function costRub(usage: UsageTokens, price: PriceSnapshot): number {
  return costUsd(usage, price) * price.usdRubRate * (1 + price.markupPercent / 100);
}

/** Итоговая стоимость в копейках (округление вверх, чтобы не работать себе в убыток). */
export function costKopecks(usage: UsageTokens, price: PriceSnapshot): bigint {
  const rub = costRub(usage, price);
  if (!Number.isFinite(rub) || rub <= 0) return 0n;
  return BigInt(Math.ceil(rub * 100));
}

/** Оценка стоимости запроса в копейках до его выполнения (для проверки баланса). */
export function estimateKopecks(
  params: { promptTokensEstimate: number; maxTokens?: number },
  price: PriceSnapshot,
): bigint {
  return costKopecks(
    {
      promptTokens: params.promptTokensEstimate,
      completionTokens: params.maxTokens ?? 0,
    },
    price,
  );
}

/** Грубая оценка токенов текста: ~4 символа на токен. */
export function estimateTokensFromText(text: string): number {
  return Math.max(1, Math.ceil(text.length / 4));
}
