import type { Payment } from "@prisma/client";
import { prisma } from "./db";
import { env } from "./env";
import { createYooKassaPayment, getYooKassaPayment } from "./yookassa";

/**
 * Создаёт платёж на пополнение. В mock-режиме подтверждение происходит
 * отдельным вызовом /api/billing/mock-pay, в боевом — через ЮKassa.
 */
export async function createTopupPayment(params: {
  userId: string;
  amountKopecks: bigint;
}): Promise<{ payment: Payment; confirmationUrl: string | null; mock: boolean }> {
  const description = `Пополнение баланса rubai на ${Number(params.amountKopecks) / 100} ₽`;

  const payment = await prisma.payment.create({
    data: {
      userId: params.userId,
      amountKopecks: params.amountKopecks,
      status: "PENDING",
      provider: env.paymentMode === "mock" ? "mock" : "yookassa",
      description,
    },
  });

  if (env.paymentMode === "mock") {
    return { payment, confirmationUrl: null, mock: true };
  }

  const remote = await createYooKassaPayment({
    amountKopecks: params.amountKopecks,
    description,
    returnUrl: `${env.appUrl}/dashboard/billing?payment=${payment.id}`,
    metadata: { paymentId: payment.id, userId: params.userId },
  });

  const updated = await prisma.payment.update({
    where: { id: payment.id },
    data: {
      providerPaymentId: remote.id,
      confirmationUrl: remote.confirmationUrl ?? null,
    },
  });

  return { payment: updated, confirmationUrl: remote.confirmationUrl ?? null, mock: false };
}

/**
 * Идемпотентно зачисляет оплаченный платёж: статус меняется атомарно,
 * поэтому повторный вебхук не приведёт к двойному зачислению.
 */
export async function creditPayment(params: { paymentId: string; providerPaymentId?: string }): Promise<boolean> {
  return prisma.$transaction(async (tx) => {
    const claimed = await tx.payment.updateMany({
      where: { id: params.paymentId, status: "PENDING" },
      data: {
        status: "SUCCEEDED",
        paidAt: new Date(),
        ...(params.providerPaymentId ? { providerPaymentId: params.providerPaymentId } : {}),
      },
    });
    if (claimed.count === 0) return false;

    const payment = await tx.payment.findUniqueOrThrow({ where: { id: params.paymentId } });
    const user = await tx.user.update({
      where: { id: payment.userId },
      data: { balanceKopecks: { increment: payment.amountKopecks } },
    });
    await tx.transaction.create({
      data: {
        userId: payment.userId,
        type: "DEPOSIT",
        amountKopecks: payment.amountKopecks,
        balanceAfter: user.balanceKopecks,
        description: "Пополнение баланса",
        paymentId: payment.id,
      },
    });
    return true;
  });
}

export async function markPaymentCanceled(paymentId: string): Promise<void> {
  await prisma.payment.updateMany({
    where: { id: paymentId, status: "PENDING" },
    data: { status: "CANCELED" },
  });
}

/** Перепроверяет статус платежа в ЮKassa (на случай задержки вебхука). */
export async function refreshPaymentStatus(payment: Payment): Promise<Payment> {
  if (payment.status !== "PENDING" || payment.provider !== "yookassa" || !payment.providerPaymentId) {
    return payment;
  }

  try {
    const remote = await getYooKassaPayment(payment.providerPaymentId);
    if (remote.status === "succeeded" && remote.paid) {
      const remoteKopecks = BigInt(Math.round(Number(remote.amountValue) * 100));
      if (remoteKopecks === payment.amountKopecks) {
        await creditPayment({ paymentId: payment.id, providerPaymentId: remote.id });
      }
    } else if (remote.status === "canceled") {
      await markPaymentCanceled(payment.id);
    }
  } catch {
    // сеть недоступна — платёж остаётся в статусе PENDING
  }

  return (await prisma.payment.findUnique({ where: { id: payment.id } })) ?? payment;
}

/** Обновляет все зависшие платежи пользователя (используется на странице пополнения). */
export async function refreshPendingPayments(userId: string): Promise<void> {
  const pending = await prisma.payment.findMany({
    where: { userId, status: "PENDING", provider: "yookassa" },
    orderBy: { createdAt: "desc" },
    take: 5,
  });
  for (const payment of pending) {
    await refreshPaymentStatus(payment);
  }
}
