export interface UpstreamModel {
  slug: string;
  displayName: string;
  provider: string;
  description?: string;
  contextLength?: number;
  inputUsdPerM: number;
  outputUsdPerM: number;
  cachedUsdPerM: number;
  inputModalities: string[];
  outputModalities: string[];
  raw?: unknown;
}

export interface UpstreamUsage {
  promptTokens: number;
  completionTokens: number;
  cachedTokens: number;
  totalTokens: number;
}

export interface UpstreamCallOptions {
  signal?: AbortSignal;
}

/**
 * Апстрим-провайдер. Возвращает «сырой» Response, чтобы шлюз мог
 * прозрачно проксировать и обычные ответы, и SSE-стримы.
 */
export interface UpstreamProvider {
  name: string;
  listModels(): Promise<UpstreamModel[]>;
  chatCompletions(body: Record<string, unknown>, options?: UpstreamCallOptions): Promise<Response>;
  embeddings(body: Record<string, unknown>, options?: UpstreamCallOptions): Promise<Response>;
}
