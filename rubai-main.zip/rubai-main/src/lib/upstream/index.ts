import { activeProviderName } from "../env";
import { mockProvider } from "./mock";
import { openRouterProvider } from "./openrouter";
import type { UpstreamProvider } from "./types";

export function getProvider(): UpstreamProvider {
  return activeProviderName() === "openrouter" ? openRouterProvider : mockProvider;
}

export type { UpstreamModel, UpstreamProvider, UpstreamUsage } from "./types";
