import { randomUUID } from "node:crypto";
import { estimateTokensFromText } from "../pricing";
import type { UpstreamModel, UpstreamProvider } from "./types";

/**
 * Mock-провайдер для локальной разработки и тестов:
 * не обращается к внешним сервисам и не тратит деньги.
 */

const MOCK_MODELS: UpstreamModel[] = [
  {
    slug: "openai/gpt-4o-mini",
    displayName: "GPT-4o mini",
    provider: "openai",
    description: "Быстрая и недорогая модель OpenAI для повседневных задач.",
    contextLength: 128_000,
    inputUsdPerM: 0.15,
    outputUsdPerM: 0.6,
    cachedUsdPerM: 0.075,
    inputModalities: ["text", "image"],
    outputModalities: ["text"],
  },
  {
    slug: "anthropic/claude-3.5-sonnet",
    displayName: "Claude 3.5 Sonnet",
    provider: "anthropic",
    description: "Флагманская модель Anthropic для кода и агентных сценариев.",
    contextLength: 200_000,
    inputUsdPerM: 3,
    outputUsdPerM: 15,
    cachedUsdPerM: 0.3,
    inputModalities: ["text", "image"],
    outputModalities: ["text"],
  },
  {
    slug: "google/gemini-2.0-flash-001",
    displayName: "Gemini 2.0 Flash",
    provider: "google",
    description: "Быстрая мультимодальная модель Google с большим контекстом.",
    contextLength: 1_000_000,
    inputUsdPerM: 0.1,
    outputUsdPerM: 0.4,
    cachedUsdPerM: 0.025,
    inputModalities: ["text", "image"],
    outputModalities: ["text"],
  },
  {
    slug: "deepseek/deepseek-chat",
    displayName: "DeepSeek V3",
    provider: "deepseek",
    description: "Открытая модель DeepSeek — сильный кодинг за небольшие деньги.",
    contextLength: 64_000,
    inputUsdPerM: 0.14,
    outputUsdPerM: 0.28,
    cachedUsdPerM: 0.014,
    inputModalities: ["text"],
    outputModalities: ["text"],
  },
  {
    slug: "meta-llama/llama-3.3-70b-instruct",
    displayName: "Llama 3.3 70B",
    provider: "meta-llama",
    description: "Открытая модель Meta для универсальных задач.",
    contextLength: 131_072,
    inputUsdPerM: 0.12,
    outputUsdPerM: 0.3,
    cachedUsdPerM: 0,
    inputModalities: ["text"],
    outputModalities: ["text"],
  },
  {
    slug: "qwen/qwen-2.5-72b-instruct",
    displayName: "Qwen 2.5 72B",
    provider: "qwen",
    description: "Открытая модель Alibaba с поддержкой русского языка.",
    contextLength: 32_768,
    inputUsdPerM: 0.35,
    outputUsdPerM: 0.4,
    cachedUsdPerM: 0,
    inputModalities: ["text"],
    outputModalities: ["text"],
  },
];

function extractText(content: unknown): string {
  if (typeof content === "string") return content;
  if (Array.isArray(content)) {
    return content
      .map((part) => {
        if (typeof part === "string") return part;
        if (part && typeof part === "object" && "text" in part) {
          return String((part as { text?: unknown }).text ?? "");
        }
        return "";
      })
      .join(" ")
      .trim();
  }
  return "";
}

function messagesText(messages: unknown): string {
  if (!Array.isArray(messages)) return "";
  return messages
    .map((message) => {
      if (!message || typeof message !== "object") return "";
      const item = message as { role?: string; content?: unknown };
      return `${item.role ?? "user"}: ${extractText(item.content)}`;
    })
    .join("\n");
}

function buildAnswer(model: string, messages: unknown): string {
  const text = messagesText(messages);
  const lastUser = extractText(
    (Array.isArray(messages) ? [...messages].reverse().find((m) => (m as { role?: string })?.role === "user") : null) as
      | { content?: unknown }
      | null as unknown,
  );
  const snippet = (lastUser || text).slice(0, 160);
  return `[mock] Это тестовый ответ шлюза rubai на запрос «${snippet}». Модель ${model} не вызывалась: включён режим UPSTREAM_PROVIDER=mock.`;
}

function completionId(): string {
  return `chatcmpl-${randomUUID().replace(/-/g, "").slice(0, 20)}`;
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function sseStream(params: {
  id: string;
  created: number;
  model: string;
  words: string[];
  usage: { prompt_tokens: number; completion_tokens: number; total_tokens: number };
  signal?: AbortSignal;
}): ReadableStream<Uint8Array> {
  const encoder = new TextEncoder();
  let index = 0;
  let closed = false;

  return new ReadableStream<Uint8Array>({
    async pull(controller) {
      if (closed) return;
      if (params.signal?.aborted) {
        closed = true;
        controller.error(new Error("aborted"));
        return;
      }

      if (index === 0) {
        const first = {
          id: params.id,
          object: "chat.completion.chunk",
          created: params.created,
          model: params.model,
          choices: [{ index: 0, delta: { role: "assistant", content: "" }, finish_reason: null }],
        };
        controller.enqueue(encoder.encode(`data: ${JSON.stringify(first)}\n\n`));
        index += 1;
        await sleep(15);
        return;
      }

      if (index <= params.words.length) {
        const chunk = {
          id: params.id,
          object: "chat.completion.chunk",
          created: params.created,
          model: params.model,
          choices: [{ index: 0, delta: { content: params.words[index - 1] }, finish_reason: null }],
        };
        controller.enqueue(encoder.encode(`data: ${JSON.stringify(chunk)}\n\n`));
        index += 1;
        await sleep(15);
        return;
      }

      const last = {
        id: params.id,
        object: "chat.completion.chunk",
        created: params.created,
        model: params.model,
        choices: [{ index: 0, delta: {}, finish_reason: "stop" }],
        usage: params.usage,
      };
      controller.enqueue(encoder.encode(`data: ${JSON.stringify(last)}\n\n`));
      controller.enqueue(encoder.encode("data: [DONE]\n\n"));
      closed = true;
      controller.close();
    },
    cancel() {
      closed = true;
    },
  });
}

function deterministicVector(text: string, dimensions = 8): number[] {
  const vector: number[] = [];
  let seed = 2166136261;
  for (let i = 0; i < text.length; i += 1) {
    seed ^= text.charCodeAt(i);
    seed = Math.imul(seed, 16777619);
  }
  for (let i = 0; i < dimensions; i += 1) {
    seed = Math.imul(seed ^ (seed >>> 15), 2246822507);
    vector.push(((seed >>> 0) % 2000) / 1000 - 1);
  }
  return vector;
}

export const mockProvider: UpstreamProvider = {
  name: "mock",

  async listModels() {
    return MOCK_MODELS;
  },

  async chatCompletions(body, options) {
    const model = String(body.model ?? "mock-model");
    const answer = buildAnswer(model, body.messages);
    const promptTokens = estimateTokensFromText(messagesText(body.messages));
    const completionTokens = estimateTokensFromText(answer);
    const id = completionId();
    const created = Math.floor(Date.now() / 1000);
    const usage = {
      prompt_tokens: promptTokens,
      completion_tokens: completionTokens,
      total_tokens: promptTokens + completionTokens,
    };

    if (body.stream) {
      const words = answer.split(/(\s+)/).filter((w) => w.length > 0);
      return new Response(
        sseStream({ id, created, model, words, usage, signal: options?.signal }),
        { headers: { "content-type": "text/event-stream; charset=utf-8" } },
      );
    }

    return Response.json({
      id,
      object: "chat.completion",
      created,
      model,
      choices: [
        {
          index: 0,
          message: { role: "assistant", content: answer },
          finish_reason: "stop",
        },
      ],
      usage,
    });
  },

  async embeddings(body) {
    const input = body.input;
    const texts = Array.isArray(input) ? input : [input];
    const data = texts.map((text, index) => ({
      object: "embedding",
      index,
      embedding: deterministicVector(String(text ?? "")),
    }));
    const promptTokens = texts.reduce<number>((sum, text) => sum + estimateTokensFromText(String(text ?? "")), 0);

    return Response.json({
      object: "list",
      data,
      model: String(body.model ?? "mock-embedding"),
      usage: { prompt_tokens: promptTokens, total_tokens: promptTokens },
    });
  },
};
