import { env } from "../env";
import type { UpstreamModel, UpstreamProvider } from "./types";

interface OpenRouterRawModel {
  id?: string;
  name?: string;
  description?: string;
  context_length?: number;
  pricing?: {
    prompt?: string | number;
    completion?: string | number;
    input_cache_read?: string | number;
  };
  architecture?: {
    input_modalities?: string[];
    output_modalities?: string[];
    modality?: string;
  };
}

function perMillion(value: string | number | undefined): number {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed * 1_000_000 : 0;
}

function mapModel(raw: OpenRouterRawModel): UpstreamModel {
  const slug = String(raw.id ?? "").trim();
  const provider = slug.includes("/") ? slug.split("/")[0] : "other";
  return {
    slug,
    displayName: String(raw.name ?? slug),
    provider,
    description: raw.description ? String(raw.description).slice(0, 600) : undefined,
    contextLength: Number(raw.context_length) || undefined,
    inputUsdPerM: perMillion(raw.pricing?.prompt),
    outputUsdPerM: perMillion(raw.pricing?.completion),
    cachedUsdPerM: perMillion(raw.pricing?.input_cache_read),
    inputModalities: raw.architecture?.input_modalities ?? ["text"],
    outputModalities: raw.architecture?.output_modalities ?? ["text"],
    raw,
  };
}

function baseHeaders(): Record<string, string> {
  return {
    "http-referer": env.openrouterReferer,
    "x-title": env.openrouterTitle,
  };
}

function timeoutSignal(external: AbortSignal | undefined, timeoutMs: number): AbortSignal {
  const timeout = AbortSignal.timeout(timeoutMs);
  return external ? AbortSignal.any([external, timeout]) : timeout;
}

export const openRouterProvider: UpstreamProvider = {
  name: "openrouter",

  async listModels() {
    const response = await fetch(`${env.openrouterBaseUrl}/models`, {
      headers: baseHeaders(),
      signal: AbortSignal.timeout(30_000),
    });
    if (!response.ok) {
      throw new Error(`OpenRouter /models: HTTP ${response.status}`);
    }
    const json = (await response.json()) as { data?: OpenRouterRawModel[] };
    return (json.data ?? []).map(mapModel).filter((model) => model.slug.length > 0);
  },

  async chatCompletions(body, options) {
    return fetch(`${env.openrouterBaseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        ...baseHeaders(),
        authorization: `Bearer ${env.openrouterApiKey}`,
        "content-type": "application/json",
      },
      body: JSON.stringify(body),
      signal: timeoutSignal(options?.signal, 600_000),
    });
  },

  async embeddings(body, options) {
    return fetch(`${env.openrouterBaseUrl}/embeddings`, {
      method: "POST",
      headers: {
        ...baseHeaders(),
        authorization: `Bearer ${env.openrouterApiKey}`,
        "content-type": "application/json",
      },
      body: JSON.stringify(body),
      signal: timeoutSignal(options?.signal, 120_000),
    });
  },
};
