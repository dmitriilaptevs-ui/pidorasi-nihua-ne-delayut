function num(value: string | undefined, fallback: number): number {
  if (value === undefined || value.trim() === "") return fallback;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

export const env = {
  appUrl: (process.env.APP_URL ?? "http://localhost:3000").replace(/\/+$/, ""),
  sessionSecret: process.env.SESSION_SECRET ?? "dev-only-secret-change-me",
  upstreamProvider: (process.env.UPSTREAM_PROVIDER ?? "mock").toLowerCase(),
  openrouterApiKey: process.env.OPENROUTER_API_KEY ?? "",
  openrouterBaseUrl: (process.env.OPENROUTER_BASE_URL ?? "https://openrouter.ai/api/v1").replace(/\/+$/, ""),
  openrouterReferer: process.env.OPENROUTER_REFERER ?? "https://rubai.ru",
  openrouterTitle: process.env.OPENROUTER_TITLE ?? "rubai",
  usdRubFallback: num(process.env.USD_RUB_FALLBACK, 95),
  markupPercentDefault: num(process.env.MARKUP_PERCENT_DEFAULT, 30),
  paymentMode: (process.env.PAYMENT_MODE ?? "mock").toLowerCase(),
  yookassaShopId: process.env.YOOKASSA_SHOP_ID ?? "",
  yookassaSecretKey: process.env.YOOKASSA_SECRET_KEY ?? "",
  defaultKeyRpm: num(process.env.DEFAULT_KEY_RPM, 60),
  adminEmail: process.env.ADMIN_EMAIL ?? "",
  adminPassword: process.env.ADMIN_PASSWORD ?? "",
  isProd: process.env.NODE_ENV === "production",
};

export type ProviderName = "openrouter" | "mock";

/** Активный апстрим-провайдер: openrouter, если задан ключ, иначе mock. */
export function activeProviderName(): ProviderName {
  return env.upstreamProvider === "openrouter" && env.openrouterApiKey ? "openrouter" : "mock";
}
