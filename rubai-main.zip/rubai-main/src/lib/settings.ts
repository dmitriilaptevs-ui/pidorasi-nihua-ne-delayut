import { prisma } from "./db";
import { env } from "./env";

export const SETTING_KEYS = {
  usdRubRate: "usd_rub_rate",
  markupPercent: "markup_percent",
  modelsSyncedAt: "models_synced_at",
  rateSyncedAt: "rate_synced_at",
} as const;

export interface AppSettings {
  usdRubRate: number;
  markupPercent: number;
  modelsSyncedAt: string | null;
  rateSyncedAt: string | null;
}

let cache: (AppSettings & { cachedAt: number }) | null = null;
const CACHE_TTL_MS = 30_000;

export async function getSettings(): Promise<AppSettings> {
  if (cache && Date.now() - cache.cachedAt < CACHE_TTL_MS) {
    return cache;
  }

  let rows: Array<{ key: string; value: string }> = [];
  try {
    rows = await prisma.setting.findMany({
      where: { key: { in: Object.values(SETTING_KEYS) } },
      select: { key: true, value: true },
    });
  } catch {
    rows = [];
  }

  const map = new Map(rows.map((row) => [row.key, row.value]));
  const rate = Number(map.get(SETTING_KEYS.usdRubRate));

  const settings: AppSettings = {
    usdRubRate: Number.isFinite(rate) && rate > 0 ? rate : env.usdRubFallback,
    markupPercent: Number(map.get(SETTING_KEYS.markupPercent) ?? env.markupPercentDefault),
    modelsSyncedAt: map.get(SETTING_KEYS.modelsSyncedAt) ?? null,
    rateSyncedAt: map.get(SETTING_KEYS.rateSyncedAt) ?? null,
  };

  cache = { ...settings, cachedAt: Date.now() };
  return settings;
}

export function invalidateSettingsCache(): void {
  cache = null;
}

export async function setSetting(key: string, value: string): Promise<void> {
  await prisma.setting.upsert({
    where: { key },
    create: { key, value },
    update: { value },
  });
  invalidateSettingsCache();
}
