import { randomUUID } from "node:crypto";
import type { Model } from "@prisma/client";
import { authenticateApiKey, extractBearerToken, type ApiKeyWithUser } from "./api-keys";
import { keySpent, recordUsage } from "./billing";
import { prisma } from "./db";
import { env } from "./env";
import { formatRub } from "./money";
import { openAiError, withCors } from "./openai-error";
import { costKopecks, estimateTokensFromText, type PriceSnapshot } from "./pricing";
import { checkRateLimit } from "./ratelimit";
import { getSettings } from "./settings";
import { getProvider } from "./upstream";
import type { UpstreamUsage } from "./upstream/types";

/** Минимальный баланс, при котором запросы разрешены. */
const MIN_BALANCE_KOPECKS = 100n;

type JsonRecord = Record<string, unknown>;

interface RequestContext {
  key: ApiKeyWithUser;
  model: Model;
  price: PriceSnapshot;
  requestId: string;
  startedAt: number;
  endpoint: string;
  body: JsonRecord;
}

// ── Авторизация и проверки ────────────────────────────────────────────────────

async function resolveKey(request: Request): Promise<ApiKeyWithUser | Response> {
  const token = extractBearerToken(request);
  if (!token) {
    return openAiError(401, "Не передан API-ключ. Добавьте заголовок Authorization: Bearer sk-rubai-…", {
      code: "missing_api_key",
    });
  }

  const key = await authenticateApiKey(token);
  if (!key) {
    return openAiError(401, "Неверный или отозванный API-ключ", { code: "invalid_api_key" });
  }

  if (key.status === "PAUSED") {
    return openAiError(403, "Ключ приостановлен владельцем аккаунта", {
      type: "permission_error",
      code: "key_paused",
    });
  }

  const rpmLimit = key.rpmLimit || env.defaultKeyRpm;
  const rate = checkRateLimit(`key:${key.id}`, rpmLimit);
  if (!rate.ok) {
    return openAiError(429, `Превышен лимит запросов: ${rpmLimit} в минуту`, {
      type: "rate_limit_error",
      code: "rate_limit_exceeded",
      headers: { "retry-after": String(rate.retryAfterSec) },
    });
  }

  return key;
}

async function resolveModel(key: ApiKeyWithUser, slug: string): Promise<Model | Response> {
  if (!slug) {
    return openAiError(400, "Параметр model обязателен", { code: "missing_model" });
  }

  const model = await prisma.model.findUnique({ where: { slug } });
  if (!model || !model.isActive) {
    return openAiError(404, `Модель «${slug}» не найдена. Список доступных моделей: GET /v1/models`, {
      code: "model_not_found",
    });
  }

  if (key.allowedModels.length > 0 && !key.allowedModels.includes(slug)) {
    return openAiError(403, `Модель «${slug}» недоступна для этого ключа`, {
      type: "permission_error",
      code: "model_not_allowed",
    });
  }

  return model;
}

async function checkLimits(key: ApiKeyWithUser): Promise<Response | null> {
  if (key.limitKopecks !== null) {
    const spent = await keySpent(key.id, key.limitPeriod);
    if (spent >= key.limitKopecks) {
      const period = key.limitPeriod === "MONTHLY" ? "за текущий месяц" : "за всё время";
      return openAiError(
        429,
        `Лимит расхода по ключу исчерпан: ${formatRub(spent)} из ${formatRub(key.limitKopecks)} ${period}`,
        { type: "insufficient_quota", code: "key_limit_exceeded" },
      );
    }
  }

  if (key.user.balanceKopecks < MIN_BALANCE_KOPECKS) {
    return openAiError(402, "Недостаточно средств. Пополните баланс в личном кабинете rubai.", {
      type: "insufficient_quota",
      code: "insufficient_funds",
    });
  }

  return null;
}

// ── Разбор usage ─────────────────────────────────────────────────────────────

function extractUsage(json: unknown): UpstreamUsage | null {
  if (!json || typeof json !== "object") return null;
  const usage = (json as { usage?: Record<string, unknown> }).usage;
  if (!usage) return null;

  const prompt = Number(usage.prompt_tokens ?? 0) || 0;
  const completion = Number(usage.completion_tokens ?? 0) || 0;
  const details = usage.prompt_tokens_details as { cached_tokens?: number } | undefined;
  const cached = Number(details?.cached_tokens ?? usage.cache_read_input_tokens ?? 0) || 0;

  return {
    promptTokens: prompt,
    completionTokens: completion,
    cachedTokens: cached,
    totalTokens: Number(usage.total_tokens ?? prompt + completion) || prompt + completion,
  };
}

function estimatePromptTokens(body: JsonRecord): number {
  const parts: string[] = [];

  if (Array.isArray(body.messages)) {
    for (const message of body.messages) {
      if (!message || typeof message !== "object") continue;
      const content = (message as { content?: unknown }).content;
      parts.push(typeof content === "string" ? content : JSON.stringify(content ?? ""));
    }
  }
  if (typeof body.input === "string") parts.push(body.input);
  if (Array.isArray(body.input)) parts.push(body.input.map((item) => String(item)).join("\n"));
  if (typeof body.prompt === "string") parts.push(body.prompt);

  return estimateTokensFromText(parts.join("\n"));
}

function extractUpstreamError(json: unknown): string | null {
  if (!json || typeof json !== "object") return null;
  const error = (json as { error?: { message?: unknown } }).error;
  if (error && typeof error.message === "string") return error.message;
  const message = (json as { message?: unknown }).message;
  return typeof message === "string" ? message : null;
}

function errorMessage(error: unknown): string {
  if (error instanceof Error) return error.message;
  return String(error);
}

// ── Обработка ответов ────────────────────────────────────────────────────────

async function handleNonStreamResponse(upstream: Response, ctx: RequestContext): Promise<Response> {
  const latencyMs = Date.now() - ctx.startedAt;
  const text = await upstream.text();

  let json: unknown = null;
  try {
    json = JSON.parse(text);
  } catch {
    json = null;
  }

  if (!upstream.ok || !json) {
    await recordUsage({
      userId: ctx.key.userId,
      apiKeyId: ctx.key.id,
      modelSlug: ctx.model.slug,
      endpoint: ctx.endpoint,
      promptTokens: 0,
      completionTokens: 0,
      cachedTokens: 0,
      totalTokens: 0,
      costKopecks: 0n,
      usdRubRate: ctx.price.usdRubRate,
      markupPercent: ctx.price.markupPercent,
      status: "error",
      httpStatus: upstream.status,
      latencyMs,
      streamed: false,
      requestId: ctx.requestId,
    }).catch(() => undefined);

    const status = upstream.status >= 400 ? upstream.status : 502;
    const message = extractUpstreamError(json) ?? `Апстрим-провайдер вернул ошибку ${upstream.status}`;
    return openAiError(status, message, { type: "api_error", code: "upstream_error" });
  }

  const usage = extractUsage(json) ?? {
    promptTokens: estimatePromptTokens(ctx.body),
    completionTokens: 0,
    cachedTokens: 0,
    totalTokens: 0,
  };
  usage.totalTokens = usage.totalTokens || usage.promptTokens + usage.completionTokens;

  const cost = costKopecks(usage, ctx.price);
  const { balanceAfter } = await recordUsage({
    userId: ctx.key.userId,
    apiKeyId: ctx.key.id,
    modelSlug: ctx.model.slug,
    endpoint: ctx.endpoint,
    promptTokens: usage.promptTokens,
    completionTokens: usage.completionTokens,
    cachedTokens: usage.cachedTokens,
    totalTokens: usage.totalTokens,
    costKopecks: cost,
    usdRubRate: ctx.price.usdRubRate,
    markupPercent: ctx.price.markupPercent,
    status: "ok",
    httpStatus: 200,
    latencyMs,
    streamed: false,
    requestId: ctx.requestId,
  });

  const headers: Record<string, string> = {
    "content-type": "application/json; charset=utf-8",
    "x-rubai-request-id": ctx.requestId,
    "x-rubai-cost-kopecks": cost.toString(),
  };
  if (balanceAfter !== null) {
    headers["x-rubai-balance-kopecks"] = balanceAfter.toString();
  }

  return withCors(new Response(text, { status: 200, headers }));
}

async function handleStreamResponse(upstream: Response, ctx: RequestContext): Promise<Response> {
  const latencyStart = ctx.startedAt;

  if (!upstream.ok || !upstream.body) {
    const text = await upstream.text();
    let json: unknown = null;
    try {
      json = JSON.parse(text);
    } catch {
      json = null;
    }

    await recordUsage({
      userId: ctx.key.userId,
      apiKeyId: ctx.key.id,
      modelSlug: ctx.model.slug,
      endpoint: ctx.endpoint,
      promptTokens: 0,
      completionTokens: 0,
      cachedTokens: 0,
      totalTokens: 0,
      costKopecks: 0n,
      usdRubRate: ctx.price.usdRubRate,
      markupPercent: ctx.price.markupPercent,
      status: "error",
      httpStatus: upstream.status,
      latencyMs: Date.now() - latencyStart,
      streamed: true,
      requestId: ctx.requestId,
    }).catch(() => undefined);

    const status = upstream.status >= 400 ? upstream.status : 502;
    const message = extractUpstreamError(json) ?? `Апстрим-провайдер вернул ошибку ${upstream.status}`;
    return openAiError(status, message, { type: "api_error", code: "upstream_error" });
  }

  const reader = upstream.body.getReader();
  const decoder = new TextDecoder();
  const promptEstimate = estimatePromptTokens(ctx.body);

  let buffer = "";
  let usage: UpstreamUsage | null = null;
  let completionChars = 0;
  let finalized = false;

  async function finalize(cancelled: boolean): Promise<void> {
    if (finalized) return;
    finalized = true;

    const hasUsage = usage !== null || completionChars > 0;
    const finalUsage: UpstreamUsage = usage ?? {
      promptTokens: promptEstimate,
      completionTokens: estimateTokensFromText("x".repeat(completionChars)),
      cachedTokens: 0,
      totalTokens: 0,
    };
    finalUsage.totalTokens = finalUsage.totalTokens || finalUsage.promptTokens + finalUsage.completionTokens;

    const cost = hasUsage ? costKopecks(finalUsage, ctx.price) : 0n;
    await recordUsage({
      userId: ctx.key.userId,
      apiKeyId: ctx.key.id,
      modelSlug: ctx.model.slug,
      endpoint: ctx.endpoint,
      promptTokens: finalUsage.promptTokens,
      completionTokens: finalUsage.completionTokens,
      cachedTokens: finalUsage.cachedTokens,
      totalTokens: finalUsage.totalTokens,
      costKopecks: cost,
      usdRubRate: ctx.price.usdRubRate,
      markupPercent: ctx.price.markupPercent,
      status: hasUsage ? "ok" : "error",
      httpStatus: cancelled ? 499 : 200,
      latencyMs: Date.now() - latencyStart,
      streamed: true,
      requestId: ctx.requestId,
    }).catch(() => undefined);
  }

  const stream = new ReadableStream<Uint8Array>({
    async pull(controller) {
      try {
        const { done, value } = await reader.read();
        if (done) {
          await finalize(false);
          controller.close();
          return;
        }

        controller.enqueue(value);
        buffer += decoder.decode(value, { stream: true });

        let newlineIndex: number;
        while ((newlineIndex = buffer.indexOf("\n")) >= 0) {
          const line = buffer.slice(0, newlineIndex).trim();
          buffer = buffer.slice(newlineIndex + 1);
          if (!line.startsWith("data:")) continue;

          const payload = line.slice(5).trim();
          if (payload === "[DONE]") continue;

          try {
            const chunk = JSON.parse(payload) as {
              usage?: unknown;
              choices?: Array<{ delta?: { content?: unknown } }>;
            };
            const chunkUsage = extractUsage(chunk);
            if (chunkUsage) usage = chunkUsage;
            const deltaContent = chunk.choices?.[0]?.delta?.content;
            if (typeof deltaContent === "string") completionChars += deltaContent.length;
          } catch {
            // неполный или нестандартный чанк — пропускаем
          }
        }
      } catch {
        await finalize(true);
        try {
          controller.close();
        } catch {
          // поток уже закрыт
        }
      }
    },
    async cancel() {
      await reader.cancel().catch(() => undefined);
      await finalize(true);
    },
  });

  const headers: Record<string, string> = {
    "content-type": "text/event-stream; charset=utf-8",
    "cache-control": "no-cache, no-transform",
    connection: "keep-alive",
    "x-accel-buffering": "no",
    "x-rubai-request-id": ctx.requestId,
  };

  return withCors(new Response(stream, { status: 200, headers }));
}

// ── Публичные обработчики ────────────────────────────────────────────────────

async function prepareRequest(
  request: Request,
  options: { requireModel: boolean },
): Promise<{ key: ApiKeyWithUser; body: JsonRecord; model?: Model; price?: PriceSnapshot } | Response> {
  const keyOrError = await resolveKey(request);
  if (keyOrError instanceof Response) return keyOrError;
  const key = keyOrError;

  let body: JsonRecord | null = null;
  try {
    const parsed = await request.json();
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
      body = parsed as JsonRecord;
    }
  } catch {
    body = null;
  }
  if (!body) {
    return openAiError(400, "Тело запроса должно быть корректным JSON-объектом");
  }

  if (!options.requireModel) {
    return { key, body };
  }

  const modelOrError = await resolveModel(key, typeof body.model === "string" ? body.model.trim() : "");
  if (modelOrError instanceof Response) return modelOrError;
  const model = modelOrError;

  const limitError = await checkLimits(key);
  if (limitError) return limitError;

  const settings = await getSettings();
  const price: PriceSnapshot = {
    inputUsdPerM: model.inputUsdPerM,
    outputUsdPerM: model.outputUsdPerM,
    cachedUsdPerM: model.cachedUsdPerM,
    usdRubRate: settings.usdRubRate,
    markupPercent: settings.markupPercent,
  };

  return { key, body, model, price };
}

export async function handleChatCompletions(request: Request): Promise<Response> {
  const prepared = await prepareRequest(request, { requireModel: true });
  if (prepared instanceof Response) return prepared;
  const { key, body, model, price } = prepared;
  if (!model || !price) return openAiError(500, "Внутренняя ошибка подготовки запроса", { type: "api_error" });

  const streamed = Boolean(body.stream);
  const upstreamBody: JsonRecord = { ...body, model: model.slug };
  if (streamed) {
    const streamOptions = (upstreamBody.stream_options as JsonRecord | undefined) ?? {};
    upstreamBody.stream_options = { ...streamOptions, include_usage: true };
  }

  const requestId = `req_${randomUUID().replace(/-/g, "").slice(0, 24)}`;
  const ctx: RequestContext = {
    key,
    model,
    price,
    requestId,
    startedAt: Date.now(),
    endpoint: "chat.completions",
    body,
  };

  await prisma.apiKey
    .update({ where: { id: key.id }, data: { lastUsedAt: new Date() } })
    .catch(() => undefined);

  try {
    const provider = getProvider();
    const upstream = await provider.chatCompletions(upstreamBody, {
      signal: streamed ? request.signal : AbortSignal.timeout(600_000),
    });

    return streamed ? await handleStreamResponse(upstream, ctx) : await handleNonStreamResponse(upstream, ctx);
  } catch (error) {
    await recordUsage({
      userId: key.userId,
      apiKeyId: key.id,
      modelSlug: model.slug,
      endpoint: "chat.completions",
      promptTokens: 0,
      completionTokens: 0,
      cachedTokens: 0,
      totalTokens: 0,
      costKopecks: 0n,
      usdRubRate: price.usdRubRate,
      markupPercent: price.markupPercent,
      status: "error",
      httpStatus: 502,
      latencyMs: Date.now() - ctx.startedAt,
      streamed,
      requestId,
    }).catch(() => undefined);

    return openAiError(502, `Ошибка апстрим-провайдера: ${errorMessage(error)}`, {
      type: "api_error",
      code: "upstream_error",
    });
  }
}

export async function handleEmbeddings(request: Request): Promise<Response> {
  const prepared = await prepareRequest(request, { requireModel: true });
  if (prepared instanceof Response) return prepared;
  const { key, body, model, price } = prepared;
  if (!model || !price) return openAiError(500, "Внутренняя ошибка подготовки запроса", { type: "api_error" });

  const requestId = `req_${randomUUID().replace(/-/g, "").slice(0, 24)}`;
  const ctx: RequestContext = {
    key,
    model,
    price,
    requestId,
    startedAt: Date.now(),
    endpoint: "embeddings",
    body,
  };

  try {
    const provider = getProvider();
    const upstream = await provider.embeddings(
      { ...body, model: model.slug },
      { signal: AbortSignal.timeout(120_000) },
    );
    return await handleNonStreamResponse(upstream, ctx);
  } catch (error) {
    await recordUsage({
      userId: key.userId,
      apiKeyId: key.id,
      modelSlug: model.slug,
      endpoint: "embeddings",
      promptTokens: 0,
      completionTokens: 0,
      cachedTokens: 0,
      totalTokens: 0,
      costKopecks: 0n,
      usdRubRate: price.usdRubRate,
      markupPercent: price.markupPercent,
      status: "error",
      httpStatus: 502,
      latencyMs: Date.now() - ctx.startedAt,
      streamed: false,
      requestId,
    }).catch(() => undefined);

    return openAiError(502, `Ошибка апстрим-провайдера: ${errorMessage(error)}`, {
      type: "api_error",
      code: "upstream_error",
    });
  }
}

export async function handleModels(request: Request): Promise<Response> {
  const keyOrError = await resolveKey(request);
  if (keyOrError instanceof Response) return keyOrError;

  const models = await prisma.model.findMany({
    where: { isActive: true },
    orderBy: { slug: "asc" },
    select: { slug: true, provider: true, createdAt: true },
  });

  return withCors(
    Response.json({
      object: "list",
      data: models.map((model) => ({
        id: model.slug,
        object: "model",
        created: Math.floor(model.createdAt.getTime() / 1000),
        owned_by: model.provider,
      })),
    }),
  );
}
