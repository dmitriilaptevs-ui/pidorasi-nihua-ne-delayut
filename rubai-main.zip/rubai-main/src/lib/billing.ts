import { Prisma } from "@prisma/client";
import { prisma } from "./db";

export interface UsageRecordInput {
  userId: string;
  apiKeyId: string | null;
  modelSlug: string;
  endpoint: string;
  promptTokens: number;
  completionTokens: number;
  cachedTokens: number;
  totalTokens: number;
  costKopecks: bigint;
  usdRubRate: number;
  markupPercent: number;
  status: "ok" | "error";
  httpStatus: number;
  latencyMs: number;
  streamed: boolean;
  requestId: string;
}

/**
 * Записывает лог запроса и, если есть стоимость, списывает её с баланса
 * в одной транзакции. Баланс может уйти в минус — следующие запросы
 * будут блокироваться до пополнения.
 */
export async function recordUsage(input: UsageRecordInput) {
  return prisma.$transaction(async (tx) => {
    const log = await tx.usageLog.create({
      data: {
        userId: input.userId,
        apiKeyId: input.apiKeyId,
        modelSlug: input.modelSlug,
        endpoint: input.endpoint,
        promptTokens: input.promptTokens,
        completionTokens: input.completionTokens,
        cachedTokens: input.cachedTokens,
        totalTokens: input.totalTokens,
        costKopecks: input.costKopecks,
        usdRubRate: input.usdRubRate,
        markupPercent: input.markupPercent,
        status: input.status,
        httpStatus: input.httpStatus,
        latencyMs: input.latencyMs,
        streamed: input.streamed,
        requestId: input.requestId,
      },
    });

    if (input.costKopecks > 0n) {
      const user = await tx.user.update({
        where: { id: input.userId },
        data: { balanceKopecks: { decrement: input.costKopecks } },
      });
      await tx.transaction.create({
        data: {
          userId: input.userId,
          type: "CHARGE",
          amountKopecks: -input.costKopecks,
          balanceAfter: user.balanceKopecks,
          description: `Запрос к модели ${input.modelSlug}`,
          usageLogId: log.id,
        },
      });
      return { log, balanceAfter: user.balanceKopecks };
    }

    return { log, balanceAfter: null };
  });
}

export function startOfMonth(date = new Date()): Date {
  return new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), 1));
}

/** Расход по ключу за период (или за всё время). */
export async function keySpent(apiKeyId: string, period: "NONE" | "MONTHLY"): Promise<bigint> {
  const where: Prisma.UsageLogWhereInput = { apiKeyId, status: "ok" };
  if (period === "MONTHLY") {
    where.createdAt = { gte: startOfMonth() };
  }
  const agg = await prisma.usageLog.aggregate({ where, _sum: { costKopecks: true } });
  return agg._sum.costKopecks ?? 0n;
}

export async function deposit(params: {
  userId: string;
  amountKopecks: bigint;
  description: string;
  type?: "DEPOSIT" | "ADJUSTMENT" | "REFUND";
  paymentId?: string;
}) {
  return prisma.$transaction(async (tx) => {
    const user = await tx.user.update({
      where: { id: params.userId },
      data: { balanceKopecks: { increment: params.amountKopecks } },
    });
    const transaction = await tx.transaction.create({
      data: {
        userId: params.userId,
        type: params.type ?? "DEPOSIT",
        amountKopecks: params.amountKopecks,
        balanceAfter: user.balanceKopecks,
        description: params.description,
        paymentId: params.paymentId,
      },
    });
    return { user, transaction };
  });
}

/** Ручная корректировка баланса администратором (может быть отрицательной). */
export async function adjustBalance(params: { userId: string; deltaKopecks: bigint; description: string }) {
  return prisma.$transaction(async (tx) => {
    const user = await tx.user.update({
      where: { id: params.userId },
      data: { balanceKopecks: { increment: params.deltaKopecks } },
    });
    await tx.transaction.create({
      data: {
        userId: params.userId,
        type: "ADJUSTMENT",
        amountKopecks: params.deltaKopecks,
        balanceAfter: user.balanceKopecks,
        description: params.description,
      },
    });
    return user;
  });
}
