/** Ошибки в формате OpenAI API. */

export function openAiError(
  status: number,
  message: string,
  options: { type?: string; code?: string | null; headers?: Record<string, string> } = {},
): Response {
  return Response.json(
    {
      error: {
        message,
        type: options.type ?? "invalid_request_error",
        param: null,
        code: options.code ?? null,
      },
    },
    { status, headers: options.headers },
  );
}

export function withCors(response: Response): Response {
  response.headers.set("access-control-allow-origin", "*");
  response.headers.set("access-control-allow-headers", "authorization, content-type, x-api-key");
  response.headers.set("access-control-allow-methods", "GET, POST, OPTIONS");
  return response;
}

export function corsPreflight(): Response {
  return withCors(new Response(null, { status: 204 }));
}
