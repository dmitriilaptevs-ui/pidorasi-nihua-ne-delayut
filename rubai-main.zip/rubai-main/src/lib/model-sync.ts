import { prisma } from "./db";
import { getProvider } from "./upstream";
import type { UpstreamModel } from "./upstream/types";
import { SETTING_KEYS, setSetting } from "./settings";

/** Модели, которые показываются на лендинге и в каталоге первыми. */
const FEATURED_SLUGS = [
  "openai/gpt-4o-mini",
  "anthropic/claude-3.5-sonnet",
  "google/gemini-2.0-flash-001",
  "deepseek/deepseek-chat",
  "meta-llama/llama-3.3-70b-instruct",
  "qwen/qwen-2.5-72b-instruct",
];

export interface SyncModelsResult {
  total: number;
  created: number;
  updated: number;
  featured: number;
  provider: string;
}

function modalityOf(model: UpstreamModel): string {
  const inputs = new Set(model.inputModalities);
  if (inputs.has("image") || inputs.has("audio") || inputs.has("video")) {
    return model.inputModalities.join("+");
  }
  return "text";
}

function toModelData(model: UpstreamModel) {
  return {
    displayName: model.displayName,
    provider: model.provider,
    description: model.description ?? null,
    contextLength: model.contextLength ?? null,
    inputUsdPerM: model.inputUsdPerM,
    outputUsdPerM: model.outputUsdPerM,
    cachedUsdPerM: model.cachedUsdPerM,
    modality: modalityOf(model),
    inputModalities: model.inputModalities,
    outputModalities: model.outputModalities,
    isActive: true,
    raw: JSON.parse(JSON.stringify(model.raw ?? {})) as object,
  };
}

export async function syncModels(): Promise<SyncModelsResult> {
  const provider = getProvider();
  const models = await provider.listModels();
  if (models.length === 0) {
    throw new Error("Провайдер вернул пустой список моделей");
  }

  let created = 0;
  let updated = 0;
  const chunkSize = 25;

  for (let i = 0; i < models.length; i += chunkSize) {
    const chunk = models.slice(i, i + chunkSize);
    await Promise.all(
      chunk.map(async (model) => {
        const data = toModelData(model);
        const existing = await prisma.model.findUnique({ where: { slug: model.slug }, select: { id: true } });
        if (existing) {
          await prisma.model.update({ where: { slug: model.slug }, data });
          updated += 1;
        } else {
          await prisma.model.create({ data: { slug: model.slug, ...data } });
          created += 1;
        }
      }),
    );
  }

  const featured = await markFeatured(models);

  await setSetting(SETTING_KEYS.modelsSyncedAt, new Date().toISOString());
  return { total: models.length, created, updated, featured, provider: provider.name };
}

async function markFeatured(models: UpstreamModel[]): Promise<number> {
  const available = new Set(models.map((model) => model.slug));
  let slugs = FEATURED_SLUGS.filter((slug) => available.has(slug));

  if (slugs.length === 0) {
    slugs = models
      .filter((model) => model.outputUsdPerM > 0)
      .sort((a, b) => a.outputUsdPerM - b.outputUsdPerM)
      .slice(0, 6)
      .map((model) => model.slug);
  }

  await prisma.model.updateMany({ where: { slug: { in: slugs } }, data: { isFeatured: true } });
  await prisma.model.updateMany({ where: { slug: { notIn: slugs } }, data: { isFeatured: false } });
  return slugs.length;
}
