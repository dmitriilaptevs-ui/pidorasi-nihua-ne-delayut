import type { Metadata } from "next";
import Link from "next/link";
import { BarChart } from "@/components/charts";
import { Badge, Button, Card, PageHeader, Select, Stat, Table, Td, Th, Tr } from "@/components/ui";
import { requireUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { formatRub, formatTokens } from "@/lib/money";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Статистика",
};

const PAGE_SIZE = 25;

function first(value: string | string[] | undefined): string | undefined {
  return Array.isArray(value) ? value[0] : value;
}

function formatDateTime(date: Date): string {
  return new Intl.DateTimeFormat("ru-RU", {
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

export default async function UsagePage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const user = await requireUser();
  const params = await searchParams;

  const days = Math.min(365, Math.max(1, Number(first(params.days)) || 30));
  const page = Math.max(1, Number(first(params.page)) || 1);
  const keyId = first(params.keyId) || undefined;
  const modelSlug = first(params.model) || undefined;

  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
  const where = {
    userId: user.id,
    createdAt: { gte: since },
    ...(keyId ? { apiKeyId: keyId } : {}),
    ...(modelSlug ? { modelSlug } : {}),
  };

  const chartDays = Math.min(days, 60);
  const chartSince = new Date(Date.now() - (chartDays - 1) * 24 * 60 * 60 * 1000);

  const [totals, totalCount, logs, byModel, keys, models, chartLogs] = await Promise.all([
    prisma.usageLog.aggregate({
      where: { ...where, status: "ok" },
      _sum: { costKopecks: true, promptTokens: true, completionTokens: true, cachedTokens: true, totalTokens: true },
      _count: { _all: true },
    }),
    prisma.usageLog.count({ where }),
    prisma.usageLog.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * PAGE_SIZE,
      take: PAGE_SIZE,
    }),
    prisma.usageLog.groupBy({
      by: ["modelSlug"],
      where: { ...where, status: "ok" },
      _sum: { costKopecks: true, totalTokens: true },
      _count: { _all: true },
      orderBy: { _sum: { costKopecks: "desc" } },
      take: 10,
    }),
    prisma.apiKey.findMany({ where: { userId: user.id }, select: { id: true, name: true } }),
    prisma.model.findMany({
      where: { isActive: true },
      select: { slug: true, displayName: true },
      orderBy: { slug: "asc" },
      take: 500,
    }),
    prisma.usageLog.findMany({
      where: { userId: user.id, status: "ok", createdAt: { gte: chartSince } },
      select: { createdAt: true, costKopecks: true },
      take: 20_000,
    }),
  ]);

  const keyNames = new Map(keys.map((key) => [key.id, key.name]));

  const buckets = new Map<string, number>();
  for (let index = 0; index < chartDays; index += 1) {
    const date = new Date(chartSince.getTime() + index * 24 * 60 * 60 * 1000);
    buckets.set(date.toISOString().slice(0, 10), 0);
  }
  for (const log of chartLogs) {
    const key = log.createdAt.toISOString().slice(0, 10);
    if (buckets.has(key)) {
      buckets.set(key, (buckets.get(key) ?? 0) + Number(log.costKopecks));
    }
  }
  const chartData = Array.from(buckets.entries()).map(([key, value]) => ({
    label: new Intl.DateTimeFormat("ru-RU", { day: "2-digit", month: "2-digit" }).format(
      new Date(`${key}T00:00:00Z`),
    ),
    value,
  }));

  const cost = totals._sum.costKopecks ?? 0n;
  const requests = totals._count._all;
  const avgCost = requests > 0 ? Number(cost) / requests : 0;
  const totalPages = Math.max(1, Math.ceil(totalCount / PAGE_SIZE));

  const baseQuery = new URLSearchParams();
  baseQuery.set("days", String(days));
  if (keyId) baseQuery.set("keyId", keyId);
  if (modelSlug) baseQuery.set("model", modelSlug);

  const exportQuery = new URLSearchParams(baseQuery);
  const pageLink = (target: number) => {
    const query = new URLSearchParams(baseQuery);
    query.set("page", String(target));
    return `/dashboard/usage?${query.toString()}`;
  };

  return (
    <div>
      <PageHeader
        title="Статистика"
        description="Токены и стоимость запросов по моделям, ключам и дням."
      >
        <Link href={`/api/usage/export?${exportQuery.toString()}`}>
          <Button size="sm" variant="secondary">
            Экспорт CSV
          </Button>
        </Link>
      </PageHeader>

      <Card className="mb-6 p-4">
        <form method="get" className="grid gap-3 md:grid-cols-[140px_1fr_1fr_auto_auto]">
          <Select name="days" defaultValue={String(days)}>
            <option value="7">7 дней</option>
            <option value="30">30 дней</option>
            <option value="90">90 дней</option>
            <option value="365">Год</option>
          </Select>
          <Select name="keyId" defaultValue={keyId ?? ""}>
            <option value="">Все ключи</option>
            {keys.map((key) => (
              <option key={key.id} value={key.id}>
                {key.name}
              </option>
            ))}
          </Select>
          <Select name="model" defaultValue={modelSlug ?? ""}>
            <option value="">Все модели</option>
            {models.map((model) => (
              <option key={model.slug} value={model.slug}>
                {model.displayName}
              </option>
            ))}
          </Select>
          <Button type="submit" size="sm">
            Применить
          </Button>
          <Link href="/dashboard/usage" className="self-center text-xs text-slate-500 hover:text-slate-300">
            Сбросить
          </Link>
        </form>
      </Card>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="Расход за период" value={formatRub(cost)} hint={`Запросов: ${requests}`} />
        <Stat
          label="Токенов всего"
          value={formatTokens(totals._sum.totalTokens ?? 0)}
          hint={`Вход: ${formatTokens(totals._sum.promptTokens ?? 0)} · Выход: ${formatTokens(totals._sum.completionTokens ?? 0)}`}
        />
        <Stat
          label="Кэшированных токенов"
          value={formatTokens(totals._sum.cachedTokens ?? 0)}
          hint="Тарифицируются дешевле"
        />
        <Stat label="Средняя стоимость запроса" value={formatRub(Math.round(avgCost))} />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1.5fr_1fr]">
        <Card className="p-6">
          <div className="mb-4 font-medium text-white">Расход по дням</div>
          <BarChart data={chartData} />
        </Card>

        <Card className="overflow-hidden">
          <div className="px-5 py-4 font-medium text-white">Топ моделей</div>
          {byModel.length === 0 ? (
            <div className="border-t border-white/5 px-5 py-8 text-center text-xs text-slate-500">
              Нет данных
            </div>
          ) : (
            <Table className="min-w-[360px]">
              <thead>
                <tr>
                  <Th>Модель</Th>
                  <Th className="text-right">Запросов</Th>
                  <Th className="text-right">Расход</Th>
                </tr>
              </thead>
              <tbody>
                {byModel.map((row) => (
                  <Tr key={row.modelSlug}>
                    <Td className="font-mono text-xs">{row.modelSlug}</Td>
                    <Td className="text-right text-xs">{row._count._all}</Td>
                    <Td className="text-right text-xs">{formatRub(row._sum.costKopecks ?? 0n)}</Td>
                  </Tr>
                ))}
              </tbody>
            </Table>
          )}
        </Card>
      </div>

      <div className="mt-6">
        <Card className="overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4">
            <div className="font-medium text-white">Журнал запросов</div>
            <div className="text-xs text-slate-500">
              Страница {page} из {totalPages}
            </div>
          </div>

          {logs.length === 0 ? (
            <div className="border-t border-white/5 px-5 py-10 text-center text-sm text-slate-500">
              За выбранный период запросов не было.
            </div>
          ) : (
            <Table className="min-w-[720px]">
              <thead>
                <tr>
                  <Th>Время</Th>
                  <Th>Ключ</Th>
                  <Th>Модель</Th>
                  <Th className="text-right">Вход</Th>
                  <Th className="text-right">Выход</Th>
                  <Th className="text-right">Кэш</Th>
                  <Th className="text-right">Стоимость</Th>
                  <Th>Статус</Th>
                  <Th className="text-right">мс</Th>
                </tr>
              </thead>
              <tbody>
                {logs.map((log) => (
                  <Tr key={log.id}>
                    <Td className="text-xs text-slate-400">{formatDateTime(log.createdAt)}</Td>
                    <Td className="text-xs text-slate-400">
                      {log.apiKeyId ? (keyNames.get(log.apiKeyId) ?? "—") : "—"}
                    </Td>
                    <Td className="font-mono text-xs">{log.modelSlug}</Td>
                    <Td className="text-right text-xs">{formatTokens(log.promptTokens)}</Td>
                    <Td className="text-right text-xs">{formatTokens(log.completionTokens)}</Td>
                    <Td className="text-right text-xs">{formatTokens(log.cachedTokens)}</Td>
                    <Td className="text-right text-xs">{formatRub(log.costKopecks)}</Td>
                    <Td>
                      {log.status === "ok" ? (
                        <Badge tone="success">{log.streamed ? "stream" : "ok"}</Badge>
                      ) : (
                        <Badge tone="danger">{log.httpStatus}</Badge>
                      )}
                    </Td>
                    <Td className="text-right text-xs text-slate-500">{log.latencyMs}</Td>
                  </Tr>
                ))}
              </tbody>
            </Table>
          )}

          {totalPages > 1 ? (
            <div className="flex items-center justify-between border-t border-white/5 px-5 py-4 text-xs">
              {page > 1 ? (
                <Link href={pageLink(page - 1)} className="text-brand-300 hover:text-brand-200">
                  ← Новее
                </Link>
              ) : (
                <span />
              )}
              {page < totalPages ? (
                <Link href={pageLink(page + 1)} className="text-brand-300 hover:text-brand-200">
                  Старее →
                </Link>
              ) : (
                <span />
              )}
            </div>
          ) : null}
        </Card>
      </div>
    </div>
  );
}
