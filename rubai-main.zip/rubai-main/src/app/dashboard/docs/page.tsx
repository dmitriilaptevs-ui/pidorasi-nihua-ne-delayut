import type { Metadata } from "next";
import { DocsTabs } from "@/components/docs-tabs";
import { Card, PageHeader } from "@/components/ui";
import { requireUser } from "@/lib/auth";
import { env } from "@/lib/env";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Документация",
};

export default async function DashboardDocsPage() {
  await requireUser();

  return (
    <div>
      <PageHeader
        title="Подключение"
        description="Замените base_url и ключ в вашем инструменте — остальной код менять не нужно."
      />

      <Card className="mb-6 p-5">
        <div className="grid gap-5 md:grid-cols-3">
          <div>
            <div className="text-xs font-medium uppercase tracking-wide text-slate-500">Base URL</div>
            <div className="mt-1.5 font-mono text-sm text-brand-300">{env.appUrl}/v1</div>
          </div>
          <div>
            <div className="text-xs font-medium uppercase tracking-wide text-slate-500">
              Авторизация
            </div>
            <div className="mt-1.5 font-mono text-sm text-slate-300">Bearer sk-rubai-…</div>
          </div>
          <div>
            <div className="text-xs font-medium uppercase tracking-wide text-slate-500">
              Поддержка
            </div>
            <div className="mt-1.5 text-sm text-slate-300">
              Стриминг, tool calling, эмбеддинги
            </div>
          </div>
        </div>
      </Card>

      <DocsTabs baseUrl={env.appUrl} />
    </div>
  );
}
