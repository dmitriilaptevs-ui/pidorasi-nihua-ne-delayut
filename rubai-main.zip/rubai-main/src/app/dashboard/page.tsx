import Link from "next/link";
import { ArrowUpRight, KeyRound } from "lucide-react";
import { CodeBlock } from "@/components/code-block";
import { BarChart } from "@/components/charts";
import { Badge, Button, Card, PageHeader, Stat, Table, Td, Th, Tr } from "@/components/ui";
import { requireUser } from "@/lib/auth";
import { startOfMonth } from "@/lib/billing";
import { prisma } from "@/lib/db";
import { env } from "@/lib/env";
import { formatRub, formatTokens } from "@/lib/money";

export const dynamic = "force-dynamic";

function dayKey(date: Date): string {
  return date.toISOString().slice(0, 10);
}

function formatDay(date: Date): string {
  return new Intl.DateTimeFormat("ru-RU", { day: "2-digit", month: "2-digit" }).format(date);
}

function formatDateTime(date: Date): string {
  return new Intl.DateTimeFormat("ru-RU", {
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

export default async function DashboardOverviewPage() {
  const user = await requireUser();
  const now = new Date();
  const todayStart = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
  const monthStart = startOfMonth(now);
  const chartStart = new Date(todayStart.getTime() - 13 * 24 * 60 * 60 * 1000);

  const [todaySpend, monthSpend, monthRequests, activeKeys, recentLogs, chartLogs] = await Promise.all([
    prisma.usageLog.aggregate({
      where: { userId: user.id, status: "ok", createdAt: { gte: todayStart } },
      _sum: { costKopecks: true },
    }),
    prisma.usageLog.aggregate({
      where: { userId: user.id, status: "ok", createdAt: { gte: monthStart } },
      _sum: { costKopecks: true, totalTokens: true },
    }),
    prisma.usageLog.count({ where: { userId: user.id, createdAt: { gte: monthStart } } }),
    prisma.apiKey.count({ where: { userId: user.id, status: "ACTIVE" } }),
    prisma.usageLog.findMany({ where: { userId: user.id }, orderBy: { createdAt: "desc" }, take: 8 }),
    prisma.usageLog.findMany({
      where: { userId: user.id, status: "ok", createdAt: { gte: chartStart } },
      select: { createdAt: true, costKopecks: true },
      take: 10_000,
    }),
  ]);

  const buckets = new Map<string, number>();
  for (let index = 0; index < 14; index += 1) {
    const date = new Date(chartStart.getTime() + index * 24 * 60 * 60 * 1000);
    buckets.set(dayKey(date), 0);
  }
  for (const log of chartLogs) {
    const key = dayKey(log.createdAt);
    buckets.set(key, (buckets.get(key) ?? 0) + Number(log.costKopecks));
  }
  const chartData = Array.from(buckets.entries()).map(([key, value]) => ({
    label: formatDay(new Date(`${key}T00:00:00Z`)),
    value,
  }));

  const quickStart = `from openai import OpenAI

client = OpenAI(
    api_key="sk-rubai-ВАШ_КЛЮЧ",
    base_url="${env.appUrl}/v1",
)`;

  return (
    <div>
      <PageHeader
        title={`Привет, ${user.name.split(" ")[0]}!`}
        description="Сводка по балансу, расходам и последним запросам к моделям."
      >
        <Link href="/dashboard/keys">
          <Button size="sm">
            <KeyRound className="h-3.5 w-3.5" /> Выпустить ключ
          </Button>
        </Link>
      </PageHeader>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Stat
          label="Баланс"
          value={formatRub(user.balanceKopecks)}
          hint={
            Number(user.balanceKopecks) < 10_000
              ? "Пора пополнить баланс"
              : "Средства не сгорают"
          }
        />
        <Stat label="Расход сегодня" value={formatRub(todaySpend._sum.costKopecks ?? 0n)} />
        <Stat
          label="Расход за месяц"
          value={formatRub(monthSpend._sum.costKopecks ?? 0n)}
          hint={`${formatTokens(monthSpend._sum.totalTokens ?? 0)} токенов`}
        />
        <Stat
          label="Запросов за месяц"
          value={monthRequests.toLocaleString("ru-RU")}
          hint={`Активных ключей: ${activeKeys}`}
        />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1.6fr_1fr]">
        <Card className="p-6">
          <div className="mb-5 flex items-center justify-between">
            <div>
              <div className="font-medium text-white">Расход за 14 дней</div>
              <div className="mt-1 text-xs text-slate-500">Сумма списаний по всем ключам</div>
            </div>
            <Link
              href="/dashboard/usage"
              className="flex items-center gap-1 text-xs text-brand-300 transition hover:text-brand-200"
            >
              Вся статистика <ArrowUpRight className="h-3.5 w-3.5" />
            </Link>
          </div>
          <BarChart data={chartData} />
        </Card>

        <Card className="p-6">
          <div className="font-medium text-white">Быстрый старт</div>
          <div className="mt-1 text-xs text-slate-500">
            Замените ключ на свой и отправьте первый запрос
          </div>
          <CodeBlock className="mt-4" title="python" code={quickStart} />
        </Card>
      </div>

      <div className="mt-6">
        <Card className="overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4">
            <div className="font-medium text-white">Последние запросы</div>
            <Link
              href="/dashboard/usage"
              className="text-xs text-brand-300 transition hover:text-brand-200"
            >
              Смотреть все
            </Link>
          </div>
          {recentLogs.length === 0 ? (
            <div className="border-t border-white/5 px-5 py-10 text-center text-sm text-slate-500">
              Запросов ещё не было. Выпустите API-ключ и отправьте первый запрос.
            </div>
          ) : (
            <Table>
              <thead>
                <tr>
                  <Th>Время</Th>
                  <Th>Модель</Th>
                  <Th className="text-right">Токены</Th>
                  <Th className="text-right">Стоимость</Th>
                  <Th>Статус</Th>
                </tr>
              </thead>
              <tbody>
                {recentLogs.map((log) => (
                  <Tr key={log.id}>
                    <Td className="text-xs text-slate-400">{formatDateTime(log.createdAt)}</Td>
                    <Td className="font-mono text-xs">{log.modelSlug}</Td>
                    <Td className="text-right text-xs">{formatTokens(log.totalTokens)}</Td>
                    <Td className="text-right text-xs">{formatRub(log.costKopecks)}</Td>
                    <Td>
                      {log.status === "ok" ? (
                        <Badge tone="success">ok</Badge>
                      ) : (
                        <Badge tone="danger">{log.httpStatus}</Badge>
                      )}
                    </Td>
                  </Tr>
                ))}
              </tbody>
            </Table>
          )}
        </Card>
      </div>
    </div>
  );
}
