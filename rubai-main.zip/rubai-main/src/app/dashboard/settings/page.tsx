import type { Metadata } from "next";
import { PasswordForm, ProfileForm } from "@/components/settings-forms";
import { Card, PageHeader } from "@/components/ui";
import { requireUser } from "@/lib/auth";
import { formatRub } from "@/lib/money";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Настройки",
};

export default async function SettingsPage() {
  const user = await requireUser();

  return (
    <div>
      <PageHeader title="Настройки" description="Профиль, пароль и состояние аккаунта." />

      <div className="grid gap-6 lg:grid-cols-2">
        <ProfileForm initialName={user.name} email={user.email} />
        <PasswordForm />

        <Card className="p-6">
          <div className="font-medium text-white">Аккаунт</div>
          <dl className="mt-5 space-y-3 text-sm">
            <div className="flex items-center justify-between">
              <dt className="text-slate-500">Роль</dt>
              <dd className="text-slate-200">{user.role === "ADMIN" ? "Администратор" : "Пользователь"}</dd>
            </div>
            <div className="flex items-center justify-between">
              <dt className="text-slate-500">Баланс</dt>
              <dd className="text-slate-200">{formatRub(user.balanceKopecks)}</dd>
            </div>
            <div className="flex items-center justify-between">
              <dt className="text-slate-500">Дата регистрации</dt>
              <dd className="text-slate-200">
                {new Intl.DateTimeFormat("ru-RU", { dateStyle: "long" }).format(user.createdAt)}
              </dd>
            </div>
            <div className="flex items-center justify-between">
              <dt className="text-slate-500">Согласие на обработку ПДн</dt>
              <dd className="text-slate-200">{user.consentPd ? "да" : "нет"}</dd>
            </div>
          </dl>
        </Card>

        <Card className="p-6">
          <div className="font-medium text-white">Безопасность</div>
          <ul className="mt-5 space-y-3 text-sm leading-relaxed text-slate-400">
            <li>• API-ключи хранятся только в виде хеша — восстановить их невозможно.</li>
            <li>• Отозванный ключ перестаёт работать мгновенно.</li>
            <li>• Лимит расхода защищает от неожиданных трат на стороне клиента.</li>
            <li>• Список активных сессий появится на втором этапе развития сервиса.</li>
          </ul>
        </Card>
      </div>
    </div>
  );
}
