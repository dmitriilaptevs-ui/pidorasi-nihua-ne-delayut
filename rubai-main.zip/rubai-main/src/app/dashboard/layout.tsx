import Link from "next/link";
import type { ReactNode } from "react";
import { DashboardNav } from "@/components/dashboard-nav";
import { LogoutButton } from "@/components/logout-button";
import { Badge } from "@/components/ui";
import { requireUser } from "@/lib/auth";
import { formatRub } from "@/lib/money";

export const dynamic = "force-dynamic";

export default async function DashboardLayout({ children }: { children: ReactNode }) {
  const user = await requireUser();

  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[256px_1fr]">
      <aside className="border-b border-white/5 bg-ink-900/50 lg:sticky lg:top-0 lg:h-screen lg:border-b-0 lg:border-r">
        <div className="flex items-center gap-2.5 px-5 py-5">
          <Link href="/" className="flex items-center gap-2.5">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-brand-400 to-brand-600 text-sm font-bold text-white">
              r
            </span>
            <span className="text-lg font-semibold text-white">rubai</span>
          </Link>
          <Badge tone="brand">beta</Badge>
        </div>

        <div className="px-3">
          <DashboardNav isAdmin={user.role === "ADMIN"} />
        </div>

        <div className="mt-6 hidden border-t border-white/5 px-5 py-4 text-xs lg:block">
          <div className="truncate font-medium text-slate-300">{user.name}</div>
          <div className="mt-0.5 truncate text-slate-500">{user.email}</div>
        </div>
      </aside>

      <div className="flex min-h-screen flex-col">
        <header className="sticky top-0 z-20 flex items-center justify-between gap-4 border-b border-white/5 bg-ink-950/80 px-5 py-3 backdrop-blur">
          <div className="text-sm text-slate-400">Личный кабинет</div>
          <div className="flex items-center gap-3">
            <div className="rounded-xl border border-white/10 bg-white/[0.04] px-3.5 py-2 text-sm">
              <span className="text-slate-500">Баланс: </span>
              <span className="font-medium text-white">{formatRub(user.balanceKopecks)}</span>
            </div>
            <LogoutButton />
          </div>
        </header>

        <main className="flex-1 px-5 py-8 lg:px-8">{children}</main>
      </div>
    </div>
  );
}
