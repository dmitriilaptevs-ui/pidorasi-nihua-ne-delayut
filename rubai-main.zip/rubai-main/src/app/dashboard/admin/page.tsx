import type { Metadata } from "next";
import { AdminPanel, type AdminUserRow } from "@/components/admin-panel";
import { Badge, Card, PageHeader, Stat, Table, Td, Th, Tr } from "@/components/ui";
import { requireAdmin } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { formatRub } from "@/lib/money";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Админка",
};

export default async function AdminPage() {
  await requireAdmin();

  const [settings, users, spendByUser, totalBalance, totalSpend, totalDeposits, payments, modelsCount, requestsCount] =
    await Promise.all([
      getSettings(),
      prisma.user.findMany({
        orderBy: { createdAt: "desc" },
        take: 100,
        include: { _count: { select: { apiKeys: true } } },
      }),
      prisma.usageLog.groupBy({
        by: ["userId"],
        where: { status: "ok" },
        _sum: { costKopecks: true },
      }),
      prisma.user.aggregate({ _sum: { balanceKopecks: true } }),
      prisma.usageLog.aggregate({ where: { status: "ok" }, _sum: { costKopecks: true } }),
      prisma.transaction.aggregate({
        where: { type: { in: ["DEPOSIT", "ADJUSTMENT"] }, amountKopecks: { gt: 0 } },
        _sum: { amountKopecks: true },
      }),
      prisma.payment.findMany({ orderBy: { createdAt: "desc" }, take: 15, include: { user: true } }),
      prisma.model.count({ where: { isActive: true } }),
      prisma.usageLog.count(),
    ]);

  const spendMap = new Map(spendByUser.map((row) => [row.userId, Number(row._sum.costKopecks ?? 0n)]));

  const userRows: AdminUserRow[] = users.map((user) => ({
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    balanceKopecks: Number(user.balanceKopecks),
    spendKopecks: spendMap.get(user.id) ?? 0,
    keysCount: user._count.apiKeys,
    createdAt: user.createdAt.toISOString(),
  }));

  return (
    <div>
      <PageHeader
        title="Админка"
        description="Синхронизация каталога, цены, пользователи и платежи."
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="Пользователей" value={users.length} hint={`Моделей в каталоге: ${modelsCount}`} />
        <Stat label="Запросов всего" value={requestsCount.toLocaleString("ru-RU")} />
        <Stat
          label="Оборот (списания)"
          value={formatRub(totalSpend._sum.costKopecks ?? 0n)}
          hint={`Зачислено: ${formatRub(totalDeposits._sum.amountKopecks ?? 0n)}`}
        />
        <Stat
          label="Суммарный баланс"
          value={formatRub(totalBalance._sum.balanceKopecks ?? 0n)}
          hint="Обязательства перед пользователями"
        />
      </div>

      <div className="mt-6">
        <AdminPanel settings={settings} users={userRows} />
      </div>

      <div className="mt-6">
        <Card className="overflow-hidden">
          <div className="px-5 py-4 font-medium text-white">Последние платежи</div>
          {payments.length === 0 ? (
            <div className="border-t border-white/5 px-5 py-8 text-center text-sm text-slate-500">
              Платежей пока нет.
            </div>
          ) : (
            <Table className="min-w-[640px]">
              <thead>
                <tr>
                  <Th>Дата</Th>
                  <Th>Пользователь</Th>
                  <Th>Провайдер</Th>
                  <Th className="text-right">Сумма</Th>
                  <Th>Статус</Th>
                </tr>
              </thead>
              <tbody>
                {payments.map((payment) => (
                  <Tr key={payment.id}>
                    <Td className="text-xs text-slate-400">
                      {new Intl.DateTimeFormat("ru-RU", {
                        dateStyle: "short",
                        timeStyle: "short",
                      }).format(payment.createdAt)}
                    </Td>
                    <Td className="text-xs">
                      <div className="text-slate-200">{payment.user.name}</div>
                      <div className="text-slate-500">{payment.user.email}</div>
                    </Td>
                    <Td className="text-xs text-slate-400">{payment.provider}</Td>
                    <Td className="text-right text-xs">{formatRub(payment.amountKopecks)}</Td>
                    <Td>
                      {payment.status === "SUCCEEDED" ? <Badge tone="success">оплачен</Badge> : null}
                      {payment.status === "PENDING" ? <Badge tone="warning">ожидает</Badge> : null}
                      {payment.status === "CANCELED" ? <Badge tone="danger">отменён</Badge> : null}
                    </Td>
                  </Tr>
                ))}
              </tbody>
            </Table>
          )}
        </Card>
      </div>
    </div>
  );
}
