import type { Metadata } from "next";
import { ModelsExplorer } from "@/components/models-explorer";
import { PageHeader } from "@/components/ui";
import { requireUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { serializeModel } from "@/lib/serializers";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Модели",
};

export default async function DashboardModelsPage() {
  await requireUser();

  const [models, settings] = await Promise.all([
    prisma.model.findMany({ where: { isActive: true }, orderBy: { outputUsdPerM: "asc" } }),
    getSettings(),
  ]);

  return (
    <div>
      <PageHeader
        title="Доступные модели"
        description="Используйте точный slug модели в параметре model при запросе к API."
      />
      <ModelsExplorer
        models={models.map((model) => serializeModel(model, settings))}
        usdRubRate={settings.usdRubRate}
        markupPercent={settings.markupPercent}
      />
    </div>
  );
}
