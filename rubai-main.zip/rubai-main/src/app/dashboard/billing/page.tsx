import type { Metadata } from "next";
import { TopupForm } from "@/components/topup-form";
import { Badge, Card, PageHeader, Stat, Table, Td, Th, Tr } from "@/components/ui";
import { requireUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { env } from "@/lib/env";
import { formatRub, formatRubWhole } from "@/lib/money";
import { refreshPendingPayments } from "@/lib/payments";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Пополнение баланса",
};

function formatDateTime(date: Date): string {
  return new Intl.DateTimeFormat("ru-RU", {
    day: "2-digit",
    month: "2-digit",
    year: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

const TXN_LABELS: Record<string, string> = {
  DEPOSIT: "Пополнение",
  CHARGE: "Списание",
  REFUND: "Возврат",
  ADJUSTMENT: "Корректировка",
};

export default async function BillingPage() {
  const user = await requireUser();
  await refreshPendingPayments(user.id);

  const [freshUser, payments, transactions] = await Promise.all([
    prisma.user.findUniqueOrThrow({ where: { id: user.id } }),
    prisma.payment.findMany({ where: { userId: user.id }, orderBy: { createdAt: "desc" }, take: 20 }),
    prisma.transaction.findMany({ where: { userId: user.id }, orderBy: { createdAt: "desc" }, take: 20 }),
  ]);

  const mock = env.paymentMode === "mock";
  const totalDeposited = transactions
    .filter((txn) => txn.type === "DEPOSIT" || txn.type === "ADJUSTMENT")
    .reduce((sum, txn) => sum + Number(txn.amountKopecks), 0);

  return (
    <div>
      <PageHeader
        title="Пополнение баланса"
        description="Средства расходуются только по факту запросов к моделям. Баланс не сгорает."
      />

      <div className="grid gap-4 sm:grid-cols-3">
        <Stat label="Текущий баланс" value={formatRub(freshUser.balanceKopecks)} />
        <Stat
          label="Пополнено (последние операции)"
          value={formatRubWhole(totalDeposited)}
          hint="Сумма зачислений в журнале"
        />
        <Stat
          label="Режим оплаты"
          value={mock ? "Тестовый" : "ЮKassa"}
          hint={mock ? "PAYMENT_MODE=mock" : "Боевой магазин"}
        />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_1.4fr]">
        <TopupForm mock={mock} />

        <Card className="overflow-hidden">
          <div className="px-5 py-4 font-medium text-white">История платежей</div>
          {payments.length === 0 ? (
            <div className="border-t border-white/5 px-5 py-10 text-center text-sm text-slate-500">
              Платежей пока не было.
            </div>
          ) : (
            <Table className="min-w-[480px]">
              <thead>
                <tr>
                  <Th>Дата</Th>
                  <Th>Сумма</Th>
                  <Th>Провайдер</Th>
                  <Th>Статус</Th>
                </tr>
              </thead>
              <tbody>
                {payments.map((payment) => (
                  <Tr key={payment.id}>
                    <Td className="text-xs text-slate-400">{formatDateTime(payment.createdAt)}</Td>
                    <Td className="text-sm">{formatRub(payment.amountKopecks)}</Td>
                    <Td className="text-xs text-slate-400">{payment.provider}</Td>
                    <Td>
                      {payment.status === "SUCCEEDED" ? <Badge tone="success">оплачен</Badge> : null}
                      {payment.status === "PENDING" ? <Badge tone="warning">ожидает</Badge> : null}
                      {payment.status === "CANCELED" ? <Badge tone="danger">отменён</Badge> : null}
                    </Td>
                  </Tr>
                ))}
              </tbody>
            </Table>
          )}
        </Card>
      </div>

      <div className="mt-6">
        <Card className="overflow-hidden">
          <div className="px-5 py-4 font-medium text-white">Движение средств</div>
          {transactions.length === 0 ? (
            <div className="border-t border-white/5 px-5 py-10 text-center text-sm text-slate-500">
              Операций пока не было.
            </div>
          ) : (
            <Table className="min-w-[560px]">
              <thead>
                <tr>
                  <Th>Дата</Th>
                  <Th>Операция</Th>
                  <Th>Описание</Th>
                  <Th className="text-right">Сумма</Th>
                  <Th className="text-right">Баланс после</Th>
                </tr>
              </thead>
              <tbody>
                {transactions.map((txn) => (
                  <Tr key={txn.id}>
                    <Td className="text-xs text-slate-400">{formatDateTime(txn.createdAt)}</Td>
                    <Td className="text-xs">
                      <Badge
                        tone={
                          txn.type === "CHARGE"
                            ? "neutral"
                            : txn.type === "DEPOSIT"
                              ? "success"
                              : "warning"
                        }
                      >
                        {TXN_LABELS[txn.type] ?? txn.type}
                      </Badge>
                    </Td>
                    <Td className="max-w-xs truncate text-xs text-slate-400">{txn.description}</Td>
                    <Td
                      className={`text-right text-sm ${
                        Number(txn.amountKopecks) >= 0 ? "text-emerald-300" : "text-slate-300"
                      }`}
                    >
                      {formatRub(txn.amountKopecks, { signed: true })}
                    </Td>
                    <Td className="text-right text-xs text-slate-400">
                      {formatRub(txn.balanceAfter)}
                    </Td>
                  </Tr>
                ))}
              </tbody>
            </Table>
          )}
        </Card>
      </div>
    </div>
  );
}
