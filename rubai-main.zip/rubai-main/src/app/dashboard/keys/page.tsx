import type { Metadata } from "next";
import { KeysManager } from "@/components/keys-manager";
import { PageHeader } from "@/components/ui";
import { requireUser } from "@/lib/auth";
import { startOfMonth } from "@/lib/billing";
import { prisma } from "@/lib/db";
import { env } from "@/lib/env";
import { serializeApiKey, serializeModel, type ApiKeyDto } from "@/lib/serializers";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "API-ключи",
};

export default async function KeysPage() {
  const user = await requireUser();

  const [keys, monthAgg, totalAgg, models, settings] = await Promise.all([
    prisma.apiKey.findMany({ where: { userId: user.id }, orderBy: { createdAt: "desc" } }),
    prisma.usageLog.groupBy({
      by: ["apiKeyId"],
      where: { userId: user.id, status: "ok", createdAt: { gte: startOfMonth() } },
      _sum: { costKopecks: true },
    }),
    prisma.usageLog.groupBy({
      by: ["apiKeyId"],
      where: { userId: user.id, status: "ok" },
      _sum: { costKopecks: true },
    }),
    prisma.model.findMany({ where: { isActive: true }, orderBy: { outputUsdPerM: "asc" }, take: 400 }),
    getSettings(),
  ]);

  const monthMap = new Map(monthAgg.map((row) => [row.apiKeyId ?? "", row._sum.costKopecks ?? 0n]));
  const totalMap = new Map(totalAgg.map((row) => [row.apiKeyId ?? "", row._sum.costKopecks ?? 0n]));

  const initialKeys: ApiKeyDto[] = keys.map((key) =>
    serializeApiKey(key, (key.limitPeriod === "MONTHLY" ? monthMap : totalMap).get(key.id) ?? 0n),
  );

  return (
    <div>
      <PageHeader
        title="API-ключи"
        description="Выпускайте отдельные ключи для проектов и окружений, задавайте лимиты и отзывайте доступ в один клик."
      />
      <KeysManager
        initialKeys={initialKeys}
        models={models.map((model) => serializeModel(model, settings))}
        defaultRpm={env.defaultKeyRpm}
      />
    </div>
  );
}
