import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "rubai — зарубежные AI-модели с оплатой в рублях",
    template: "%s — rubai",
  },
  description:
    "Единый OpenAI-совместимый API к GPT, Claude, Gemini, DeepSeek и сотням других моделей. Оплата в рублях, ключи, лимиты и статистика расходов.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru">
      <body>{children}</body>
    </html>
  );
}
