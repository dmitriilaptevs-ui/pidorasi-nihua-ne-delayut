import type { Metadata } from "next";
import { Card } from "@/components/ui";
import { LoginForm } from "@/components/login-form";

export const metadata: Metadata = {
  title: "Вход",
};

export default function LoginPage() {
  return (
    <Card className="w-full max-w-md p-8">
      <h1 className="text-xl font-semibold text-white">Вход в rubai</h1>
      <p className="mt-1.5 text-sm text-slate-400">Управляйте ключами, балансом и статистикой.</p>
      <div className="mt-7">
        <LoginForm />
      </div>
    </Card>
  );
}
