import type { Metadata } from "next";
import { Card } from "@/components/ui";
import { RegisterForm } from "@/components/register-form";

export const metadata: Metadata = {
  title: "Регистрация",
};

export default function RegisterPage() {
  return (
    <Card className="w-full max-w-md p-8">
      <h1 className="text-xl font-semibold text-white">Создать аккаунт</h1>
      <p className="mt-1.5 text-sm text-slate-400">
        Ключ можно выпустить сразу после регистрации. Пополнение — от 100 ₽.
      </p>
      <div className="mt-7">
        <RegisterForm />
      </div>
    </Card>
  );
}
