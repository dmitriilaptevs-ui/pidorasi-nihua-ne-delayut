import type { Metadata } from "next";
import Link from "next/link";
import { DocsTabs } from "@/components/docs-tabs";
import { Badge, Button, Card, Table, Td, Th, Tr } from "@/components/ui";
import { env } from "@/lib/env";

export const metadata: Metadata = {
  title: "Документация",
  description: "Как подключить rubai к OpenAI SDK, Cursor, Cline и OpenCode.",
};

export default function DocsPage() {
  return (
    <div className="mx-auto w-full max-w-4xl px-4 py-12">
      <Badge tone="brand" className="mb-4">
        Документация
      </Badge>
      <h1 className="text-3xl font-semibold text-white">Подключение к rubai</h1>
      <p className="mt-3 max-w-2xl text-sm leading-relaxed text-slate-400">
        rubai — это OpenAI-совместимый API. Замените <code className="text-slate-200">base_url</code> и
        API-ключ в вашем инструменте — и получите доступ ко всем моделям каталога через единый баланс.
      </p>

      <Card className="mt-8 p-6">
        <div className="grid gap-6 md:grid-cols-2">
          <div>
            <div className="text-xs font-medium uppercase tracking-wide text-slate-500">Base URL</div>
            <div className="mt-2 font-mono text-sm text-brand-300">{env.appUrl}/v1</div>
          </div>
          <div>
            <div className="text-xs font-medium uppercase tracking-wide text-slate-500">
              Аутентификация
            </div>
            <div className="mt-2 font-mono text-sm text-slate-300">
              Authorization: Bearer sk-rubai-…
            </div>
          </div>
        </div>
        <div className="mt-6 flex flex-wrap gap-3">
          <Link href="/dashboard/keys">
            <Button size="sm">Выпустить API-ключ</Button>
          </Link>
          <Link href="/models">
            <Button size="sm" variant="secondary">
              Каталог моделей
            </Button>
          </Link>
        </div>
      </Card>

      <div className="mt-10">
        <h2 className="mb-5 text-xl font-semibold text-white">Примеры интеграции</h2>
        <DocsTabs baseUrl={env.appUrl} />
      </div>

      <div className="mt-10">
        <h2 className="mb-5 text-xl font-semibold text-white">Поддерживаемые endpoints</h2>
        <Card className="overflow-hidden">
          <Table className="min-w-[520px]">
            <thead>
              <tr>
                <Th>Метод</Th>
                <Th>Endpoint</Th>
                <Th>Описание</Th>
              </tr>
            </thead>
            <tbody>
              <Tr>
                <Td className="font-mono text-xs text-emerald-300">POST</Td>
                <Td className="font-mono text-xs">/v1/chat/completions</Td>
                <Td className="text-xs">Чат-комплишены, стриминг, tool calling</Td>
              </Tr>
              <Tr>
                <Td className="font-mono text-xs text-emerald-300">POST</Td>
                <Td className="font-mono text-xs">/v1/embeddings</Td>
                <Td className="text-xs">Векторные представления текста</Td>
              </Tr>
              <Tr>
                <Td className="font-mono text-xs text-sky-300">GET</Td>
                <Td className="font-mono text-xs">/v1/models</Td>
                <Td className="text-xs">Список доступных моделей</Td>
              </Tr>
            </tbody>
          </Table>
        </Card>
        <p className="mt-3 text-xs text-slate-500">
          Алиасы с префиксом <code>/api</code> (например, <code>/api/v1/chat/completions</code>)
          работают так же.
        </p>
      </div>

      <div className="mt-10">
        <h2 className="mb-5 text-xl font-semibold text-white">Ошибки API</h2>
        <Card className="overflow-hidden">
          <Table className="min-w-[520px]">
            <thead>
              <tr>
                <Th>Код</Th>
                <Th>Причина</Th>
                <Th>Что делать</Th>
              </tr>
            </thead>
            <tbody>
              <Tr>
                <Td className="font-mono text-xs">401</Td>
                <Td className="text-xs">Ключ неверный или отозван</Td>
                <Td className="text-xs">Проверьте ключ в личном кабинете</Td>
              </Tr>
              <Tr>
                <Td className="font-mono text-xs">402</Td>
                <Td className="text-xs">Недостаточно средств на балансе</Td>
                <Td className="text-xs">Пополните баланс</Td>
              </Tr>
              <Tr>
                <Td className="font-mono text-xs">403</Td>
                <Td className="text-xs">Ключ приостановлен или модель запрещена</Td>
                <Td className="text-xs">Проверьте настройки ключа</Td>
              </Tr>
              <Tr>
                <Td className="font-mono text-xs">404</Td>
                <Td className="text-xs">Модель не найдена</Td>
                <Td className="text-xs">Запросите список моделей: GET /v1/models</Td>
              </Tr>
              <Tr>
                <Td className="font-mono text-xs">429</Td>
                <Td className="text-xs">Превышен лимит расхода или частота запросов</Td>
                <Td className="text-xs">Увеличьте лимит ключа или подождите</Td>
              </Tr>
            </tbody>
          </Table>
        </Card>
      </div>

      <div className="mt-10">
        <h2 className="mb-5 text-xl font-semibold text-white">Как считаются токены и стоимость</h2>
        <Card className="space-y-3 p-6 text-sm leading-relaxed text-slate-400">
          <p>
            Каждый запрос логируется: количество входных, выходных и кэшированных токенов, модель и
            итоговая стоимость в рублях.
          </p>
          <p>
            Стоимость = цена модели в долларах за 1 млн токенов × курс ЦБ РФ × наценка сервиса.
            Результат округляется до копейки. Курс и наценка на момент запроса сохраняются в журнале.
          </p>
          <p>
            В ответах API возвращаются служебные заголовки:{" "}
            <code className="text-slate-200">x-rubai-cost-kopecks</code>,{" "}
            <code className="text-slate-200">x-rubai-balance-kopecks</code> и{" "}
            <code className="text-slate-200">x-rubai-request-id</code>.
          </p>
        </Card>
      </div>
    </div>
  );
}
