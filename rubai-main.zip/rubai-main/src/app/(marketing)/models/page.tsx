import type { Metadata } from "next";
import { ModelsExplorer } from "@/components/models-explorer";
import { prisma } from "@/lib/db";
import { serializeModel, type ModelDto } from "@/lib/serializers";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Каталог AI-моделей",
  description: "Все доступные модели с ценами в рублях за миллион токенов.",
};

async function loadModels(): Promise<{ models: ModelDto[]; usdRubRate: number; markupPercent: number }> {
  try {
    const [models, settings] = await Promise.all([
      prisma.model.findMany({ where: { isActive: true }, orderBy: { outputUsdPerM: "asc" } }),
      getSettings(),
    ]);
    return {
      models: models.map((model) => serializeModel(model, settings)),
      usdRubRate: settings.usdRubRate,
      markupPercent: settings.markupPercent,
    };
  } catch {
    return { models: [], usdRubRate: 95, markupPercent: 30 };
  }
}

export default async function PublicModelsPage() {
  const { models, usdRubRate, markupPercent } = await loadModels();

  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-12">
      <div className="mb-8">
        <h1 className="text-3xl font-semibold text-white">Каталог моделей</h1>
        <p className="mt-2 max-w-2xl text-sm text-slate-400">
          {models.length > 0
            ? `${models.length} моделей доступны через единый OpenAI-совместимый API.`
            : "Каталог пока пуст: администратору нужно выполнить синхронизацию моделей."}
        </p>
      </div>

      <ModelsExplorer models={models} usdRubRate={usdRubRate} markupPercent={markupPercent} />
    </div>
  );
}
