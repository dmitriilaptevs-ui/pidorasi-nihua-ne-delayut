import Link from "next/link";
import { ArrowRight, BarChart3, KeyRound, Layers, ShieldCheck, Sparkles, Wallet } from "lucide-react";
import { CodeBlock } from "@/components/code-block";
import { Badge, Button, Card } from "@/components/ui";
import { env } from "@/lib/env";
import { formatRubWhole, formatTokens } from "@/lib/money";
import { prisma } from "@/lib/db";
import { serializeModel, type ModelDto } from "@/lib/serializers";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

const FALLBACK_MODELS: Array<Pick<ModelDto, "slug" | "displayName" | "provider" | "contextLength" | "inputRubPerM" | "outputRubPerM">> = [
  { slug: "openai/gpt-4o-mini", displayName: "GPT-4o mini", provider: "openai", contextLength: 128_000, inputRubPerM: 18.53, outputRubPerM: 74.1 },
  { slug: "anthropic/claude-3.5-sonnet", displayName: "Claude 3.5 Sonnet", provider: "anthropic", contextLength: 200_000, inputRubPerM: 370.5, outputRubPerM: 1852.5 },
  { slug: "google/gemini-2.0-flash-001", displayName: "Gemini 2.0 Flash", provider: "google", contextLength: 1_000_000, inputRubPerM: 12.35, outputRubPerM: 49.4 },
  { slug: "deepseek/deepseek-chat", displayName: "DeepSeek V3", provider: "deepseek", contextLength: 64_000, inputRubPerM: 17.29, outputRubPerM: 34.58 },
  { slug: "meta-llama/llama-3.3-70b-instruct", displayName: "Llama 3.3 70B", provider: "meta-llama", contextLength: 131_072, inputRubPerM: 14.82, outputRubPerM: 37.05 },
  { slug: "qwen/qwen-2.5-72b-instruct", displayName: "Qwen 2.5 72B", provider: "qwen", contextLength: 32_768, inputRubPerM: 43.23, outputRubPerM: 49.4 },
];

async function loadFeatured(): Promise<ModelDto[]> {
  try {
    const [models, settings] = await Promise.all([
      prisma.model.findMany({
        where: { isActive: true, isFeatured: true },
        orderBy: { outputUsdPerM: "asc" },
        take: 6,
      }),
      getSettings(),
    ]);
    return models.map((model) => serializeModel(model, settings));
  } catch {
    return [];
  }
}

function priceRub(value: number): string {
  return new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 2 }).format(value);
}

export default async function LandingPage() {
  const featured = await loadFeatured();

  const heroCode = `from openai import OpenAI

client = OpenAI(
    api_key="sk-rubai-ВАШ_КЛЮЧ",
    base_url="${env.appUrl}/v1",
)

response = client.chat.completions.create(
    model="openai/gpt-4o-mini",
    messages=[{"role": "user", "content": "Привет!"}],
)`;

  return (
    <div>
      {/* ── Hero ─────────────────────────────────────────────────────────── */}
      <section className="hero-glow relative overflow-hidden">
        <div className="grid-lines pointer-events-none absolute inset-0" />
        <div className="relative mx-auto w-full max-w-6xl px-4 pb-20 pt-16 md:pt-24">
          <div className="grid items-center gap-12 lg:grid-cols-[1.1fr_1fr]">
            <div>
              <Badge tone="brand" className="mb-5">
                <Sparkles className="h-3.5 w-3.5" /> OpenAI-совместимый API · Оплата в рублях
              </Badge>
              <h1 className="text-4xl font-semibold leading-tight tracking-tight text-white md:text-5xl">
                Все зарубежные AI-модели — через{" "}
                <span className="bg-gradient-to-r from-brand-300 to-accent-400 bg-clip-text text-transparent">
                  один API
                </span>{" "}
                и с оплатой в рублях
              </h1>
              <p className="mt-5 max-w-xl text-base leading-relaxed text-slate-400">
                GPT, Claude, Gemini, DeepSeek и сотни других моделей. Один ключ, один баланс, один
                endpoint. Подключается к Cursor, Cline, OpenCode и любому OpenAI SDK за пару минут.
              </p>

              <div className="mt-8 flex flex-wrap items-center gap-3">
                <Link href="/register">
                  <Button size="lg">
                    Начать бесплатно <ArrowRight className="h-4 w-4" />
                  </Button>
                </Link>
                <Link href="/models">
                  <Button size="lg" variant="secondary">
                    Смотреть каталог
                  </Button>
                </Link>
              </div>

              <div className="mt-10 grid max-w-lg grid-cols-3 gap-6">
                <div>
                  <div className="text-2xl font-semibold text-white">300+</div>
                  <div className="mt-1 text-xs text-slate-500">моделей в каталоге</div>
                </div>
                <div>
                  <div className="text-2xl font-semibold text-white">1 endpoint</div>
                  <div className="mt-1 text-xs text-slate-500">OpenAI-совместимый</div>
                </div>
                <div>
                  <div className="text-2xl font-semibold text-white">от 100 ₽</div>
                  <div className="mt-1 text-xs text-slate-500">пополнение баланса</div>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="absolute -inset-4 rounded-3xl bg-brand-600/10 blur-2xl" />
              <div className="relative">
                <CodeBlock code={heroCode} title="python · OpenAI SDK" />
                <Card className="mt-4 flex items-center gap-4 p-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-500/15 text-brand-300">
                    <Layers className="h-5 w-5" />
                  </div>
                  <div className="text-xs leading-relaxed text-slate-400">
                    Меняете только <span className="text-slate-200">base_url</span> и ключ — остальной
                    код остаётся прежним. Стриминг, tool calling и эмбеддинги поддерживаются.
                  </div>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Модели ───────────────────────────────────────────────────────── */}
      <section className="mx-auto w-full max-w-6xl px-4 py-16">
        <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
          <div>
            <h2 className="text-2xl font-semibold text-white">Популярные модели</h2>
            <p className="mt-1.5 text-sm text-slate-400">
              Цены указаны в рублях с учётом курса ЦБ РФ и наценки сервиса.
            </p>
          </div>
          <Link href="/models" className="text-sm text-brand-300 transition hover:text-brand-200">
            Все модели →
          </Link>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {(featured.length > 0 ? featured : FALLBACK_MODELS).map((model) => (
            <Card key={model.slug} className="p-5 transition hover:border-brand-500/30">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-medium text-white">{model.displayName}</div>
                  <div className="mt-0.5 font-mono text-xs text-slate-500">{model.slug}</div>
                </div>
                <Badge>{model.provider}</Badge>
              </div>
              <div className="mt-4 flex items-center justify-between text-xs text-slate-400">
                <span>
                  Контекст:{" "}
                  {model.contextLength
                    ? `${formatTokens(model.contextLength)} токенов`
                    : "—"}
                </span>
              </div>
              <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                <div className="rounded-lg border border-white/5 bg-white/[0.02] px-3 py-2">
                  <div className="text-slate-500">Вход</div>
                  <div className="mt-0.5 font-medium text-slate-200">
                    {priceRub(model.inputRubPerM)} ₽ / 1M
                  </div>
                </div>
                <div className="rounded-lg border border-white/5 bg-white/[0.02] px-3 py-2">
                  <div className="text-slate-500">Выход</div>
                  <div className="mt-0.5 font-medium text-slate-200">
                    {priceRub(model.outputRubPerM)} ₽ / 1M
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </section>

      {/* ── Возможности ──────────────────────────────────────────────────── */}
      <section className="border-y border-white/5 bg-ink-900/40 py-16">
        <div className="mx-auto w-full max-w-6xl px-4">
          <h2 className="text-2xl font-semibold text-white">Всё для работы с моделями — в одном месте</h2>
          <div className="mt-10 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {[
              {
                icon: <Layers className="h-5 w-5" />,
                title: "OpenAI-совместимый API",
                text: "Один endpoint для всех моделей. Работает с официальными SDK, Cursor, Cline, OpenCode и любым агентом с поддержкой смены base_url.",
              },
              {
                icon: <Wallet className="h-5 w-5" />,
                title: "Оплата в рублях",
                text: "Пополнение российской картой. Оплата только за фактическое использование — подписок и сгорающих лимитов нет.",
              },
              {
                icon: <KeyRound className="h-5 w-5" />,
                title: "Ключи и лимиты",
                text: "Выпускайте отдельные ключи для проектов и окружений, ставьте лимит в рублях, приостанавливайте и отзывайте в один клик.",
              },
              {
                icon: <BarChart3 className="h-5 w-5" />,
                title: "Статистика расходов",
                text: "Токены и стоимость по каждому ключу, модели и дню. Экспорт в CSV для отчётности.",
              },
              {
                icon: <Sparkles className="h-5 w-5" />,
                title: "Прозрачные цены",
                text: "Курс ЦБ РФ плюс фиксированная наценка. Актуальные цены на все модели видны без регистрации.",
              },
              {
                icon: <ShieldCheck className="h-5 w-5" />,
                title: "Контроль доступа",
                text: "Ограничивайте ключ конкретными моделями и частотой запросов. Полный аудит обращений в журнале.",
              },
            ].map((feature) => (
              <Card key={feature.title} className="p-6">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-500/15 text-brand-300">
                  {feature.icon}
                </div>
                <div className="mt-4 font-medium text-white">{feature.title}</div>
                <p className="mt-2 text-sm leading-relaxed text-slate-400">{feature.text}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* ── Три шага ─────────────────────────────────────────────────────── */}
      <section className="mx-auto w-full max-w-6xl px-4 py-16">
        <h2 className="text-2xl font-semibold text-white">Подключение за три шага</h2>
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {[
            {
              step: "01",
              title: "Зарегистрируйтесь",
              text: "Создайте аккаунт и выпустите API-ключ в личном кабинете. Это занимает меньше минуты.",
            },
            {
              step: "02",
              title: "Пополните баланс",
              text: "Оплатите российской картой от 100 ₽. Средства расходуются только по факту запросов.",
            },
            {
              step: "03",
              title: "Замените base_url",
              text: `Укажите ${env.appUrl}/v1 в настройках агента или SDK — и работайте с любой моделью из каталога.`,
            },
          ].map((item) => (
            <Card key={item.step} className="p-6">
              <div className="font-mono text-sm text-brand-300">{item.step}</div>
              <div className="mt-3 font-medium text-white">{item.title}</div>
              <p className="mt-2 text-sm leading-relaxed text-slate-400">{item.text}</p>
            </Card>
          ))}
        </div>
      </section>

      {/* ── Тарифы ───────────────────────────────────────────────────────── */}
      <section id="pricing" className="border-y border-white/5 bg-ink-900/40 py-16">
        <div className="mx-auto w-full max-w-6xl px-4">
          <h2 className="text-2xl font-semibold text-white">Простые условия</h2>
          <p className="mt-1.5 text-sm text-slate-400">
            Оплата только за использование. Никаких подписок и сгорающих лимитов.
          </p>

          <div className="mt-10 grid gap-4 md:grid-cols-2">
            <Card className="p-7">
              <Badge tone="brand">Популярный</Badge>
              <div className="mt-4 text-lg font-medium text-white">Физическим лицам</div>
              <div className="mt-2 text-3xl font-semibold text-white">от 100 ₽</div>
              <div className="mt-1 text-xs text-slate-500">пополнение баланса</div>
              <ul className="mt-6 space-y-3 text-sm text-slate-400">
                <li>• Доступ ко всем моделям каталога через API</li>
                <li>• OpenAI-совместимый SDK и endpoint</li>
                <li>• Ключи, лимиты и статистика расходов</li>
                <li>• Баланс не сгорает</li>
              </ul>
              <Link href="/register" className="mt-7 block">
                <Button className="w-full">Начать бесплатно</Button>
              </Link>
            </Card>

            <Card className="p-7">
              <Badge>Корпоративный</Badge>
              <div className="mt-4 text-lg font-medium text-white">Для команд и бизнеса</div>
              <div className="mt-2 text-3xl font-semibold text-white">По запросу</div>
              <div className="mt-1 text-xs text-slate-500">второй этап развития сервиса</div>
              <ul className="mt-6 space-y-3 text-sm text-slate-400">
                <li>• Управление командой, ролями и общими ключами</li>
                <li>• Аналитика по сотрудникам и проектам</li>
                <li>• Оплата по счёту, закрывающие документы</li>
                <li>• SLA и приоритетная поддержка</li>
              </ul>
              <div className="mt-7">
                <Button variant="secondary" className="w-full" disabled>
                  Скоро
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* ── FAQ ──────────────────────────────────────────────────────────── */}
      <section id="faq" className="mx-auto w-full max-w-3xl px-4 py-16">
        <h2 className="text-2xl font-semibold text-white">Частые вопросы</h2>
        <div className="mt-8 space-y-3">
          {[
            {
              q: "Совместим ли ваш API с кодом для OpenAI?",
              a: `Да. Достаточно заменить base_url на ${env.appUrl}/v1 и указать ключ rubai — остальной код менять не нужно. Работает с официальными SDK Python, Node.js и любым OpenAI-совместимым инструментом.`,
            },
            {
              q: "Как оплатить использование?",
              a: "Пополните баланс российской картой через ЮKassa от 100 ₽. Деньги списываются по факту запросов, исходя из фактического числа токенов. Баланс не сгорает.",
            },
            {
              q: "Как считается стоимость запроса?",
              a: "Стоимость модели в долларах умножается на курс ЦБ РФ и фиксированную наценку сервиса. Итог округляется до копейки и отображается в статистике по каждому запросу.",
            },
            {
              q: "Можно ли ограничить расходы?",
              a: "Да. На каждый API-ключ можно задать лимит в рублях (месячный или общий) и частоту запросов. При достижении лимита ключ автоматически перестаёт обслуживать запросы.",
            },
            {
              q: "Что с моими данными?",
              a: "Запросы передаются выбранным провайдерам моделей согласно их политикам. Мы храним историю обращений (модель, токены, стоимость) для биллинга и статистики. Подробнее — в политике конфиденциальности.",
            },
            {
              q: "Поддерживается ли Claude Code?",
              a: "В MVP доступен OpenAI-совместимый API: он подключается к Cursor, Cline, OpenCode и любому OpenAI SDK. Поддержка Anthropic-совместимого протокола для Claude Code запланирована на второй этап.",
            },
          ].map((item) => (
            <details
              key={item.q}
              className="group rounded-2xl border border-white/10 bg-white/[0.03] px-5 py-4 open:bg-white/[0.05]"
            >
              <summary className="cursor-pointer list-none text-sm font-medium text-slate-200 marker:hidden">
                <span className="flex items-center justify-between gap-4">
                  {item.q}
                  <span className="text-slate-500 transition group-open:rotate-45">+</span>
                </span>
              </summary>
              <p className="mt-3 text-sm leading-relaxed text-slate-400">{item.a}</p>
            </details>
          ))}
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────────────────────── */}
      <section className="mx-auto w-full max-w-6xl px-4 pb-20">
        <Card className="hero-glow relative overflow-hidden p-10 text-center">
          <h2 className="text-2xl font-semibold text-white">Начните работать с лучшими моделями прямо сейчас</h2>
          <p className="mx-auto mt-3 max-w-xl text-sm text-slate-400">
            Один API-ключ — сотни моделей. Регистрация занимает меньше минуты, минимальное пополнение —
            {formatRubWhole(10_000n)}.
          </p>
          <div className="mt-7 flex justify-center gap-3">
            <Link href="/register">
              <Button size="lg">Создать аккаунт</Button>
            </Link>
            <Link href="/docs">
              <Button size="lg" variant="secondary">
                Документация
              </Button>
            </Link>
          </div>
        </Card>
      </section>
    </div>
  );
}
