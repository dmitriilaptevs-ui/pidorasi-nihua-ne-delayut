import Link from "next/link";
import type { ReactNode } from "react";
import { Badge, Button } from "@/components/ui";
import { getCurrentUser } from "@/lib/auth";

export default async function MarketingLayout({ children }: { children: ReactNode }) {
  let isAuthenticated = false;
  try {
    isAuthenticated = (await getCurrentUser()) !== null;
  } catch {
    isAuthenticated = false;
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-30 border-b border-white/5 bg-ink-950/80 backdrop-blur">
        <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between px-4">
          <Link href="/" className="flex items-center gap-2.5">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-brand-400 to-brand-600 text-sm font-bold text-white">
              r
            </span>
            <span className="text-lg font-semibold tracking-tight text-white">rubai</span>
            <Badge tone="brand">beta</Badge>
          </Link>

          <nav className="hidden items-center gap-7 text-sm text-slate-300 md:flex">
            <Link href="/models" className="transition hover:text-white">
              Модели
            </Link>
            <Link href="/docs" className="transition hover:text-white">
              Документация
            </Link>
            <Link href="/#pricing" className="transition hover:text-white">
              Тарифы
            </Link>
            <Link href="/#faq" className="transition hover:text-white">
              FAQ
            </Link>
          </nav>

          <div className="flex items-center gap-3">
            {isAuthenticated ? (
              <Link href="/dashboard">
                <Button size="sm">Личный кабинет</Button>
              </Link>
            ) : (
              <>
                <Link href="/login" className="text-sm text-slate-300 transition hover:text-white">
                  Войти
                </Link>
                <Link href="/register">
                  <Button size="sm">Начать бесплатно</Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </header>

      <main className="flex-1">{children}</main>

      <footer className="border-t border-white/5 bg-ink-900/40">
        <div className="mx-auto grid w-full max-w-6xl gap-10 px-4 py-12 md:grid-cols-4">
          <div>
            <div className="flex items-center gap-2.5">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-brand-400 to-brand-600 text-sm font-bold text-white">
                r
              </span>
              <span className="text-lg font-semibold text-white">rubai</span>
            </div>
            <p className="mt-3 max-w-xs text-xs leading-relaxed text-slate-500">
              Единый OpenAI-совместимый API к зарубежным AI-моделям с оплатой в рублях. MVP-версия
              сервиса.
            </p>
          </div>

          <div>
            <div className="text-xs font-semibold uppercase tracking-wide text-slate-500">Продукт</div>
            <ul className="mt-3 space-y-2 text-sm text-slate-400">
              <li>
                <Link href="/models" className="transition hover:text-white">
                  Каталог моделей
                </Link>
              </li>
              <li>
                <Link href="/docs" className="transition hover:text-white">
                  Документация
                </Link>
              </li>
              <li>
                <Link href="/#pricing" className="transition hover:text-white">
                  Тарифы
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <div className="text-xs font-semibold uppercase tracking-wide text-slate-500">Аккаунт</div>
            <ul className="mt-3 space-y-2 text-sm text-slate-400">
              <li>
                <Link href="/register" className="transition hover:text-white">
                  Регистрация
                </Link>
              </li>
              <li>
                <Link href="/login" className="transition hover:text-white">
                  Вход
                </Link>
              </li>
              <li>
                <Link href="/dashboard" className="transition hover:text-white">
                  Личный кабинет
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <div className="text-xs font-semibold uppercase tracking-wide text-slate-500">Документы</div>
            <ul className="mt-3 space-y-2 text-sm text-slate-400">
              <li>
                <Link href="/legal/terms" className="transition hover:text-white">
                  Пользовательское соглашение
                </Link>
              </li>
              <li>
                <Link href="/legal/privacy" className="transition hover:text-white">
                  Политика конфиденциальности
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="border-t border-white/5 py-5 text-center text-xs text-slate-600">
          © {new Date().getFullYear()} rubai. Сервис работает в тестовом режиме.
        </div>
      </footer>
    </div>
  );
}
