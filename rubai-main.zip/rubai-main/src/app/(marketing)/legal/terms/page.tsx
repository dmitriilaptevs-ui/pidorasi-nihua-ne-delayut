import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Пользовательское соглашение",
};

export default function TermsPage() {
  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-12">
      <h1 className="text-3xl font-semibold text-white">Пользовательское соглашение</h1>
      <p className="mt-3 text-sm text-slate-500">
        Редакция от {new Date().toLocaleDateString("ru-RU")}. Документ носит характер заготовки для
        MVP: перед запуском в продакшене текст должен быть проверен юристом.
      </p>

      <div className="prose-invert mt-8 space-y-6 text-sm leading-relaxed text-slate-400">
        <section>
          <h2 className="text-lg font-medium text-white">1. Общие положения</h2>
          <p className="mt-2">
            Сервис rubai предоставляет технический доступ к сторонним AI-моделям через единый
            OpenAI-совместимый интерфейс. Используя сервис, вы соглашаетесь с условиями настоящего
            соглашения.
          </p>
        </section>
        <section>
          <h2 className="text-lg font-medium text-white">2. Учётная запись и баланс</h2>
          <p className="mt-2">
            Пользователь самостоятельно обеспечивает сохранность пароля и API-ключей. Средства,
            зачисленные на баланс, расходуются по факту использования моделей. Баланс не сгорает.
          </p>
        </section>
        <section>
          <h2 className="text-lg font-medium text-white">3. Допустимое использование</h2>
          <p className="mt-2">
            Запрещено использование сервиса для деятельности, нарушающей законодательство Российской
            Федерации, а также для генерации запрещённого контента. Сервис вправе приостановить
            обслуживание при нарушении правил.
          </p>
        </section>
        <section>
          <h2 className="text-lg font-medium text-white">4. Сторонние модели</h2>
          <p className="mt-2">
            Ответы генерируются сторонними провайдерами моделей и могут содержать неточности. Сервис
            не гарантирует пригодность ответов для конкретных целей.
          </p>
        </section>
        <section>
          <h2 className="text-lg font-medium text-white">5. Возврат средств</h2>
          <p className="mt-2">
            Неиспользованные средства могут быть возвращены по запросу в порядке, предусмотренном
            законодательством. Израсходованные на запросы к моделям средства возврату не подлежат.
          </p>
        </section>
      </div>
    </div>
  );
}
