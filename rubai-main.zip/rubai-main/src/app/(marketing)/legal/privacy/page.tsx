import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Политика конфиденциальности",
};

export default function PrivacyPage() {
  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-12">
      <h1 className="text-3xl font-semibold text-white">Политика конфиденциальности</h1>
      <p className="mt-3 text-sm text-slate-500">
        Редакция от {new Date().toLocaleDateString("ru-RU")}. Документ носит характер заготовки для
        MVP: перед запуском в продакшене текст должен быть проверен юристом.
      </p>

      <div className="mt-8 space-y-6 text-sm leading-relaxed text-slate-400">
        <section>
          <h2 className="text-lg font-medium text-white">1. Какие данные мы собираем</h2>
          <p className="mt-2">
            Имя, адрес электронной почты, хеш пароля, историю платежей и техническую информацию об
            обращениях к API: модель, количество токенов, стоимость, время запроса. Тексты запросов и
            ответов моделей не сохраняются.
          </p>
        </section>
        <section>
          <h2 className="text-lg font-medium text-white">2. Зачем мы их используем</h2>
          <p className="mt-2">
            Для работы личного кабинета, биллинга, отображения статистики расходов и защиты сервиса от
            злоупотреблений.
          </p>
        </section>
        <section>
          <h2 className="text-lg font-medium text-white">3. Передача третьим лицам</h2>
          <p className="mt-2">
            Содержимое запросов передаётся провайдерам AI-моделей, выбранным пользователем, согласно
            их собственным политикам конфиденциальности. Платёжные данные обрабатываются ЮKassa; сервис
            не хранит реквизиты карт.
          </p>
        </section>
        <section>
          <h2 className="text-lg font-medium text-white">4. Хранение и удаление</h2>
          <p className="mt-2">
            Данные хранятся на серверах на территории Российской Федерации. Пользователь может
            запросить удаление аккаунта и связанных данных, написав в поддержку.
          </p>
        </section>
        <section>
          <h2 className="text-lg font-medium text-white">5. Согласие</h2>
          <p className="mt-2">
            Регистрируясь в сервисе, пользователь даёт согласие на обработку персональных данных в
            объёме, необходимом для работы сервиса.
          </p>
        </section>
      </div>
    </div>
  );
}
