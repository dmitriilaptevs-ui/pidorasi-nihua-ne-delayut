import { NextResponse } from "next/server";
import { apiUser } from "@/lib/api-auth";
import { prisma } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function csvValue(value: unknown): string {
  const text = String(value ?? "");
  if (text.includes(";") || text.includes('"') || text.includes("\n")) {
    return `"${text.replace(/"/g, '""')}"`;
  }
  return text;
}

export async function GET(request: Request): Promise<Response> {
  const auth = await apiUser();
  if ("response" in auth) return auth.response;

  const url = new URL(request.url);
  const days = Math.min(365, Math.max(1, Number(url.searchParams.get("days")) || 30));
  const keyId = url.searchParams.get("keyId") || undefined;
  const model = url.searchParams.get("model") || undefined;
  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

  const [logs, keys] = await Promise.all([
    prisma.usageLog.findMany({
      where: {
        userId: auth.user.id,
        createdAt: { gte: since },
        ...(keyId ? { apiKeyId: keyId } : {}),
        ...(model ? { modelSlug: model } : {}),
      },
      orderBy: { createdAt: "desc" },
      take: 50_000,
    }),
    prisma.apiKey.findMany({ where: { userId: auth.user.id }, select: { id: true, name: true } }),
  ]);

  const keyNames = new Map(keys.map((key) => [key.id, key.name]));

  const header = [
    "Дата",
    "Модель",
    "Ключ",
    "Входные токены",
    "Выходные токены",
    "Кэшированные токены",
    "Всего токенов",
    "Стоимость, ₽",
    "Статус",
    "HTTP",
    "Задержка, мс",
  ].join(";");

  const rows = logs.map((log) =>
    [
      new Date(log.createdAt).toISOString(),
      log.modelSlug,
      log.apiKeyId ? (keyNames.get(log.apiKeyId) ?? "—") : "—",
      log.promptTokens,
      log.completionTokens,
      log.cachedTokens,
      log.totalTokens,
      (Number(log.costKopecks) / 100).toFixed(2).replace(".", ","),
      log.status,
      log.httpStatus,
      log.latencyMs,
    ]
      .map(csvValue)
      .join(";"),
  );

  const csv = `\uFEFF${[header, ...rows].join("\r\n")}`;

  return new NextResponse(csv, {
    headers: {
      "content-type": "text/csv; charset=utf-8",
      "content-disposition": `attachment; filename="rubai-usage-${new Date().toISOString().slice(0, 10)}.csv"`,
    },
  });
}
