import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { creditPayment, markPaymentCanceled } from "@/lib/payments";
import { getYooKassaPayment } from "@/lib/yookassa";

export const runtime = "nodejs";

/**
 * Вебхук ЮKassa. Не доверяем телу уведомления: перепроверяем платёж
 * через API ЮKassa и зачисляем только при совпадении суммы.
 */
export async function POST(request: Request): Promise<Response> {
  const json = (await request.json().catch(() => null)) as
    | { event?: string; object?: { id?: string } }
    | null;

  const providerPaymentId = json?.object?.id;
  if (!providerPaymentId) {
    return NextResponse.json({ ok: true, skipped: true });
  }

  const payment = await prisma.payment.findFirst({ where: { providerPaymentId } });
  if (!payment) {
    return NextResponse.json({ ok: true, skipped: true });
  }

  try {
    const remote = await getYooKassaPayment(providerPaymentId);

    if (remote.status === "succeeded" && remote.paid) {
      const remoteKopecks = BigInt(Math.round(Number(remote.amountValue) * 100));
      const metadataMatches = remote.metadata.paymentId === payment.id;
      if (remoteKopecks === payment.amountKopecks && metadataMatches) {
        await creditPayment({ paymentId: payment.id, providerPaymentId: remote.id });
      }
    } else if (remote.status === "canceled") {
      await markPaymentCanceled(payment.id);
    }
  } catch {
    // При ошибке проверки отвечаем 200, чтобы ЮKassa не зациклила повтор,
    // платёж будет перепроверен на странице пополнения.
  }

  return NextResponse.json({ ok: true });
}
