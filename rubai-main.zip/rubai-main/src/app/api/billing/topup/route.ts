import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { rubToKopecks } from "@/lib/money";
import { createTopupPayment } from "@/lib/payments";
import { topupSchema } from "@/lib/validators";

export const runtime = "nodejs";

export async function POST(request: Request): Promise<Response> {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Требуется авторизация" }, { status: 401 });

  const json = await request.json().catch(() => null);
  const parsed = topupSchema.safeParse(json);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Некорректная сумма" },
      { status: 400 },
    );
  }

  try {
    const result = await createTopupPayment({
      userId: user.id,
      amountKopecks: rubToKopecks(parsed.data.amountRub),
    });

    return NextResponse.json({
      paymentId: result.payment.id,
      mock: result.mock,
      confirmationUrl: result.confirmationUrl,
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Не удалось создать платёж";
    return NextResponse.json({ error: message }, { status: 502 });
  }
}
