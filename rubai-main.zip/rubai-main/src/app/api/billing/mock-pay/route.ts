import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { env } from "@/lib/env";
import { creditPayment } from "@/lib/payments";

export const runtime = "nodejs";

/** Подтверждение тестового платежа — работает только в режиме PAYMENT_MODE=mock. */
export async function POST(request: Request): Promise<Response> {
  if (env.paymentMode !== "mock") {
    return NextResponse.json({ error: "Тестовые платежи отключены" }, { status: 404 });
  }

  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Требуется авторизация" }, { status: 401 });

  const json = (await request.json().catch(() => null)) as { paymentId?: string } | null;
  const paymentId = json?.paymentId;
  if (!paymentId) return NextResponse.json({ error: "Не указан платёж" }, { status: 400 });

  const payment = await prisma.payment.findFirst({ where: { id: paymentId, userId: user.id } });
  if (!payment) return NextResponse.json({ error: "Платёж не найден" }, { status: 404 });

  const credited = await creditPayment({ paymentId: payment.id });
  const fresh = await prisma.user.findUniqueOrThrow({ where: { id: user.id } });

  return NextResponse.json({
    ok: true,
    credited,
    balanceKopecks: Number(fresh.balanceKopecks),
  });
}
