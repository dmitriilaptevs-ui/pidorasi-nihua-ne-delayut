import { NextResponse } from "next/server";
import { destroySession } from "@/lib/auth";

export const runtime = "nodejs";

export async function POST(): Promise<Response> {
  await destroySession();
  return NextResponse.json({ ok: true });
}
