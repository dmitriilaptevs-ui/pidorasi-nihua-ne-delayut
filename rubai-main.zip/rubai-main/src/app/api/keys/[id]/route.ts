import type { Prisma } from "@prisma/client";
import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { rubToKopecks } from "@/lib/money";
import { serializeApiKey } from "@/lib/serializers";
import { updateKeySchema } from "@/lib/validators";

export const runtime = "nodejs";

interface RouteParams {
  params: Promise<{ id: string }>;
}

export async function PATCH(request: Request, { params }: RouteParams): Promise<Response> {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Требуется авторизация" }, { status: 401 });

  const { id } = await params;
  const key = await prisma.apiKey.findFirst({ where: { id, userId: user.id } });
  if (!key) return NextResponse.json({ error: "Ключ не найден" }, { status: 404 });
  if (key.status === "REVOKED") {
    return NextResponse.json({ error: "Отозванный ключ нельзя изменить" }, { status: 400 });
  }

  const json = await request.json().catch(() => null);
  const parsed = updateKeySchema.safeParse(json);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Некорректные данные" },
      { status: 400 },
    );
  }

  const data: Prisma.ApiKeyUpdateInput = {};
  const input = parsed.data;
  if (input.name !== undefined) data.name = input.name;
  if (input.limitRub !== undefined) {
    data.limitKopecks = input.limitRub === null ? null : rubToKopecks(input.limitRub);
  }
  if (input.limitPeriod !== undefined) data.limitPeriod = input.limitPeriod;
  if (input.allowedModels !== undefined) data.allowedModels = input.allowedModels;
  if (input.rpmLimit !== undefined) data.rpmLimit = input.rpmLimit;
  if (input.status !== undefined) data.status = input.status;

  const updated = await prisma.apiKey.update({ where: { id: key.id }, data });

  const spend = await prisma.usageLog.aggregate({
    where: { apiKeyId: key.id, status: "ok" },
    _sum: { costKopecks: true },
  });

  return NextResponse.json({ key: serializeApiKey(updated, spend._sum.costKopecks ?? 0n) });
}

export async function DELETE(_request: Request, { params }: RouteParams): Promise<Response> {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Требуется авторизация" }, { status: 401 });

  const { id } = await params;
  const key = await prisma.apiKey.findFirst({ where: { id, userId: user.id } });
  if (!key) return NextResponse.json({ error: "Ключ не найден" }, { status: 404 });

  const updated = await prisma.apiKey.update({
    where: { id: key.id },
    data: { status: "REVOKED", revokedAt: new Date() },
  });

  return NextResponse.json({ key: serializeApiKey(updated, 0n) });
}
