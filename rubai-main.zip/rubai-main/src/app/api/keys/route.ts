import { NextResponse } from "next/server";
import { generateApiKey } from "@/lib/api-keys";
import { getCurrentUser } from "@/lib/auth";
import { startOfMonth } from "@/lib/billing";
import { prisma } from "@/lib/db";
import { env } from "@/lib/env";
import { rubToKopecks } from "@/lib/money";
import { serializeApiKey } from "@/lib/serializers";
import { createKeySchema } from "@/lib/validators";

export const runtime = "nodejs";

export async function GET(): Promise<Response> {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Требуется авторизация" }, { status: 401 });

  const [keys, monthAgg, totalAgg] = await Promise.all([
    prisma.apiKey.findMany({ where: { userId: user.id }, orderBy: { createdAt: "desc" } }),
    prisma.usageLog.groupBy({
      by: ["apiKeyId"],
      where: { userId: user.id, status: "ok", createdAt: { gte: startOfMonth() } },
      _sum: { costKopecks: true },
    }),
    prisma.usageLog.groupBy({
      by: ["apiKeyId"],
      where: { userId: user.id, status: "ok" },
      _sum: { costKopecks: true },
    }),
  ]);

  const monthMap = new Map(monthAgg.map((row) => [row.apiKeyId ?? "", row._sum.costKopecks ?? 0n]));
  const totalMap = new Map(totalAgg.map((row) => [row.apiKeyId ?? "", row._sum.costKopecks ?? 0n]));

  const data = keys.map((key) =>
    serializeApiKey(key, (key.limitPeriod === "MONTHLY" ? monthMap : totalMap).get(key.id) ?? 0n),
  );

  return NextResponse.json({ keys: data });
}

export async function POST(request: Request): Promise<Response> {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Требуется авторизация" }, { status: 401 });

  const json = await request.json().catch(() => null);
  const parsed = createKeySchema.safeParse(json);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Некорректные данные" },
      { status: 400 },
    );
  }

  const { name, limitRub, limitPeriod, allowedModels, rpmLimit } = parsed.data;
  const generated = generateApiKey();

  const key = await prisma.apiKey.create({
    data: {
      userId: user.id,
      name,
      keyHash: generated.hash,
      keyPrefix: generated.prefix,
      last4: generated.last4,
      limitKopecks: limitRub === undefined || limitRub === null ? null : rubToKopecks(limitRub),
      limitPeriod,
      allowedModels,
      rpmLimit: rpmLimit ?? env.defaultKeyRpm,
    },
  });

  return NextResponse.json({
    key: serializeApiKey(key, 0n),
    plainKey: generated.plain,
  });
}
