import { NextResponse } from "next/server";
import { apiAdmin } from "@/lib/api-auth";
import { syncUsdRate } from "@/lib/rate-sync";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(): Promise<Response> {
  const auth = await apiAdmin();
  if ("response" in auth) return auth.response;

  try {
    const rate = await syncUsdRate();
    return NextResponse.json({ ok: true, usdRubRate: rate });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Ошибка обновления курса" },
      { status: 502 },
    );
  }
}
