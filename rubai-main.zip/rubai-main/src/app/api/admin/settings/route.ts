import { NextResponse } from "next/server";
import { apiAdmin } from "@/lib/api-auth";
import { SETTING_KEYS, getSettings, setSetting } from "@/lib/settings";
import { adminSettingsSchema } from "@/lib/validators";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request): Promise<Response> {
  const auth = await apiAdmin();
  if ("response" in auth) return auth.response;

  const json = await request.json().catch(() => null);
  const parsed = adminSettingsSchema.safeParse(json);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Некорректные данные" },
      { status: 400 },
    );
  }

  const { usdRubRate, markupPercent } = parsed.data;
  if (usdRubRate !== undefined) await setSetting(SETTING_KEYS.usdRubRate, String(usdRubRate));
  if (markupPercent !== undefined) await setSetting(SETTING_KEYS.markupPercent, String(markupPercent));

  const settings = await getSettings();
  return NextResponse.json({ ok: true, settings });
}
