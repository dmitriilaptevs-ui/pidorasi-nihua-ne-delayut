import { NextResponse } from "next/server";
import { apiAdmin } from "@/lib/api-auth";
import { adjustBalance } from "@/lib/billing";
import { prisma } from "@/lib/db";
import { rubToKopecks } from "@/lib/money";
import { adminBalanceSchema } from "@/lib/validators";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }): Promise<Response> {
  const auth = await apiAdmin();
  if ("response" in auth) return auth.response;

  const { id } = await params;
  const user = await prisma.user.findUnique({ where: { id } });
  if (!user) return NextResponse.json({ error: "Пользователь не найден" }, { status: 404 });

  const json = await request.json().catch(() => null);
  const parsed = adminBalanceSchema.safeParse(json);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Некорректные данные" },
      { status: 400 },
    );
  }

  const { deltaRub, description } = parsed.data;
  const updated = await adjustBalance({
    userId: user.id,
    deltaKopecks: rubToKopecks(deltaRub),
    description: description || `Корректировка баланса администратором (${auth.user.email})`,
  });

  return NextResponse.json({ ok: true, balanceKopecks: Number(updated.balanceKopecks) });
}
