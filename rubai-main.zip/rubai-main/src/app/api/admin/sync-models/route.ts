import { NextResponse } from "next/server";
import { apiAdmin } from "@/lib/api-auth";
import { syncModels } from "@/lib/model-sync";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(): Promise<Response> {
  const auth = await apiAdmin();
  if ("response" in auth) return auth.response;

  try {
    const result = await syncModels();
    return NextResponse.json({ ok: true, ...result });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Ошибка синхронизации" },
      { status: 502 },
    );
  }
}
