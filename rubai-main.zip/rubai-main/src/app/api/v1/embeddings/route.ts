import { handleEmbeddings } from "@/lib/gateway";
import { corsPreflight } from "@/lib/openai-error";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request): Promise<Response> {
  return handleEmbeddings(request);
}

export async function OPTIONS(): Promise<Response> {
  return corsPreflight();
}
