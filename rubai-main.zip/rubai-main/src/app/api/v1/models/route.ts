import { handleModels } from "@/lib/gateway";
import { corsPreflight } from "@/lib/openai-error";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: Request): Promise<Response> {
  return handleModels(request);
}

export async function OPTIONS(): Promise<Response> {
  return corsPreflight();
}
