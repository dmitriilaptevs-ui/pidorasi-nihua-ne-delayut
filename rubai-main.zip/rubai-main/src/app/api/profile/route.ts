import { NextResponse } from "next/server";
import { apiUser } from "@/lib/api-auth";
import { prisma } from "@/lib/db";
import { profileSchema } from "@/lib/validators";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request): Promise<Response> {
  const auth = await apiUser();
  if ("response" in auth) return auth.response;

  const json = await request.json().catch(() => null);
  const parsed = profileSchema.safeParse(json);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Некорректные данные" },
      { status: 400 },
    );
  }

  const user = await prisma.user.update({
    where: { id: auth.user.id },
    data: { name: parsed.data.name },
  });

  return NextResponse.json({ ok: true, user: { id: user.id, name: user.name, email: user.email } });
}
